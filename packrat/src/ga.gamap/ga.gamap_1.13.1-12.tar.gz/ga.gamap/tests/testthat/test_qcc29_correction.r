library(ga.gamap)
library(ga.data)
library(ga.utils)

context( "qcc29 correction" )

test_that( "data is corrected", {

    pr <- probe.set("ibs3", include.technical=FALSE)
    nc <- length(pr)
    nc2 <- nc/2

    n <- 4
    x <- rbind(
        matrix( 10, ncol=nc, nrow=n, dimnames = list( paste("Sample",1:n), pr ) ),
        matrix( rep(1:2,each=nc2), ncol=nc, nrow=2, byrow=TRUE, dimnames = list( paste0("QCC29_",LETTERS[1:2]), pr ))
    )

    expect_warning(
        xc <- qcc29.correct( x ),
        "plate"
    )

    expect_equal( dim(x), dim(xc) )
    expect_true( all( xc[5:6,] == 0 ) )

    ## the first half of the profiles should now be all 9s, (10-1)
    expect_true( all( xc[1:4,1:27] == 9 ) )
    ## the second half of the profiles should be all 8s, (10-2)
    expect_true( all( xc[1:4,nc2+(1:nc2)] == 8 ), "second half of profile has correct corrected values" )

})

test_that( "data is corrected across multiple plates", {

    pr <- probe.set("ibs3", include.technical=FALSE)
    nc <- length(pr)
    nc2 <- nc/2

    n <- 4
    x <- rbind(
        matrix( 10, ncol=nc, nrow=n, dimnames = list( paste("Sample",1:n), pr ) ),
        matrix( rep(1:2,each=nc2), ncol=nc, nrow=2, byrow=TRUE, dimnames = list( paste0("QCC29_",LETTERS[1:2]), pr )),
        matrix( 8, ncol=nc, nrow=n, dimnames = list( paste("Sample",1:n), pr ) ),
        matrix( rep(3:4,each=nc2), ncol=nc, nrow=2, byrow=TRUE, dimnames = list( paste0("QCC29_",LETTERS[1:2]), pr ))
    )

    attr( x, "plate" ) <- rep( 1:2, each=6 )

    xc <- qcc29.correct( x )

    expect_equal( dim(x), dim(xc) )
    expect_true( all( xc[grepl("QCC29",rownames(xc)),,drop=FALSE] == 0 ) )

    x.nq <- xc[ !grepl("QCC29",rownames(xc)), ]

    ## the first half of the profiles should now be all 9s, (10-1)
    expect( all( x.nq[1:4,1:27] == 9 ), "first half of profile has correct corrected values" )
    ## the second half of the profiles should be all 8s, (10-2)
    expect( all( x.nq[1:4,nc2+(1:nc2)] == 8 ), "second half of profile has correct corrected values" )

    ## the first half of the profiles should now be all 9s, (10-1)
    expect( all( x.nq[4+(1:4),1:27] == 5 ), "first half of part 2 of profiles has correct corrected values" )
    ## the second half of the profiles should be all 8s, (10-2)
    expect( all( x.nq[4+(1:4),nc2+(1:nc2)] == 4 ), "second half of part 2 of profiles has correct corrected values" )

})

test_that( "qcc29 correction on real data", {

    lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )
    di.qcc <- gamap( lx200.file, stop.at="qcc" )

    xc <- qcc29.correct( di.qcc )

    ## all values are now lower
    expect_true( all( di.qcc[,lx200.probes(incl=FALSE)] - xc[,lx200.probes(incl=FALSE)] > 0 ) )
    ## but no values are below zero
    expect_true( !any( xc[, lx200.probes(incl=FALSE)] < 0 ), "no negative values after correction" )

})

test_that( "qcc29 correction works with regression", {

    lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )
    di.qcc <- gamap( lx200.file, stop.at="qcc" )

    di.plate <- gamap( lx200.file, stop.at="file" )
    xc   <- qcc29.correct( di.qcc, variant="regression", meta.data=meta(di.plate) )
    set.qcc.indeces( xc, verbose=FALSE )

    ## all values are now lower
    expect_true( all( di.qcc[,lx200.probes(incl=FALSE)] - xc[,lx200.probes(incl=FALSE)] > 0 ) )
    ## but no values are below zero
    expect_true( !any( xc[, lx200.probes(incl=FALSE)] < 0 ), "no negative values after correction" )

    ## test specific data points
    xx <- seq_along( rownames(di.qcc) )
    x.29 <- xx[ i.qcc29 ]
    y.29 <- di.qcc[ i.qcc29, lx200.probes(incl=F), drop=FALSE ]

    ff <- function( index, probe ) {
        v <- di.qcc[ index, probe ]
        y <- y.29[, probe ]
        x <- x.29
        m <- lm( y~x )
        yh <- predict( m, newdata=data.frame(x=index) )
        return( v-yh )
    }

    ## for( i in 1:nrow(di.qcc) ) {
    qcc29.tests <- unlist(lapply( 1:nrow(di.qcc), function(i) {
        ## for( p in lx200.probes(include.technical=FALSE) ) {
        lapply( lx200.probes(include.technical=FALSE), function(p) {
            clamp(ff(i,p),c(0,Inf)) - xc[ i, p ]
        })
    }))

    expect_true( all( abs(qcc29.tests) < 1e-12 ) )

})

test_that( "qcc29 correction handles unordered plates", {

    lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )
    di.plate <- gamap( lx200.file, stop.at="file" )
    di.qcc <- gamap( lx200.file, stop.at="qcc" )

    xc1 <- qcc29.correct( di.qcc, variant="regression", meta=di.plate )

    set.seed( 101 )
    s <- sample( 1:nrow(di.plate) )
    di.plate.s <- subset_deep( di.plate, s )
    di.plate.s
    di.qcc.s <- gamap( di.plate.s, start.from="file", stop.at="qcc" )

    xc   <- qcc29.correct( di.qcc.s, variant="regression", meta=di.plate.s )
    xc.matched <- xc[ match( 1:nrow(xc), s ), ]

    expect_equivalent(
        xc.matched,
        xc1
    )

})
