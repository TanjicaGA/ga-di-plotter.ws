##' cycle a vector
##'
##' Shifts elements of a vector a number of positions in either
##' direction
##' @title cycle
##' @param x vector to cycle
##' @param positions How many posiotions to shift the
##'     elements. accepts positiave and negative indeces
##' @return cycled vector
##' @author Torbjørn Lindahl
##' @export
cycle <- function(x,positions=1) {

    i <- seq_along(x) - positions

    j <- i %% length(x)

    j[ j == 0 ] <- length(x)

    return( x[j] )

}
