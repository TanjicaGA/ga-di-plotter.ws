library(ga.gamap)
library(ga.utils)
library(ga.data)
library(dplyr)

biocode.file <- file.path( "data", "Q2-005-K1515_II-BC1511.csv" )

context( "bacteria levels" )

test_that( "bacteria levels are right", {

    bt <- gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision="rev3" )

    expect_true( !is.null( dim(bt) ) )
    expect_equal( ncol(bt), 39 )
    expect_true( all( grepl("^[AI]G\\d{4}", colnames(bt) ) ) )

    bt0 <- load.get(
        "data/bacteria_levels_data_q2005_k1515.RData",
        verbose=FALSE )

    expect_equal(
        bt, bt0
        )

})

test_that( "data.frame interface works", {

    rev3 <- bacteria.limits( revision="rev3" )
    rev2 <- bacteria.limits( revision="rev2" )

    bt <- gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision="rev3" )
    bt2 <- gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision=rev3 )

    expect_identical( bt, bt2 )

    bt3 <- gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision="rev2" )
    bt4 <- gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision=rev2 )

    expect_identical( bt3, bt4 )

    ## Introduce an invalid probe in the list
    d <- rev3
    d$Probe[1] <- "FOO"

    expect_error(
        gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision=d ),
        "probe"
    )

})

test_that( "bt with qcc29 correction works", {

    lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" ) ## PS1801L
    bt <- gamap.probe.levels( lx200.file, batch="PS1801L", use.bacteria.names=FALSE )

    new.bl <- load.get( file.path("data","rev4-candidate-2019-09-13.RData"), verbose=FALSE )

    bt2 <- gamap.probe.levels(
        lx200.file, batch="PS1801L", bacteria.table.revision=new.bl,
        check.at.qcc29.corrected.before.batch=TRUE,
        use.bacteria.names=FALSE
    )
    bt3 <- gamap.probe.levels(
        lx200.file, batch="PS1801L", bacteria.table.revision=new.bl,
        check.at.qcc29.corrected.before.batch=FALSE,
        use.bacteria.names=FALSE
    )

    expect_true( !identical(bt2,bt3) )

    ## some random samples
    x <- gamap.batchcorrect.qcc29( lx200.file, batch="PS1801L" )
    n <- c("-3", "-2", "-1", "+1", "+2", "+3" )

    ## manually check it allll
    for( r in 1:nrow(x) ) {
        for( c in 1:nrow(new.bl)) {
            pr <- new.bl$Probe[c]
            rn <- rownames(bt2)[r]
            v <- x[ rn, pr ]
            xn <- as.matrix( new.bl[ new.bl$Probe == pr, n ] )
            p <- first(which(xn>v))
            if( is.na( p ) ) {
                pp <- max( which(is.finite(xn)))+1
                ## if( pp > 6 ) pp <- 6
                res <- c(-3:-1,0,1:3)[pp]
            } else if( p<4 ){
                res <- c(-3:-1,1:3)[ p ]
            } else if( p == 4 ) {
                res <- 0
            } else {
                res <- c(-3:-1,1:3)[ p-1 ]
            }
            show_failure( expect_equal( !!res, bt2[!!rn,!!pr] ) )
        }
    }

})
