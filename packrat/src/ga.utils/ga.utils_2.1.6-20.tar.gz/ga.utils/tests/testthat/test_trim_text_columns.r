library(ga.utils)

context( "trim_text_columns" )

test_that( "text columns are trimmed in a data.frame", {

    d1 <- data.frame(
        A=c("foo", "bar ", " baz", " test "),
        B=1:4,
        stringsAsFactors=FALSE
    )

    d2 <- trim_text_columns(d1)

    expect_equal(
        d2$A, c("foo", "bar", "baz", "test")
    )

    d3 <- trim_text_columns(d2)

    expect_equal(
        d3$A, c("foo", "bar", "baz", "test")
    )

})

test_that( "text columns are trimmed in an array", {

    d1 <- cbind(
        c("foo", "bar ", " baz", " test "),
        1:4
    )

    d2 <- trim_text_columns(d1)

    expect_equal(
        d2[,1], c("foo", "bar", "baz", "test")
    )

})
