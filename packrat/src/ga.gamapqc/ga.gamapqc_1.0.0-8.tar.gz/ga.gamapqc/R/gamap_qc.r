##' GAmap QC
##'
##' QC evaluates the gamap result
##' @title GAmap QC
##' @param ... arguments passed to \code{gamap}
##' @param skip.upper.hyc don't evaluate upper HYC01 limit
##' @param qcc.is.na logical default TRUE, set QCC samples to NA. If
##' FALSE, reports them as her samples
##' @return logical, one per sample, TRUE if passed QC
##' @author Torbjørn Lindahl
##' @importFrom ga.gamap gamap
##' @export
gamap.qc <- function( ... ,
                     skip.upper.hyc=TRUE,
                     qcc.is.na=TRUE
                     ) {

    ## Initializing some variables
    plate.data <- ga.gamap::gamap( ..., stop.at = "file" )
    count.data <- attr( plate.data, "count" )
    di.num <- ga.gamap::gamap( ... )

    plate.data$Sample <- ga.gamap::translate.qcc.names( plate.data$Sample )
    names(di.num) <- ga.gamap::translate.qcc.names( names(di.num) )

    unique.plates <- unique( plate.data$Plate )
    plate.count <- length( unique.plates )

    ## Check integrity
    gamap.qc.check.integrity( plate.data, count.data, di.num )

    ## Plate QC
    plate.qc <- gamap.qc.plate.qc( plate.data, count.data, di.num )

    ## Sample QC
    sample.qc <- gamap.qc.sample.qc( plate.data, count.data, qcc.is.na=qcc.is.na )

    ## Report per sample for all plates
    qc.err.nr <- qc.err.msg <- list()
    length(qc.err.nr) <- length(qc.err.msg) <- nrow(plate.data)
    qc.result <- logical(nrow(plate.data))

    names(qc.result) <- plate.data$Sample

    for( i in 1:plate.count ) {
        ##
        p.qc <- plate.qc[[i]]
        s.qc <- sample.qc[[i]]
        ##
        j <- plate.data$Plate == unique.plates[i]
        ##
        this.qc.nr <- list()
        length(this.qc.nr) <- length(s.qc)
        this.qc.msg <- list()
        length(this.qc.msg) <- length(s.qc)
        ##
        this.qc <- rep( plate.qc[[i]], length(s.qc) ) & s.qc
        n <- attr( s.qc, "err.nrs" )
        this.qc.nr[!is.na(n)] <- n[!is.na(n)]
        m <- attr( s.qc, "err.msg" )
        this.qc.msg[!is.na(m)] <- m[!is.na(m)]
        ##
        if( !plate.qc[[i]] ) {
            this.qc.nr <- rep( list( attr( p.qc, "ErrorNumbers" ) ), length(s.qc) )
            this.qc.msg <- rep( list( attr( p.qc, "ErrorMessages" ) ), length(s.qc) )
        }
        ##
        qc.err.nr[j] <- this.qc.nr
        qc.err.msg[j] <- this.qc.msg
        qc.result[j] <- this.qc
        ##
    }

    attr( qc.result, "ErrorNumbers" ) <- qc.err.nr
    attr( qc.result, "ErrorMessages" ) <- qc.err.msg
    attr( qc.result, "PlateData" ) <- plate.data

    class( qc.result ) <- unique( append( "gamap.qc", class( qc.result ) ) )

    return( qc.result )

}

gamap.qc.plate.qc <- function( plate.data, count.data, di.num, skip.upper.hyc=TRUE ) {

    ## 1. CHECK 01 - ALL 3 QCC'S ARE PRESENT
    qc.check.01 <- gamap.qc.plate.cp.01.qcc.count( plate.data )

    ## 2. CHECK SAMPLE QCC30
    qc.check.02 <- gamap.qc.plate.cp.02.qcc30.checks( plate.data, count.data )

    ## 3. CHECK QCC23 AND QCC33
    qc.check.03.qcc23 <- gamap.qc.plate.cp.03.pos.neg.qc( plate.data, count.data, di.num, "QCC23" )
    qc.check.03.qcc33 <- gamap.qc.plate.cp.03.pos.neg.qc( plate.data, count.data, di.num, "QCC33" )

    up <- unique(plate.data$Plate)
    plate.count <- length(up)

    ## 4. Compose all sources of plate QC into one matrix.
    qc.checks <- lapply( 1:plate.count, function(i) {
        return( c(
            qc.check.01[[i]],
            qc.check.02[[i]],
            qc.check.03.qcc23[[i]],
            qc.check.03.qcc33[[i]]
            ))
    })

    ## Evaluate each plate
    ## evaluators <- ls( pattern="gamap.qc.evaluation" )
    evaluators <- c(
        "gamap.qc.evaluation.01.qcc.count",
        "gamap.qc.evaluation.02.qcc30.qc",
        "gamap.qc.evaluation.03.pos.neg.qc"
    )

    plate.qc <- lapply( 1:plate.count, function(i) {
        plate.status <- TRUE
        plt <- up[i]
        platform <- plate.data$Platform[ plate.data$Plate %in% plt ][1]
        for( ev.name in evaluators ) {
            ev.func <- get(ev.name)
            plate.status <- ev.func( qc.checks[[i]], platform=platform )
            if( !plate.status )
                break
        }
        plate.status
    })

    return( plate.qc )

}

##' @importFrom ga.utils subset_deep
##' @importFrom gdata duplicated2
gamap.qc.sample.qc <- function( plate.data, count.data, skip.upper.hyc=TRUE, qcc.is.na=TRUE ) {

    ## 1. CHECK 01 - Count
    qc.check.01 <- gamap.qc.sample.cp.01.count( count.data )

    ## 2. CHECK 02 - HYC01
    qc.check.02 <- gamap.qc.sample.cp.02.hyc( plate.data, skip.upper.hyc = skip.upper.hyc )

    ## 3. CHECK 03 - UNI05
    qc.check.03 <- gamap.qc.sample.cp.03.uni( plate.data )

    ## 4. CHECK 04 - BLANK
    qc.check.04 <- gamap.qc.sample.cp.04.bg( plate.data )

    ## 5. CHECK 05 - Duplicated names
    qc.check.05 <- as.integer( duplicated2( plate.data$Sample ) )

    ## qc.check.names <- ls( pattern="^qc\\.check\\.\\d+$" )
    ## qc.check.names <- c("qc.check.01","qc.check.02","qc.check.03","qc.check.04")
    qc.vectors <- list( qc.check.01, qc.check.02, qc.check.03, qc.check.04, qc.check.05 )
    qc.matrix <- Reduce( cbind, qc.vectors )
    qc.matrix <- cbind.data.frame( qc.matrix, Platform=plate.data$Platform, stringsAsFactors=FALSE, row.names=NULL )

    colnames(qc.matrix)[1:length(qc.vectors)] <- c( "Count","HYC01","UNI05","BLANK","Duplicated" ) ## FIX THIS TO BE DYNAMIC

    qc.eval <- gamap.qc.sample.ev.all( qc.matrix, qcc.is.na=qcc.is.na, sample.names=plate.data$Sample )

    unique.plates <- unique( plate.data$Plate )
    plate.count <- length(unique.plates)

    sample.qc <- list(); length(sample.qc) <- plate.count

    for( i in 1:plate.count ) {
        j <- plate.data$Plate == unique.plates[i]
        sample.qc[[i]] <- subset_deep( qc.eval, j )
    }

    return( sample.qc )

}

##### HELPER FUNCTIONS #####
gamap.qc.pos.neg.name <- function( qcc.name ) {

    tr <- c(
        QCC23="pos",
        QCC33="neg",
        pos="QCC23",
        neg="QCC33"
        )

    if( !qcc.name %in% names(tr) ) {
        stop( sprintf( "'%s' doesn't match any of the pos or neg controls",
                      qcc.name ) )
    }

    return( tr[qcc.name] )

}
gamap.qc.plate.applier <- function( plate.data ) {
    return( function( ... ) return( t(sapply( unique(plate.data$Plate), ... ) ) ) )
}
gamap.qc.plate.lapplier <- function( plate.data ) {
    return( function( ... ) return( lapply( unique(plate.data$Plate), ... ) ) )
}
gamap.qc.parse.qc.vector <- function( qc.vector, part, a.name ) {

    n <- names( qc.vector )
    i <- grepl( part, names(qc.vector) )

    v <- qc.vector[i]
    n2 <- n[i]

    qcc.names <- sub( "^(QCC\\d+)\\..*", "\\1", n2 )

    dd <- data.frame( data=v, qcc=qcc.names, stringsAsFactors = FALSE )

    if( !missing( a.name ) ) {
        dd <- dd[ grepl( a.name, dd$qcc ), ]
    }

    return( dd )

}
gamap.qc.check.integrity <- function( plate.data, count.data, di.num ) {

### Checks that di.num is integer, that count.data and plate.data
### has same names, that rowcount of plate.data and count.data is
### the same and that the qc.set is the only allowed option

    ## Control checks
    ## if( !all.equal( ceiling(di.num), as.numeric(di.num), check.attributes = FALSE ) %in% TRUE )
    ##     stop( "di.num does not seem to be integer values" )

    if( !identical( names(plate.data), names(count.data) ) )
        stop( "names of plate.data and count.data must be identical" )

    stopifnot( identical( nrow(plate.data), nrow(count.data) ) )

}

########## PLATE QC #########

######## CHECKPOINTS ########
## PL-CP 01: This function checks that there is at least 1 QCCX per plate
gamap.qc.plate.cp.01.qcc.count <- function( plate.data ) {

    ## It returns one bool per QCC that is TRUE if its found on plate
    qcc.names <- c("QCC23","QCC33","QCC30")

    plate.apply <- gamap.qc.plate.lapplier( plate.data )

    plate.qc.qcc.counts <- plate.apply( function(plate) {
        ps <- sub( ".*(QCC\\d+).*", "\\1", as.character(plate.data$Sample)[plate.data$Plate %in% plate ] )
        ps.s <- summary(as.factor(ps))
        qcc.i <- ps.s[qcc.names]
        names(qcc.i) <- paste0( qcc.names, ".count.on.plate" )
        qcc.i[is.na(qcc.i)] <- 0
        ## return( qcc.i >= qcc.counts )
        return( qcc.i )
    })

    return( plate.qc.qcc.counts )

}

## PL-CP 02: Chec Hyc, Uni and profile completness
##' @importFrom ga.data gamap.qc.ranges probe.re
gamap.qc.plate.cp.02.qcc30.checks <- function( plate.data, count.data ) {

    ## Does the following:
    ## 1. Checks that QCC30 has at least one valid HYC01
    ## 2. Checks that there is a value for each probe on remaining

    plate.apply <- gamap.qc.plate.lapplier( plate.data )

    i.probes <- grepl( probe.re( include.technical=TRUE ), names(plate.data) )

    plate.qc.qcc30.checks <- plate.apply( function(plate) {

        i.plate <- plate.data$Plate == plate

        ## Fetch current platform from the first sample entry on the plate
        qc.ranges <- gamap.qc.ranges( platform=plate.data$Platform[i.plate][1] )

        i.probes.bio <- grepl( probe.re(), names(plate.data) )
        if( length(qc.ranges$skip.probes) ) {
            i.probes.bio <- i.probes.bio & !colnames(plate.data) %in% qc.ranges$skip.probes
        }

        i.qcc30 <- grepl( "^QCC30", plate.data$Sample )
        i.qcc30.and.plate <- i.qcc30 & i.plate
        i.qcc29 <- grepl( "^QCC29", plate.data$Sample )
        i.qcc29.and.plate <- i.qcc29 & i.plate

        ## At least one QCC30 has HYC01 in range
        qcc30.control.data <- plate.data[ i.qcc30.and.plate, !i.probes ]
        qcc30.probe.data   <- plate.data[ i.qcc30.and.plate,  i.probes ]
        qcc30.probe.data.bio <- plate.data[ i.qcc30.and.plate,  i.probes.bio ]
        qcc30.count.data   <- count.data[ i.qcc30.and.plate,  i.probes ]

        qcc29.probe.data   <- plate.data[ i.qcc29.and.plate,  i.probes ]
        qcc29.probe.data.bio <- plate.data[ i.qcc29.and.plate,  i.probes.bio ]

        missing.probes <- sum(
            apply(
                qcc30.probe.data.bio[,
                                 grepl( probe.re(),
                                       colnames(qcc30.probe.data.bio))
                                 ], 2, function(r) any(!is.na(r)) == 0 )
        )


        ## Prepare vectors with HYC01, UNI05 and Probes with missing values
        hyc01 <- qcc30.probe.data[,"HYC01"]
        if( length(hyc01) )
            names( hyc01 ) <- paste0( "QCC30.HYC01.", seq_along(hyc01) )

        uni05 <- qcc30.probe.data[,"UNI05"]
        if( length(uni05) )
            names( uni05 ) <- paste0( "QCC30.UNI05.", seq_along(uni05) )

        totsum <- rowSums( qcc30.probe.data, na.rm=TRUE )
        if( length(totsum) )
            names(totsum) <- paste0( "QCC30.TS.", seq_along(totsum) )

        totsum.qcc29 <- rowSums( qcc29.probe.data.bio, na.rm=FALSE )
        if( length(totsum.qcc29) )
            names(totsum.qcc29) <- paste0( "QCC29.TS.", seq_along(totsum.qcc29) )

        names(missing.probes) <- "QCC30.missing.values"

        r <- c(
            hyc01,
            uni05,
            totsum,
            missing.probes,
            totsum.qcc29
            )

        ## names(r) <- sub( ".*?\\.", "", names(r) )
        return(r)

    })

    return( plate.qc.qcc30.checks )

}

## PL-CP 03: At least one of the 2 QCCx3 passes its own QC and DI is ok
##' @importFrom ga.data gamap.qc.ranges
gamap.qc.plate.cp.03.pos.neg.qc <- function( plate.data,
                                            count.data,
                                            di.num,
                                            qcc.name
                                            ) {

    plate.apply <- gamap.qc.plate.lapplier( plate.data )

    ## ctrl.type <- gamap.qc.pos.neg.name( qcc.name )
    ## di.valid <- unlist( qc.ranges[ paste(capitalize(ctrl.type),"Ctrl","valid",sep=".") ] )

    qccX3.check <- plate.apply( function(plate) {

        i.this.qcc <- grepl( paste0("^",qcc.name), plate.data$Sample ) & plate.data$Plate == plate

        pf <- plate.data$Platform[ plate.data$Plate == plate ][1]

        qc.ranges <- gamap.qc.ranges( pf )

        pd <- plate.data[, grepl( probe.column.re(), names(plate.data) ) ]
        cd <- count.data[, grepl( probe.column.re(), names(count.data) ) ]

        pd[ cd < qc.ranges$BeadCount.lower ] <- NA

        ## A range of QC tests is done for all qccX samples per
        ## plate. At least one sample must pass on all. QC issues must
        ## be collected per single qcc sample and then evaluated. So
        ## this routine starts with this.

        ## 0. the plate index
        ## qcc.plate.i <- plate.data$Plate[i.this.qcc]

        ## a. check count <3
        i.bio <- grepl( bio.probe.column.re(), colnames(pd) )

        if( length(qc.ranges$skip.probes) ) {
            i.bio <- i.bio & !colnames(pd) %in% qc.ranges$skip.probes
        }

        lowest.qcc.count.i <- apply( cd[ i.this.qcc, i.bio, drop=FALSE ], 1, min )
        names( lowest.qcc.count.i ) <- NULL

        ## b. hyc01 in range
        ## qcc.hyc01.in.range.i <- plate.data[ i.this.qcc, "HYC01" ] %between% qc.ranges$HYC01.range
        qcc.hyc01.i <- pd[ i.this.qcc, "HYC01" ]

        ## c. uni05 above limit
        ## qcc.uni05.above.limit.i <- plate.data[ i.this.qcc, "UNI05" ] > qc.ranges$UNI05.lower
        qcc.uni05.i <- pd[ i.this.qcc, "UNI05" ]

        ## d. blank below bg
        ## qcc.bg.i <- apply( plate.data[ i.this.qcc, grepl("^BLANK[12]",colnames(plate.data)) ], 1, function(r) {
        ##     nr <- na.omit(r)
        ##     length(nr) && all( nr <= qc.ranges$Background.upper )
        ## })
        qcc.highest.bg.i <- apply(
            pd[ i.this.qcc, grepl("^BLANK[12]",colnames(pd)), drop=FALSE ], 1,
            function(r) {
                if( all(is.na(r) ) )
                    return(NA)
                else
                    return( max(r,na.rm=TRUE) )
            })


        ## e. di
        qcc.di.i <- di.num[i.this.qcc]

        r <- rbind(
            LowCount=lowest.qcc.count.i,
            HYC01=qcc.hyc01.i,
            UNI05=qcc.uni05.i,
            HighBG=qcc.highest.bg.i,
            DI=qcc.di.i
            )
        rn <- rownames(r)
        jj <- rep( 1:ncol(r), each=nrow(r) )
        r <- as.numeric(r)

        if( length(r) )
            names(r) <- paste( qcc.name, jj, rn, sep="." )

        return( r )

    })

    return( qccX3.check )

}

######## EVALUATIONS ########
## PL-EV 01: Check QCC counts
##' @importFrom ga.data gamap.qc.ranges
gamap.qc.evaluation.01.qcc.count <- function( qc.vector, platform ) {

    qc.ranges <- gamap.qc.ranges( platform=platform )

    count.limits <- qc.ranges$QCC.counts

    qc.error.numbers <- integer()
    qc.error.messages <- character()

    qc.name.message.map <- list(
        "QCC23" = 1,
        "QCC33" = 2,
        "QCC30" = 3
        )

    ## checks qcc sample counts and reports errors if not
    for( qcc.name in names(count.limits) ) {
        limit.i <- count.limits[[qcc.name]]
        count.i <- gamap.qc.parse.qc.vector( qc.vector, "count.on.plate", qcc.name )
        if( nrow(count.i) == 0 || count.i$data < limit.i ) {
            err.nr <- qc.name.message.map[[qcc.name]]
            qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
            qc.error.numbers <- append( qc.error.numbers, err.nr )
        }
    }

    ret <- length(qc.error.messages) == 0

    if(!ret) {
        attr( ret, "ErrorNumbers" ) <- qc.error.numbers
        attr( ret, "ErrorMessages" ) <- qc.error.messages
    }

    return( ret )

}

## PL-EV 02: Evaluate QCC30 QC
##' @importFrom ga.data gamap.qc.ranges
gamap.qc.evaluation.02.qcc30.qc <- function( qc.vector, platform, skip.upper.hyc=TRUE ) {

    qc.ranges <- gamap.qc.ranges( platform=platform, skip.upper.hyc = skip.upper.hyc )

    qcc30.hyc <- gamap.qc.parse.qc.vector( qc.vector, "^QCC30\\.HYC" )
    qcc30.uni <- gamap.qc.parse.qc.vector( qc.vector, "^QCC30\\.UNI" )
    qcc30.comp <- gamap.qc.parse.qc.vector( qc.vector, "^QCC30\\.missing\\.values" )
    qcc30.ts <- gamap.qc.parse.qc.vector( qc.vector, "^QCC30\\.TS" )
    qcc29.ts <- gamap.qc.parse.qc.vector( qc.vector, "^QCC29\\.TS" )

    if( !identical( dim(qcc30.hyc), dim(qcc30.uni) ) )
        stop( "HYC01 data and UNI05 data don't have the same dimensions. They should have" )
    if( !identical( dim(qcc30.hyc), dim(qcc30.ts) ) ) {
        stop( "HYC01 data and TS data don't have the same dimensions. They should have" )
    }

    qcc30.hyc$ok <- with( qcc30.hyc, !is.na(data) & data %between% qc.ranges$QCC30.HYC01.range )
    qcc30.uni$ok <- with( qcc30.uni, !is.na(data) & data > qc.ranges$QCC30.UNI05.lower )
    qcc30.ts$ok <- with( qcc30.ts , !is.na(data) & data %between% qc.ranges$QCC30.total.signal )
    if( is.finite( qc.ranges$QCC29.total.signal.bio[2] ) ) {
        qcc29.ts$ok <- with( qcc29.ts , !is.na(data) & data %between% qc.ranges$QCC29.total.signal.bio )
    } else if( nrow(qcc29.ts) ) {
        qcc29.ts$ok <- TRUE
    }

    qcc30.comp$ok <- with( qcc30.comp, data %in% 0 )

    hyc.and.uni.and.ts <- qcc30.hyc$ok & qcc30.uni$ok & qcc30.ts$ok

    ret <- any( hyc.and.uni.and.ts ) && all(qcc30.comp$ok) && all(qcc29.ts$ok)

    ## hyc gives Err07_HybridisationErrorQC30
    ## uni gives Err21_TargetMaterialMedianQC30

    qcc30.uni.error <- 21
    qcc30.hyc.error <- 7

    qcc30.ts.low <- 24
    qcc30.ts.high <- 25

    qcc29.ts.low <- 26
    qcc29.ts.high <- 27

    ## No complete QCC30 profile:
    qcc30.not.complete.profile <- 11 ## count

    if( !ret ) {

        qc.error.numbers <- integer()
        qc.error.messages <- character()

        if( !qcc30.comp$ok ) {
            qc.error.numbers <- append( qc.error.numbers, qcc30.not.complete.profile )
            qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(qcc30.not.complete.profile) )
        }
        else {
            if( any(!qcc30.uni$ok) ) {

                err.nr <- qcc30.uni.error
                qc.error.numbers <- append( qc.error.numbers, err.nr )
                qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )

            }
            if( any(!qcc30.ts$ok) ) {

                ts.low <- qc.ranges$QCC30.total.signal[1]
                ts.high <- qc.ranges$QCC30.total.signal[2]

                if( any( qcc30.ts$data < ts.low )) {
                    err.nr <- qcc30.ts.low
                    qc.error.numbers <- append( qc.error.numbers, err.nr )
                    qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
                }
                if( any( qcc30.ts$data > ts.high )) {
                    err.nr <- qcc30.ts.high
                    qc.error.numbers <- append( qc.error.numbers, err.nr )
                    qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
                }

            }
            if( any(!qcc30.hyc$ok & qcc30.uni$ok )) {

                err.nr <- qcc30.hyc.error
                qc.error.numbers <- append( qc.error.numbers, err.nr )
                qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )

            }
            if( any(!qcc30.ts$ok) ) {

                ts.low <- qc.ranges$QCC30.total.signal[1]
                ts.high <- qc.ranges$QCC30.total.signal[2]

                if( any( qcc30.ts$data < ts.low )) {
                    err.nr <- qcc30.ts.low
                    qc.error.numbers <- append( qc.error.numbers, err.nr )
                    qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
                }
                if( any( qcc30.ts$data > ts.high )) {
                    err.nr <- qcc30.ts.high
                    qc.error.numbers <- append( qc.error.numbers, err.nr )
                    qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
                }


            }
            if( nrow(qcc29.ts)>0 && any(!qcc29.ts$ok) ) {

                ts.low <- qc.ranges$QCC29.total.signal.bio[1]
                ts.high <- qc.ranges$QCC29.total.signal.bio[2]

                if( any( qcc29.ts$data < ts.low )) {
                    err.nr <- qcc29.ts.low
                    qc.error.numbers <- append( qc.error.numbers, err.nr )
                    qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
                }
                if( any( qcc29.ts$data > ts.high )) {
                    err.nr <- qcc29.ts.high
                    qc.error.numbers <- append( qc.error.numbers, err.nr )
                    qc.error.messages <- append( qc.error.messages, gamap.qc.error.message(err.nr) )
                }


            }

        }

        key <- paste( qc.error.numbers, qc.error.messages )
        j <- duplicated( key )
        if( any( j ) ) {
            qc.error.numbers <- qc.error.numbers[!j]
            qc.error.messages <- qc.error.messages[!j]
        }

        attr( ret, "ErrorNumbers" ) <- qc.error.numbers
        attr( ret, "ErrorMessages" ) <- qc.error.messages

    }

    return( ret )

}
## PL-EV 03: Evaluate Pos/Neg controls
##' @importFrom ga.gamap kit.name.from.qcc.name
##' @importFrom ga.data gamap.qc.ranges
gamap.qc.evaluation.03.pos.neg.qc <- function( qc.vector, platform, skip.upper.hyc=TRUE ) {

    qc.ranges <- gamap.qc.ranges( platform=platform, skip.upper.hyc = skip.upper.hyc )

    qc.name.message.map <- list(
        "QCC23" = list(
        count = 9,
        hyc01 = 5,
        uni05 = 13,
        blank = 16,
        class = 18,
        generic = 22
        ),
        "QCC33" = list(
        count = 10,
        hyc01 = 6,
        uni05 = 14,
        blank = 17,
        class = 19,
        generic = 23
        )
    )

    filter.out <- function( qc.data, rep.count ) {
        i <- grepl( paste0("\\.", rep.count, "\\."), rownames(qc.data) )
        ## qc.data$data[i] <- NA
        return( qc.data[!i,] )
    }
    match.data.point <- function( qc.data, rep.count, rxp ) {
        rn <- rownames(qc.data)
        i <- grep( paste0("\\.", rep.count, "\\.", rxp ), rn )
        return( i )
    }

    qccX3.all.errors <- list()

    for( qcc.name in c("QCC23","QCC33") ) {

        qccX3.qc.errors <- list()

        qc.nr.map <- qc.name.message.map[[qcc.name]]
        if( is.null(qc.nr.map) ){
            stop( paste( "Didnt find QC numbers for sample", qcc.name ) )
        }

        qc.data <- gamap.qc.parse.qc.vector( qc.vector, paste0(qcc.name,"\\.\\d\\."), qcc.name )
        rn <- rownames(qc.data)

        rep.counts <- unique( sub( ".*\\.(\\d)\\..*", "\\1", rn ) )

        for( rep.count in rep.counts ) {

            ## Count
            i.count <- match.data.point( qc.data, rep.count, "LowCount" )
            if( is.na(qc.data$data[i.count]) || qc.data$data[i.count] < qc.ranges$BeadCount.lower ) {
                err.nr <- qc.nr.map$count
                qc.data <- filter.out( qc.data, rep.count )
                msg <- sprintf( gamap.qc.error.message(err.nr), ga.gamap::kit.name.from.qcc.name(qcc.name) )
                qccX3.qc.errors[["Count"]] <- list( err.nr, msg )
                next
            }
            if( !nrow(qc.data) ) break

            ## HYC01
            i.hyc <- match.data.point( qc.data, rep.count, "HYC01" )
            if( is.na(qc.data$data[i.hyc]) || !qc.data$data[i.hyc] %between% qc.ranges$HYC01.range ) {
                ## err.nr <- ifelse( is.na(qc.data$data[i.hyc]), qc.nr.map$count, qc.nr.map$hyc )
                err.nr <- qc.nr.map$hyc01
                qc.data <- filter.out( qc.data, rep.count )
                msg <- sprintf( gamap.qc.error.message(err.nr), ga.gamap::kit.name.from.qcc.name(qcc.name) )
                qccX3.qc.errors[["HYC01"]] <- list( err.nr, msg )
                next
            }
            if( !nrow(qc.data) ) break

            ## UNI05
            i.uni <- match.data.point( qc.data, rep.count, "UNI05" )
            if( is.na(qc.data$data[i.uni]) || qc.data$data[i.uni] < qc.ranges$UNI05.lower ) {
                ## err.nr <- ifelse( is.na(qc.data$data[i.uni]), qc.nr.map$count, qc.nr.map$uni05 )
                err.nr <- qc.nr.map$uni05
                qc.nr.map$generic
                qc.data <- filter.out( qc.data, rep.count )
                msg <- sprintf( gamap.qc.error.message(err.nr), ga.gamap::kit.name.from.qcc.name(qcc.name) )
                qccX3.qc.errors[["UNI05"]] <- list( err.nr, msg )
                next
            }
            if( !nrow(qc.data) ) break

            ## BLANK
            i.blank <- match.data.point( qc.data, rep.count, "HighBG" )
            if( !is.infinite(qc.ranges$Background.upper) && is.na(qc.data$data[i.blank]) ||
                !is.na(qc.data$data[i.blank]) && qc.data$data[i.blank] > qc.ranges$Background.upper ) {

                ## err.nr <- ifelse( is.na(qc.data$data[i.blank]), qc.nr.map$count, qc.nr.map$blank )
                err.nr <- qc.nr.map$blank
                qc.data <- filter.out( qc.data, rep.count )
                msg <- sprintf( gamap.qc.error.message(err.nr), ga.gamap::kit.name.from.qcc.name(qcc.name) )
                qccX3.qc.errors[["BLANK"]] <- list( err.nr, msg )
                next
            }
            if( !nrow(qc.data) ) break

        }

        if(!nrow(qc.data)) {
            ## If no qc.data survived this, it means QC did not pass
            ## qccX3.all.errors[[qcc.name]] <- qccX3.qc.errors
            err.nr <- qc.name.message.map[[qcc.name]]$generic
            msg <- sprintf( gamap.qc.error.message(err.nr), ga.gamap::kit.name.from.qcc.name(qcc.name) )
            qccX3.all.errors[[qcc.name]] <- list( generic=list( err.nr, msg ) )
        }
        else {
            ##  heck that all QC passing samples have valid DI
            ctrl.type <- gamap.qc.pos.neg.name( qcc.name ) ## 'pos' or 'neg'

            di.range <- unlist( qc.ranges[ paste(ga.utils::capwords(ctrl.type),"Ctrl",c("lower","upper"),sep=".") ] )

            i.di <- match.data.point( qc.data, "\\d+", "DI" )
            di.i <- qc.data$data[i.di]

            ## If the DI's are all NA, or if any of them is out of range, then an error
            if( all(is.na(di.i)) | (any( (di.i >= di.range[1] & di.i <= di.range[2]) %in% FALSE)) ) {
                err.nr <- qc.nr.map$class
                msg <- sprintf( gamap.qc.error.message(err.nr), kit.name.from.qcc.name(qcc.name) )
                qccX3.all.errors[[qcc.name]] <- list( DI=list( err.nr, msg ) )
            }
        }

    }

    ret <- length(qccX3.all.errors) == 0

    if(!ret) {

        qc.error.numbers <- integer()
        qc.error.messages <- character()

        for( l in qccX3.all.errors ) {

            for( el in l ) {
                qc.error.numbers <- append( qc.error.numbers, el[[1]] )
                qc.error.messages <- append( qc.error.messages, el[[2]] )
            }

        }

        i <- duplicated( qc.error.numbers )

        attr( ret, "ErrorNumbers" ) <- qc.error.numbers[!i]
        attr( ret, "ErrorMessages" ) <- qc.error.messages[!i]

    }

    return( ret )

}

########## SAMPLE QC ########

## SM-CP 01: Process bead count
##' @importFrom foreach foreach
##' @importFrom foreach %do%
##' @importFrom ga.data lx200.missing.probes probe.re
gamap.qc.sample.cp.01.count <- function( count.data ) {

    ## requires valid count for all probes, and at least one of othe blanks
    probe.re <- "^([AI]G\\d{4}|UNI05|HYC01)$"

    up <- unique( count.data$Plate )

    p <- NULL ## so check() doesn't complain
    sample.vectors <- foreach( p=up, .combine = c ) %do% {

        i.p <- count.data$Plate == p
        platform <- count.data$Platform[i.p][1]

        i.probes <- grepl( probe.re, colnames(count.data) )

        if( platform == "lx200" ) {
            i.probes <- i.probes & !colnames(count.data) %in% lx200.missing.probes()
        }

        cd1 <- count.data[i.p,i.probes]

        if( platform == "lx200" ) {
            cd2 <- array( Inf, dim=c( sum(i.p),2) )
        } else {
            cd2 <- count.data[i.p,grepl( "^BLANK\\d$", names(count.data) )]
        }

        ## cd1.vector <- apply( cd1, 1, function(r){ !anyNA(r) && all(r) } )
        cd1.vector <- apply( cd1, 1, min )
        cd2.vector <- apply( cd2, 1, max )

        sample.vector <- apply( cbind(cd1.vector,cd2.vector), 1, min )
        names(sample.vector) <- count.data$Sample[i.p]

        sample.vector

    }

    return( sample.vectors )

}
## SM-CP 02: Process HYC01
gamap.qc.sample.cp.02.hyc <- function( plate.data, skip.upper.hyc=TRUE ) {

    ## requires valid count for all probes, and at least one of othe blanks
    ## sample.vector <- plate.data[,"HYC01"] %between% qc.ranges$HYC01.range
    sample.vector <- plate.data[,"HYC01"]

    ## i.qcc <- grepl( "^QCC", count.data$Sample )
    ## sample.vector[i.qcc] <- NA

    names(sample.vector) <- plate.data$Sample

    return( sample.vector )

}
## SM-CP 03: Process UNI05
gamap.qc.sample.cp.03.uni <- function( plate.data ) {

    ## requires valid count for all probes, and at least one of othe blanks
    ## sample.vector <- plate.data[,"UNI05"] >= qc.ranges$UNI05.lower
    sample.vector <- plate.data[,"UNI05"]

    ## i.qcc <- grepl( "^QCC", count.data$Sample )
    ## sample.vector[i.qcc] <- NA

    names(sample.vector) <- plate.data$Sample

    return( sample.vector )

}

## SM-CP 04: Process BLANK
##' @importFrom foreach foreach
##' @importFrom foreach %do%
gamap.qc.sample.cp.04.bg <- function( plate.data ) {

    ## requires valid count for all probes, and at least one of othe blanks
    ## blank.matrix <- plate.data[,grepl("^BLANK\\d+$",names(plate.data))] <= qc.ranges$Background.upper
    up <- unique( plate.data$Plate )

    p <- NULL ## so check() doesn't complain
    sample.vectors <- foreach( p=up, .combine = c ) %do% {

        i.p <- plate.data$Plate == p
        platform <- plate.data$Platform[i.p][1]

        if( platform == "lx200" ) {
            blank.matrix <- matrix( 0, nrow=sum(i.p) )
        } else {
            blank.matrix <- plate.data[i.p,grepl("^BLANK\\d+$",names(plate.data))]
        }

        sample.vector <- apply( blank.matrix, 1, function(r) {
            if( all(is.na(r)) ) return( NA )
            return( max(r,na.rm=TRUE) )
        })

    }

    names(sample.vectors) <- plate.data$Sample

    return( sample.vectors )

}

######## EVALUATIONS ########
## SM-EV 01: Evaluate All

##' @importFrom ga.utils "%between%"
##' @importFrom ga.data gamap.qc.ranges
gamap.qc.sample.ev.all <- function( qc.matrix, skip.upper.hyc=TRUE, qcc.is.na=TRUE, sample.names ) {

    ## assuming columns Count, Hyc, Uni, Blank

    err.nrs.others <- c(
        Count=8,
        HYC01=4,
        UNI05=12,
        BLANK=15,
        Duplicated=20
        )

    err.nrs.db <- list(
        "QCC30"=c(
            Count=11,
            HYC01=7,
            UNI05=21
        ),
        "QCC23"=c(
            Count=9,
            HYC01=5,
            UNI05=13,
            BLANK=16
        ),
        "QCC33"=c(
            Count=10,
            HYC01=6,
            UNI05=14,
            BLANK=17
        )
    )

    rn <- sample.names
    if( qcc.is.na ) {
        i.qcc <- grepl( "^QCC", rn )
    }
    else {
        i.qcc <- rep( FALSE, length(rn) )
    }

    qc.result <- qc.err.msg <- qc.err.nr <- rep( NA, nrow(qc.matrix) )

    jj <- which(!i.qcc)

    for( i in jj ) {

        n <- sub( "^(QCC(?:23|33|30|29))_[A-Z].*", "\\1", rn[i] )

        platform <- qc.matrix$Platform[i]
        qc.ranges <- gamap.qc.ranges( skip.upper.hyc=skip.upper.hyc, platform=platform )

        if( n %in% names(err.nrs.db) ) {
            err.nrs <- err.nrs.db[[n]]
        } else {
            err.nrs <- err.nrs.others
        }

        r <- qc.matrix[i,]

        if( r["Count"] < qc.ranges$BeadCount.lower ) {
            qc.result[i] <- FALSE
            qc.err.nr[i] <- as.numeric( err.nrs["Count"] )
            qc.err.msg[i] <- gamap.qc.error.message(err.nrs["Count"], rn[i])
            next
        }

        ## if( anyNA( r[c("HYC01","UNI05","BLANK")]) ) {
        ##     stop( "Should not have missing values in data if count is ok" )
        ## }

        if( r["Duplicated"] != 0 ) {
            qc.result[i] <- FALSE
            err.nr <- qc.err.nr[i] <- as.numeric( err.nrs.others["Duplicated"] )
            qc.err.msg[i] <- gamap.qc.error.message( err.nr, rn[i] )
            next
        }
        if( is.na( r["HYC01"] ) || !r["HYC01"] %between% (qc.ranges$HYC01.range) ) {
            qc.result[i] <- FALSE
            qc.err.nr[i] <- as.numeric( err.nrs["HYC01"] )
            qc.err.msg[i] <- gamap.qc.error.message(err.nrs["HYC01"], rn[i])
            next
        }
        if( is.na( r["UNI05"] ) || r["UNI05"] < qc.ranges$UNI05.lower ) {
            qc.result[i] <- FALSE
            qc.err.nr[i] <- as.numeric( err.nrs["UNI05"] )
            qc.err.msg[i] <- gamap.qc.error.message(err.nrs["UNI05"], rn[i])
            next
        }
        if( !is.na(r["BLANK"]) && r["BLANK"] > qc.ranges$Background.upper & n != "QCC30" ) {
            qc.result[i] <- FALSE
            qc.err.nr[i] <- as.numeric( err.nrs["BLANK"] )
            qc.err.msg[i] <- gamap.qc.error.message(err.nrs["BLANK"], rn[i])
            next
        }

        qc.result[i] <- TRUE

    }

    attr( qc.result, "err.nrs" ) <- qc.err.nr
    attr( qc.result, "err.msg" ) <- qc.err.msg

    return( qc.result )

}

probe.column.re <- function()"^([AI]G\\d+|BLANK\\d+|HYC01|UNI05)$"
bio.probe.column.re <- function()"^([AI]G\\d+)$"
gamap.qc.error.message <- function(n, string) {

    messages <- list(
      "1" = "Kit ctrl pos not included in analysis",
      "2" = "Kit ctrl neg not included in analysis",
      "3" = "End labeling ctrl pos not included in analysis",
      "4" = "Not sufficient hybridization for sample %s",
      "5" = "Not sufficient hybridization for sample Kit ctrl pos",
      "6" = "Not sufficient hybridization for sample Kit ctrl neg",
      "7" = "Not sufficient hybridization for the End-labeling ctrl pos",
      "8" = "Not sufficient bead counts for sample %s",
      "9" = "Not sufficient bead counts for sample Kit ctrl pos",
      "10" = "Not sufficient bead counts for sample Kit ctrl neg",
      "11" = "Not sufficient bead counts for sample End-labeling ctrl pos",
      "12" = "Not sufficient target material for sample ",
      "13" = "Not sufficient target material for sample Kit ctrl pos",
      "14" = "Not sufficient target material for sample Kit ctrl neg",
      "15" = "Background too high for sample ",
      "16" = "Background too high for sample Kit ctrl pos",
      "17" = "Background too high for sample Kit ctrl neg",
      "18" = "Wrong classification of sample Kit ctrl pos",
      "19" = "Wrong classification of sample Kit ctrl neg",
      "20" = "Duplicated sample found on plate",
      "21" = "End-labeling ctrl pos template not present",
      "22" = "Control sample failure Kit ctrl pos",
      "23" = "Control sample failure Kit ctrl neg",
      "24" = "End Labeling Control Positive total signal below limit",
      "25" = "End Labeling Control Positive total signal above limit",
      "26" = "End Labeling Control Negative total signal below limit",
      "27" = "End Labeling Control Negative total signal above limit",
      "50" = "QC or parse failure"
      )

    if(!paste0(n) %in% names(messages) ) {
        stop( "Error message not defined: ", n )
    }

    msg <- messages[[paste0(n)]]

    if( grepl( "%s", msg ) && !missing(string) ){
        msg <- sprintf( msg, string )
    }

    return( msg )

}
