##' probe<->phylum<->number<->bacteria mapping
##'
##' A simple data frame that maps between different representations
##' typically used in software/customer related reporting.
##' @format A data.frame with 4 columns
##' \describe{
##'     \item{Probe}{AG/IG code}
##'     \item{Phylum}{Taxonomic phylum}
##'     \item{ProbeNumber}{3-digit code, coding for phylum}
##'     \item{NameOnReport}{String shown on report for this probe}
##' }
##' @export
"bacteria.report.name.mapping"
