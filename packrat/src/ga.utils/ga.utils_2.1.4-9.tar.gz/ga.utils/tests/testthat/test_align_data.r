library(ga.utils)

context( "align.columns" )

test_that( "data gets aligned", {

    src <- matrix(
        1:20, nrow=2,
        dimnames=list( NULL, LETTERS[10:1] )
    )

    trg <- matrix(
        1:20, nrow=2,
        dimnames=list( NULL, LETTERS[1:10] )
    )

    al <- align.columns( src, trg )

    expect_false(
        identical(
            dimnames(src),
            dimnames(trg)
        )
    )

    expect_equal(
        dimnames(al),
        dimnames(trg)
        )

    src2 <- structure( 1:10, names=LETTERS[10:1] )
    trg2 <- structure( 1:10, names=LETTERS[1:10] )

    al2 <- align.columns( src2, trg2 )

    expect_false(
        identical(
            names(src2), names(trg2)
        )
    )

    expect_equal(
        dimnames(al),
        dimnames(trg)
        )

})
