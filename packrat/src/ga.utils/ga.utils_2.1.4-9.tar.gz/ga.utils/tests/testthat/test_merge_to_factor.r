library(ga.utils)

context( "merge.to.factor" )

test_that( "it generates a factor", {

    f1 <- merge.to.factor( A=c(T,T,T,F), B=c(F,F,F,T) )

    expect_equal(
        f1,
        as.factor( c("A","A","A","B") )
    )

})
