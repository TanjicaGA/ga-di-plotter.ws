##' dysbiosis.contribution
##'
##' Calculates an estimate of how much a probe contributes to dysbiosis in samples
##' @title Dysbiosis Contribution
##' @param ... same arguments as \\code{gamap} takes to calculate dysbiosis index
##' @return matrix with probe contributions per probe reported for each sample
##' @author Torbjørn Lindahl
##' @export
##' @importFrom pls loadings
##' @importFrom ga.data model.pca
dysbiosis.contribution <- function( ... ) {

    pca <- ga.data::model.pca()
    l <- pls::loadings( pca )

    ## di.bg     <- dysbiotic.algorithm( stop.at ="bg", ... )
    ## di.batch <- gamap( stop.at ="batch", ... )

    di.scores <- gamap( ..., stop.at = "scores" )
    di.t2res  <- gamap( ..., stop.at = "t2res" )

    t2 <- di.t2res$T2
    qres <- di.t2res$Qres

    x.new.centered <- attr( di.scores, "x.centered" )

    x.pred <- di.scores %*% t(l)
    x.res <- x.pred - x.new.centered

    n.samples <- nrow(di.scores)

    pe <- probe.effect(x.pred, x.res, t2, qres)

    class( pe ) <- c( class(pe), "dysbiosiscontribuition")

    return( pe )

}

probe.effect <- function( x.pred, x.res, t2, qres ){

    if( ! identical( names(x.pred), names(x.res) ) )
      stop("Input vectors must be properly aligned")

    di.l <- list(
        T2 = t2.limit(),
        Qres = qres.limit()
    )

    qres.p <- probe.effect.qres( x.res ) *
      qres / di.l$Qres[1]

    t2.p <- probe.effect.t2( x.pred ) *
      t2 / di.l$T2[1]

    probe.effects <- t2.p + qres.p

    attr( probe.effects, "t2" ) <- t2.p
    attr( probe.effects, "qres" ) <- qres.p

    return( probe.effects )

}
probe.effect.qres <- function( x.res ) {

    if( is.null(dim(x.res)) )
      x.res <- matrix( x.res, nrow=1 )

    r <- x.res**2

    r <- r / rowSums( r )

    return( r )

}
probe.effect.t2 <- function( x.pred ){

    if( is.null(dim(x.pred)) )
      x.pred <- matrix( x.pred, nrow=1 )

    p <- x.pred**2

    p <- p / rowSums( p )

    return( p )

}

##' plot dysbiosis contribution
##'
##' Plots the dysbiosis contribution for a given sample
##' @title plot dysbiosis contribution
##' @param obj matrix, or a vector, of dysbiosis contribution as
##'     claculated by the \code{dysbiosis.contribution}. (This
##'     is just a plain matrix)
##' @param sample which sample to plot, something that can be used to
##'     look up one sample in x, ie either a matching rownames if x
##'     has dimensions, or a number of a logical with exactly one TRUE
##'     value.
##' @param di.limit di contribution limit above which to show all
##'     probes
##' @param main title of plot
##' @param ylab ylab of plot
##' @param xlab xlab of plot
##' @param cex.id cex argument to the text labels above each probe
##' @param ylim ylim to plot
##' @param use.bacteria.names logical default TRUE, show probe codes
##'     or bacteria names
##' @param mark.these regardless of result, show these probes
##' @param minimum.marked regardless of result, show at least this
##'     many probes, sorting from highest value
##' @param add add to an existing plot
##' @param ... arguments to and from functions
##' @return NULL
##' @author Torbjørn Lindahl
##' @importFrom ga.data bacteria.names
##' @importFrom graphics strwidth
##' @importFrom graphics strheight
##' @export
plot_dysbiosiscontribution <- function( obj, sample, di.limit=.7, main="Probe Effect", ylab, xlab, cex.id=0.75, ylim, use.bacteria.names=TRUE, mark.these, minimum.marked=3, add=FALSE, ... ) {

    if( is.null(dim(obj)) )
        labels.id <- names(obj)
    else
        labels.id <- colnames(obj)

    if( missing(sample) ) {
        if( is.null(dim(obj)) )
            sample <- 1
        else {
            sample <- grep("^QCC", rownames(obj), invert=TRUE )[1]
            if( is.na(sample) )
                sample <- 1
        }
    }

    if( is.null(dim(obj)) )
        row <- obj[sample]
    else
        row <- obj[sample,,drop=FALSE]

    if( nrow(row) > 1 ) {
        stop( sprintf( "Currently only supports ploting one sample, %d samples matched from the 'sample' argument" ) )
    }
    else if( nrow(row) == 0 ) {
        stop( "No samples matched from the sample argument, need to match exactly 1" )
    }

    sn <- rownames(row)
    pe <- row[,,drop=TRUE]

    if( use.bacteria.names )
      labels.id <- bacteria.names( labels.id )

    text.id <- function(x, y, ind, adj.x = FALSE, ... ) {
        text(x - if (adj.x) strwidth(" ") * cex.id else 0, y, labels.id[ind], cex = cex.id, xpd = TRUE, adj = (if (adj.x) 1), ... )
    }

    if( missing(mark.these) ) {
        iid <- sum( abs(pe) > di.limit )
        if( iid < minimum.marked ) {
            iid <- minimum.marked
        }
        show.r <- order(-abs(pe))[1:iid]
    }
    else {
        show.r <- which( labels.id %in% mark.these )
    }

    if( missing( ylim ) ) {
        ylow <- min(pe)
        yhi <- pe[show.r[1]] * 1.075
        if( yhi < 0 )
          yhi <- max(pe)
        ylim <- c(ylow, yhi )
    }

    if( missing(ylab) ) ylab <- "DI effect"
    if( missing(xlab) ) xlab <- "Probe"

    f <- plot
    if( add )
        f <- points

    x <- seq_along(pe)

    f(x=x, pe, type = "h", ylim = ylim, main = main,
         xlab = xlab, ylab = ylab, ...)

    text.id(show.r, pe[show.r] + 0.4 * cex.id * strheight(" "),
            show.r, ... )

}
