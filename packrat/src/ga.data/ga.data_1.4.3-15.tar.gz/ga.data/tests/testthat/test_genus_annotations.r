library(ga.data)

context( "genus.annotations" )

test_that( "they are correct", {

    a1 <- genus.annotations(strip.indicator=FALSE)

    expect_equal(
        a1,
        c(
            "Anaerotruncus [g]",
            "Bacteroides fragilis [s]",
            "unclassified Clostridiales [f]",
            "Bacteroides [g]",
            "Bacteroides [g]",
            "Clostridium [g]",
            "Dorea [g]",
            "Eubacterium [g]",
            "Eubacterium [g]",
            "Ruminiclostridium [g]",
            "Faecalibacterium prausnitzii [s]",
            "Parabacteroides [g]",
            "Ruminococcus gnavus [s]",
            "Streptococcus [g]",
            "Acinetobacter [g]",
            "Akkermansia muciniphila [s]",
            "Bacillus [g]",
            "Bacteroides [g]",
            "Bifidobacterium [g]",
            "Catenibacterium [g]",
            "Ruminiclostridium [g]",
            "Dialister invisus [s]",
            "Megasphaera [g], Dialister [g]",
            "Holdemanella [g]",
            "Lachnospiraceae [f], Clostridiaceae [f], Eubacteriaceae [f]",
            "Lactobacillus [g]",
            "Pediococcus [g], Lactobacillus [g]",
            "Parabacteroides [g]",
            "Prevotella [g]",
            "Ruminococcus albus [s] / bromii [s]",
            "Alistipes [g]",
            "Alistipes [g]",
            "Pseudomonas [g]",
            "Atopobium [g]",
            "Desulfitispora [g]",
            "Coprobacillus [g]",
            "Phascolarctobacterium [g]",
            "Mycoplasma [g]",
            "Proteobacteria [ph]",
            "Salmonella [g],  Citrobacter [g], Enterobacter [g], Cronobacter [g]",
            "Bacilli [cl]",
            "Streptococcus sanguinis [s] & thermophilus [s]",
            "Clostridia [cl], Negativicutes [cl], Bacilli [cl]",
            "Actinobacteria [cl]",
            "Clostridia [cl], Veillonella [g], Helicobacter [g]",
            "Lactobacillus [g]",
            "Clostridia [cl], Negativicutes [cl]",
            "Bacteroides [g], Prevotella [g]",
            "Firmicutes [ph], Tenericutes [ph], Bacteroidetes [ph]",
            "Streptococcus [g]",
            "Streptococcus [g], Eubacterium [g]",
            "Shigella [g], Escherichia [g]",
            "Streptococcus [g]",
            "Actinomycetales [o]"
        )
    )

    expect_true(
        all( grepl("\\[(?:ph|g|s|cl|o|f)\\]", a1, perl=TRUE ) )
    )

    a2 <- genus.annotations(strip.indicator=TRUE)

    expect_true(
        all( !grepl("\\[(?:ph|g|s|f|cl|o)\\]", a2, perl=TRUE ) )
    )

    a3 <- genus.annotations(strip.indicator=TRUE,uniquify=TRUE)

    expect_true(
        any( "Bacteroides 2" %in% a3 )
    )
    expect_true(
        any( "Bacteroides 3" %in% a3 )
    )


})
