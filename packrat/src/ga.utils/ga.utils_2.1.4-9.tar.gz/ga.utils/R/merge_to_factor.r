##' Merge levels to factor
##'
##' Generates a factor by combining the list of levels as defined as a list of indeces
##' @title generate a factor from a list of logicals
##' @return factor
##' @author Torbjørn Lindahl
##' @param ... multiple logicals, defining who are each level
merge.to.factor <- function( ... ) {

    indeces <- list(...)
    x <- names(indeces)

    if( is.null(x) )
        stop( "Parameters to merge.to.factor must be named" )

    if( length(x) != length(indeces) ) {
        stop( paste0( "There are more level definitions (", length(indeces), ") than there are levels (", length(x), ")" ) )
    }

    v <- rep( NA, length(indeces[[1]]) )

    for( i in seq_along(x) ) {
        j <- indeces[[i]]
        v[j] <- x[i]
    }

    return( factor( v, levels=x ) )
}
