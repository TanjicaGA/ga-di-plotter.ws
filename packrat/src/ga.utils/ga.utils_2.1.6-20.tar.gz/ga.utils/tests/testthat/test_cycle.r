library(ga.utils)

context("cycle")

test_that( "positive direction", {

  expect_equal(
      cycle( LETTERS[1:4] ),
      LETTERS[c(4,1:3)]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=2 ),
      LETTERS[c(3:4,1:2)]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=3 ),
      LETTERS[c(2:4,1)]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=4 ),
      LETTERS[1:4]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=5 ),
      cycle( LETTERS[1:4], positions=1 )
  )

})

test_that( "negative direction", {

  expect_equal(
      cycle( LETTERS[1:4], positions=-1 ),
      LETTERS[c(2:4,1)]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=-2 ),
      LETTERS[c(3:4,1:2)]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=-3 ),
      LETTERS[c(4,1:3)]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=-4 ),
      LETTERS[1:4]
  )

  expect_equal(
      cycle( LETTERS[1:4], positions=-5 ),
      cycle( LETTERS[1:4], positions=-1 )
  )

})
