library(ga.utils)
library(readr)

read.file <- read_file

context("read.file() reads files")

test_that( "read files", {

    ## 1 line

    f <- tempfile( fileext=".txt" )
    cat( "hello", file=f )

    expect_that(
        read.file( f ),
        is_identical_to( "hello" )
    )

    unlink(f)

    ## more lines

    f <- tempfile( fileext=".txt" )
    cat( "hello\nthere", file=f )

    expect_that(
      read.file( f ),
      is_identical_to( "hello\nthere" )
      )

    unlink(f)

    ## an empty line

    f <- tempfile( fileext=".txt" )
    cat( "", file=f )
    expect_true( file.exists(f) )

    expect_that(
        read.file( f ),
        is_identical_to( "" )
    )

    unlink(f)

})

## test_that( "nonexisting files behaves as expected", {

##     ## non-existing file gives error and warns

##     ## expect_that(
##     ##   read.file( tempfile() ),
##     ##   gives_warning( "No such file or directory" )
##     ##   )

##     ## ow <- options(warn=-1)

##     ## expect_that(
##     ##   read.file( tempfile() ),
##     ##   throws_error( "does not exist" )
##     ##   )

##     ## options(ow)

## })
