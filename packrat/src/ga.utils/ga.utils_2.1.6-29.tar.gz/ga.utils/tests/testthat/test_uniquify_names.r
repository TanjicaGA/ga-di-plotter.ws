library(ga.utils)

context( "unquify_names" )

test_that( "uniquify names works with plain data frames", {

    d <- data.frame( Letter = LETTERS, foo = "bar", Letter = LETTERS, bar="baz", Letter=LETTERS, check.names=FALSE )
    expect_equal( uniquify.names(d), d[,c(1,2,4)] )

    d.1 <- data.frame( Letter = LETTERS, foo = "bar", bar="baz", check.names=FALSE )
    expect_equal( uniquify.names(d.1), d.1 )

    d.2 <- data.frame( Letter = LETTERS )
    expect_equal( uniquify.names(d.2), d.2 )

    d.3 <- data.frame( Letter = LETTERS, Letter = LETTERS, Letter = LETTERS, Letter = LETTERS, Letter = LETTERS, check.names=FALSE )
    expect_equal( uniquify.names(d.3), d.3[,1,drop=FALSE] )

})

test_that( "uniquify names works with arrays", {

    d <- cbind( Letter = LETTERS, foo = "bar", Letter = LETTERS, bar="baz", Letter=LETTERS )
    expect_equal( uniquify.names(d), d[,c(1,2,4)] )

    d.1 <- cbind( Letter = LETTERS, foo = "bar", bar="baz" )
    expect_equal( uniquify.names(d.1), d.1 )

    d.2 <- cbind( Letter = LETTERS )
    expect_equal( uniquify.names(d.2), d.2 )

    d.3 <- cbind( Letter = LETTERS, Letter = LETTERS, Letter = LETTERS, Letter = LETTERS, Letter = LETTERS )
    expect_equal( uniquify.names(d.3), d.3[,1,drop=FALSE] )

})
