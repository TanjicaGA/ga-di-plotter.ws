library(ga.luminex)

context( "read luminex file" )

test_that( "luminex files can be read", {

    lum.file <- "data/LUM05-03-1601.csv"
    d <- read.luminex( lum.file )

    expect_is( d, "list" )
    ## expect_equal( length(d), 9 )

    expect_equal(
        names(d),
        c(
            "header",
            "Median",
            "Net MFI",
            "Count",
            "Avg Net MFI",
            "Normalized Net Median",
            "Avg Normalized Net Median",
            "Units",
            "Per Bead Count",
            "Dilution Factor",
            "CRC32"
        )
    )

    expect_equal(
        d$header$Operator,
        "Ragnhild"
    )

    ## "Date","3/11/2016","9:34 AM"
    expect_equal(
        d$header$Date,
        strptime("2016-03-11 09:34", format="%F %H:%M")
    )

})

test_that( "it can read sections with csv over mulitple lines",  {

    lum.file <- "data/LUM05-04-1801_L1806-0_LX1734_MWO.csv"
    d <- read.luminex( lum.file )

    expect_equal(
        d$header$BatchDescription,
        "Column 2-5 contains shelf life samples for L1806.\nColumn 1 and 6 is Q2-011 L1806_II."
    )
    
})
