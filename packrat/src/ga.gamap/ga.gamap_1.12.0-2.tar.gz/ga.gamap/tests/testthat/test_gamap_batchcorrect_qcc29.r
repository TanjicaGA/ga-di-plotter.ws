library(ga.gamap)
library(ga.batchcorrection)
library(ga.data)
library(testthat)

context( "batchcorrect on qcc29 corrected data" )

test_that( "it corrects correctly", {

    f <- "data/Lx200-TestfileD-Q2-012.csv"

    ## do it by 'hand' first:
    di.plate <- gamap( f, stop.at="file" )
    di.qcc <- gamap( di.plate, start.from="file", stop.at="qcc" )

    di.qcc29 <- qcc29.correct( di.qcc )

    di.qcc29.batch.A.1 <- correct( batch.correction("PS1801L.9"), di.qcc29 )
    di.qcc29.batch.A.2 <- correct( batch.correction("PS1901L.9"), di.qcc29 )

    ## the first factor should not change the data
    expect_equivalent( di.qcc29, di.qcc29.batch.A.1 )

    ## and then via the intended interface
    di.qcc29.batch.B.1 <- gamap.batchcorrect.qcc29( f, batch="PS1801L" )
    di.qcc29.batch.B.2 <- gamap.batchcorrect.qcc29( f, batch="PS1901L" )
    di.qcc29.batch.B.3 <- gamap.batchcorrect.qcc29( f, batch=rep("PS1901L",nrow(di.qcc29)) )

    di.qcc29.batch.B.4  <- gamap.batchcorrect.qcc29( f, batch=batch.correction("PS1902L") )
    di.qcc29.batch.B.4b <- gamap.batchcorrect.qcc29( f, batch=batch.correction("PS1902L.9") )

    expect_equivalent( di.qcc29, di.qcc29.batch.B.1 )
    expect_equivalent( di.qcc29.batch.A.2, di.qcc29.batch.B.2 )
    expect_equal( di.qcc29.batch.B.2, di.qcc29.batch.B.3 )

    expect_equal( di.qcc29.batch.B.4, di.qcc29.batch.B.4b )

    ## old, non-existing batches
    b <- c(
        rep( "PS1902L", nrow(di.qcc29) ),
        rep(  "PS1703", nrow(di.qcc29) )
    )

    xb <- gamap.batchcorrect.qcc29( rep(f,2), batch=b )

    ## everything should now be NA for the PS1703 factor:
    expect_true( all(is.na(xb[-(1:nrow(di.qcc29)),] )))

    ## for the PS1902L it should match what was calculated above:
    expect_equivalent( xb[1:nrow(di.qcc29),], di.qcc29.batch.B.4 )

    ## test that it works with kitlot names
    expect_equal( psf.from.kitlot("L1804"), "PS1801L" )

    ## check that it works via kitlot too
    di.qcc29.batch.C.1 <- gamap.batchcorrect.qcc29( f, batch="L1804" )
    expect_equivalent( di.qcc29.batch.B.1, di.qcc29.batch.C.1 )

})
