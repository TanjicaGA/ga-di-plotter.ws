##' Calcualtes batch correction parameters and returns a model
##'
##' Calculates the batch parameters needed for batch correction
##' according to procedure. Currently it log transforms, scales and
##' recenters and antilogs data to match an old reference set.
##'
##' The two input matrices must be ordered so that rows refer to the
##' same sample, ie row 1 of \code{old} must match the sample as row 1
##' in \code{new} etc.
##'
##' Dimnames of \code{old} and \code{new} are checked and required to
##' be identical.
##' @title Calculate batch correction factor
##' @param old matrix with QCC30 adjusted data from old reference lot.
##' @param new matrix with QCC30 adjusted data from new lot.
##' @param psf.name Name of the factor, e.g. PS1512
##' @param kitlot Deprecated, used to be the argument for psf.name
##' @param outliers a list of outliers to remove before
##'     calculation. Each name of the list should represent a probe
##'     number , ie 1:54, each value should be one or more samples as
##'     numerical indeces, ie 1:x where x is the maximum of rows
##'     available in the input. For example the list( "8"=39:41,
##'     "54"=40 ) would mark as outliers samples 39:41 for probe 8 and
##'     sample 40 for probe 54.
##' @param type what type of calculation to do. Defaults to
##'     'exponential'. Also available are 'log.scale' (fits model in
##'     after log transform) 'difference' (diff of means, old method),
##'     'ratio' (divide new with old) and 'null' (does nothing)
##' @param ... extra arguments passed to function calculating the batch correction
##' @return batch correction model
##' @author Torbjørn Lindahl
##' @export
##' @examples
##' # bcf <- calculate.batch.correction( old, new,
##' #	"PS1512", outliers=list("8"=39:41) )
##'
##' # To correct future data:
##' # corrected.data <- correct( bcf, x.futuredata )
##'
##' # cf <- coef(bcf) # a 2x54 matrix with correction parameters
calculate.batch.correction <- function( old, new, psf.name, kitlot, outliers=list(),
                                       type=c("exponential","log.scale",
                                              "ratio","difference","null"), ... ) {

    if( !missing(kitlot) ) {
        if( missing( psf.name ) ) {
            warning( "The kitlot argument is deprecated, use psf.name instead, see manual. psf.name was set from the kitlot argument" )
            psf.name <- kitlot
        } else {
            if( !identical( kitlot, psf.name ) ) {
                stop( "The kitlot and psf.name argument differ. 'kitlot' is deprecated, use psf.name instead")
            }
            warning( "The kitlot argument is deprecated" )
        }
    }

    type <- match.arg(type)

    if(type == "null") {
        obj <- list(
          type = "null"
          )
    }
    else {

        old.orig <- old
        new.orig <- new

        if(!missing(outliers)) {
            for( o in names(outliers) ) {
                ol <- outliers[[o]]
                n <- as.numeric(o)
                old[ ol, n ] <- NA
                new[ ol, n ] <- NA
            }
        }
        else {
            outliers <- list()
        }

        if( type == "log.scale" ) {
            obj <- batch.correction.log.scale( old, new, ... )
        }
        else if( type == "ratio" ) {
            obj <- batch.correction.ratio( old, new, ... )
        }
        else if( type == "difference" ) {
            obj <- batch.correction.difference( old, new, ... )
        }
        else if( type == "exponential" ) {
            obj <- batch.correction.exponential( old, new, ... )
        }
    }

    obj$psf.name <- psf.name
    obj$kitlot <- psf.name
    obj$outliers <- outliers

    if( type != "null")
      obj$model <- data.frame( old=I(old.orig), new=I(new.orig) )

    class( obj ) <- c( "batchcorrection" )

    return( obj )

}

##' @export
##' @importFrom ga.data check.psf.name
print.batchcorrection <- function( x, ... ) {

    x <- check.psf.name(x)

    cat( sprintf(
      "%s - Batch correction of type %s",
      x$psf.name, x$type
      ), "\n" )

    invisible(x)

}

##' Batch correct new data
##'
##' Batch correct a matrix of QCC30 adjusted data
##' @title correct new data with the bcf
##' @param obj batchcorrection object
##' @param newdata new data to correct
##' @param ... optional arguments for future use
##' @return batch corrected data
##' @seealso \code{\link{calculate.batch.correction}}
##' @author Torbjørn Lindahl
##' @seealso \code{\link{calculate.batch.correction}}
##' @rdname correct
##' @importFrom stats coef
##' @importFrom ga.data platform_align
##' @export
correct.batchcorrection <- function( obj, newdata, ... ) {

    if(!inherits( obj, "batchcorrection" )){
        stop("Object isn't a batchcorrection object")
    }

    if( obj$type == "null" )
      return(newdata)

    newdata <- check.qcc30.data(newdata)

    cf <- coef(obj)

    if( !is.null(dim(cf)) && ncol(cf) != ncol(newdata) ) {
        if( ncol(newdata) == 54 ) {
            cf <- coef( platform_align( obj, "biocode" ) )
        } else if( ncol(newdata) == 48 ) {
            cf <- coef( platform_align( obj, "lx200" ) )
        } else {
            stop(paste( "Cannot automatically handle correction, new data has unusual ncol:", ncol(newdata) ) )
        }
    }

    corr <- NULL

    if( obj$type %in% c("log.scale","exponential") ) {

        shr <- rep( cf[1,], each=nrow(newdata) )
        sft <- rep( cf[2,], each=nrow(newdata) )

        corr <- newdata**shr * sft
    }
    else if( obj$type == "ratio" ) {
        corr <- sweep( newdata, 2, cf, FUN="*" )
    }
    else if( obj$type == "difference" ) {
        corr <- sweep( newdata, 2, cf, FUN="-" )
    }
    else if( obj$type == "NA" ) {
        corr <- newdata
        corr[] <- NA
    }

    invisible(corr)

}

##' @rdname correct
##' @export
correct <- function( obj, newdata, ... ) UseMethod("correct")

##' Check that data looks like valid input qcc30 data
##'
##' Checks that x has 54 columns. If x is a vector, its changed to a
##' 1x54 matrix.
##' @title Check QCC30 data
##' @param x data that should be QCC30 adjusted data
##' @param arg.name name to annotate messages, typically the argument
##' name in the calling function
##' @return QCC30 data, possibly corrected if wrong dimensions
##' @author Torbjørn Lindahl
check.qcc30.data <- function( x, arg.name ) {

    if( missing(arg.name) )
      arg.name <- as.character(substitute(x))

    msg <- paste( arg.name, "should be data for 48 or 54 probes" )

    if( is.null(dim(x)) ) {

        if( !length(x) %in% c(48,54) ) {
            stop( msg )
        }

        warning(paste("Treating",arg.name,"as a 1 row matrix"))

        x <- matrix( x, ncol=length(x) )

    }
    else {

        if( !dim(x)[2] %in% c(48,54) )
          stop( msg )

    }

    invisible(x)

}

##' Set up correction datas
##'
##' Aligns new data to old data
##' @title align batch correction matrices
##' @param ... arguments to gamap
##' @param qcc.old optional other qcc matrix to use as reference
##'     values
##' @return list with two matrices, old and new
##' @author Torbjørn Lindahl
##' @importFrom ga.utils "%!~%"
##' @importFrom ga.utils sql.array
##' @importFrom ga.data model.qcc30.data
##' @export
align.old.and.new.data <- function( ..., qcc.old ) {

    qcc.new <- ga.gamap::gamap( ..., stop.at = "qcc" )

    if( missing( qcc.old ) )
        qcc.old <- model.qcc30.data()

    rn.old <- rownames(qcc.old)

    rn.new <- rownames(qcc.new)
    rn.new <- sub( "PC ", "PC_", rn.new )

    rownames(qcc.new) <- rn.new

    rn.minus.qcc <- rn.new[ rn.new %!~% "QCC" ]

    sn <- intersect( rn.new, rn.old )

    old <- qcc.old[ match( sn, rn.old ), ]
    new <- qcc.new[ match( sn, rn.new ), ]

    if(!identical( dim(old), dim(new) ) ) {
        stop( "Dimensions of old and new data don't match, they should." )
    }

    if(!identical( dimnames(old), dimnames(new) ) ) {
        stop( "dimnames of old and new don't match, normally they should" )
    }

    invisible( list( old=old, new=new ) )

}

##' batch correction that gives NA
##'
##' A batch correction object, that is used, gives NA only results
##' @title batch correction object resulting in NA
##' @return batch correction object with NA for all coefficients
##' @author Torbjorn Lindahl
##' @export
na.correction <- function() {

    l <- list(
        psf.name = "PSNA",
        type = "NA",
        outliers = list(),
        model = list( old=NA, new=NA ),
        coefficients = structure(
            rep(NA, 54*2),
            .Dim = c(2L, 54L),
            .Dimnames = list(
                c("shr", "sft"),
                c("AG0342", "AG0377", "AG0393", "AG0396", "AG0416", "AG0515",
                  "AG0581", "AG0608", "AG0620", "AG0638", "AG0651", "AG0686", "AG0703",
                  "AG0732", "AG0777", "AG0815", "AG0854", "AG0863", "AG0865", "AG0895",
                  "AG0912", "AG0930", "AG0931", "AG0974", "AG1034", "AG1046", "AG1061",
                  "AG1099", "AG1118", "AG1152", "AG1225", "AG1226", "AG1267", "AG1647",
                  "AG1652", "AG1661", "AG1687", "AG1698", "IG0005", "IG0011", "IG0012",
                  "IG0020", "IG0023", "IG0028", "IG0044", "IG0053", "IG0058", "IG0060",
                  "IG0063", "IG0079", "IG0081", "IG0133", "IG0197", "IG0314"
                  ))
        )
    )
    class( l ) <- "batchcorrection"

    return( l )

}
