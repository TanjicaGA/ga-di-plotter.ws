library(ga.gamapqc)
library(ga.gamap)
library(ga.data)
library(ga.utils)

context( "gamap qc sets" )

test_that( "it loads the json", {

    l <- gamap.qc.sets()
    expect_is( l, "list" )
    expect_named( l, c("Biocode","Lx200") )

})

test_that( "it loads the freshest set", {

    local({

        s <- newest.gamap.qc.set( "Biocode" )
        all.sets <- gamap.qc.sets()$Biocode

        o <- order( sapply( all.sets, function(s)s$"valid-from-date" ), decreasing=TRUE )
        s.target <- all.sets[o][[1]]$set

        expect_equal( s, s.target )

    })

    local({

        s <- newest.gamap.qc.set( "Lx200" )
        all.sets <- gamap.qc.sets()$Lx200

        o <- order( sapply( all.sets, function(s)s$"valid-from-date" ), decreasing=TRUE )
        s.target <- all.sets[o][[1]]$set

        expect_equal( s, s.target )

    })

})
