##' regex for probe names
##'
##' A regular expression that matches probe names
##' @title probe regex
##' @return a regex
##' @author Torbjørn Lindahl
##' @export
##' @param include.technical include regexp for technical probes HYC, UNI and BLANK
probe.re <- function(include.technical=FALSE) {
    if( !include.technical )
        return( "^[AI]G\\d{4}$" )
    else
        return( "^([AI]G\\d{4}|UNI\\d+|HYC\\d+|BLANK\\d+)$" )
}
