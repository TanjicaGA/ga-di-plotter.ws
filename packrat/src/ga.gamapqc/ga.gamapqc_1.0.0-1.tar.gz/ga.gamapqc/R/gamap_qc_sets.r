##' Lists all defined QC sets
##'
##' Parses the internally defined json file and returns the contents
##' @title gamap.qc.sets
##' @return list
##' @author Torbjørn Lindahl
##' @importFrom readr read_file
gamap.qc.sets <- function() {

    f <- system.file(
      "qc_sets.json",
      package="ga.gamapqc",
      mustWork=TRUE
      )

    json <- read_file(f)
    .validate.qc.sets.json(json)
    sets <- jsonlite::fromJSON(json)

}

date.ordered.qc.sets.by.platform <- function(platform) {

    p.sets <- gamap.qc.sets()[[platform]]
    set.dates <- sapply( p.sets, function(s)s$"valid-from-date" )

    if( anyDuplicated( set.dates ) ) {
        stop( sprintf("There are identical 'valid-from'-dates in the qc set parameter list of '%s'", platform))
    }

    o <- order( set.dates, decreasing=TRUE )
    p.sets[o]

}

##' @importFrom jsonvalidate json_validate
##' @importFrom readr read_file
.validate.qc.sets.json <- function(json) {

    schema.file <- system.file(
        "qc_sets_schema.json",
        package="ga.gamapqc",
        mustWork=TRUE
    )

    check <- json_validate(json, read_file(schema.file), error=TRUE )

    ## check <- validate_jsonfile_with_schemafile( json.file, schema.file )
    ## if( check$value != 0 ) {
    ##     stop( paste( check[c("value","message")] ) )
    ## }

    ## most json schema validators in R don't really work all that well.
    ## Recomended to run in addition: ajv validate -s qc_sets_schema.json -d qc_sets.json

}

##' newest qc set parameters for gamap platform
##'
##' Looks up the available qc sets for given platform and returns the
##' newest one
##' @title newest.gamap.qc.set
##' @param platform platform to look up, currently one of Biocode and
##'     Lx200, but could be any future label added to the qc set list
##' @return list of qc parameters
##' @author Torbjørn Lindahl
##' @export
newest.gamap.qc.set <- function(platform) {
    date.ordered.qc.sets.by.platform(platform)[[1]]$set
}

##' Looks up the correct qc set from kitlot provided
##'
##' Orders sets by date and gets the first that covers the provided
##' kitlot
##' @title Look up qc set by kitlot
##' @param platform platform to look up
##' @param kitlot kitlot to look up qc set for
##' @return correct qc set to use with the provided kitlot
##' @author Torbjørn Lindahl
##' @importFrom ga.data validate_kitlots
##' @importFrom ga.utils last_true
##' @export
qc.set.by.kitlot <- function(platform,kitlot) {

    validate_kitlots(kitlot)
    p.sets <- date.ordered.qc.sets.by.platform(platform)[[1]]$set

    p.kitlots <- sapply( p.sets, function(p)p$"valid-from-kitlot" )
    l <- last_true( p.kitlots <= kitlot )

    if( is.na(l) ) {
        stop("No QC set could be found for kitlot ", kitlot)
    }

    return( p.sets[[l]]$set )

}
