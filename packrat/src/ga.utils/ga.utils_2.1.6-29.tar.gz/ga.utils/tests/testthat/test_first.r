library(ga.utils)

context("first returns index of first TRUE")

test.vector <- c(2,7,1,3,4,1,8,10)

test_that( "basic usage works", {

    expect_that(
      first( test.vector == 1),
      equals( 3 )
      )

    expect_that(
      first( sort(test.vector) == 1),
      equals( 1 )
      )

    expect_that(
      first( test.vector != 1),
      equals( 1 )
      )

    expect_that(
      first( test.vector > 4),
      equals( 2 )
      )

    expect_that(
      first( test.vector < 2),
      equals( 3 )
      )

    expect_that(
      first( test.vector == c(3,1)),
      equals( 6 )
      )

})



test_that( "NA is handled", {

    expect_that(
      first( test.vector == 5),
      equals( NA )
      )

    expect_that(
        first( c(NA,NA,NA) ),
        equals(NA)
    )

})

test_that( "Error when not logical", {

    expect_that(
      first( test.vector ),
      throws_error("argument should be a logical")
      )

})
