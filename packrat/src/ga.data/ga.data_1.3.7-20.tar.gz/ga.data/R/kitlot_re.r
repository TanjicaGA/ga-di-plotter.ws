##' Valid kitlot regex
##'
##' Just the regex to match valid kitlots
##' @title regexp to match a kitlot
##' @return string
##' @author Torbjørn Lindahl
##' @export
kitlot_re <- function() {
    "^[KL][12]\\d{3}$"
}


##' function to validate a kitlot
##'
##' checks that the provided kitlot(s) are valid
##' @title validate kitlot
##' @param kitlots kitlots to check
##' @param error logical default TRUE, throws an error if at least one fails
##' @return logical
##' @author Torbjørn Lindahl
##' @export
validate_kitlots <- function(kitlots, error=TRUE) {

    c <- grepl( kitlot_re(), kitlots )

    if( !all(c) && error ) {
        stop(sprintf("Invalid kiltot(s) found: %s", paste(kitlots[!c], collapse=", ")))
    }

    return(c)

}
