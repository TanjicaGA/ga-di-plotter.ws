library(ga.data)

context( "bacteria.names" )

test_that( "names are looked up correctly", {

    src <- ga.data:::probe.annotations

    pr1 <- src$Probe[1]
    b1 <- src$BacteriaName[1]

    expect_equal(
        bacteria.names( pr1 ), b1 )

    expect_equal(
        bacteria.names( c(pr1,NA) ), c(b1,NA) )

    expect_equal(
        bacteria.names( src$Probe[1:2] ), src$BacteriaName[1:2] )

})

context( "probe.numbers" )

test_that( "names are looked up correctly", {

    src <- ga.data:::probe.annotations

    pr1 <- src$Probe[1]
    b1 <- src$ProbeNumber[1]

    expect_equal( probe.numbers( pr1 ), b1 )

    expect_equal( probe.numbers( src$Probe[1:2] ),
        src$ProbeNumber[1:2] )

    expect_equal( probe.numbers( c(NA,pr1) ), c(NA,b1) )


})

context( "probe.codes" )

test_that( "names are looked up correctly", {

    expect_equal(
        probe.codes( 100 ),
        "IG0028"
    )

    expect_equal(
        probe.codes( c(101,102) ),
        c("IG0314","AG1647")
    )

})
