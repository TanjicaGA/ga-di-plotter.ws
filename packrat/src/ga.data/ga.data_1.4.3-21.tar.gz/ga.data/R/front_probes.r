##' Probes on front page of report
##'
##' Lists the 10 (currently) probes on the first page of the report
##' @title front page probes
##' @return charcter
##' @author Torbjørn Lindahl
##' @export
front.probes <- function() {
    return( c("AG0865", "AG1226", "AG0377", "AG0651", "IG0053", "AG0703",
              "IG0020", "IG0005", "IG0133", "AG0815") )
}
