##' Index of first true value
##'
##' Returns the index of the first true value in a vector or NA
##' @title First true value
##' @param x logical vector to be checked
##' @return number of first true index
##' @author Torbjørn Lindahl
##' @export
first <- function(x) {

    if( !inherits(x, "logical") )
      stop("argument should be a logical")

    if( any(x %in% TRUE) )
      return( which(x)[1] )
    else
      ## If no true elements in input, NA is the only meaningful response
      return( NA )
}
