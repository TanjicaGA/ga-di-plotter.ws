## step functions for the gamap

##' step 1: read files
##'
##' Reads biocode csv files
##' @title step 1
##' @param input character, file names
##' @return a data.frame with data read from the csv file
##' @author Torbjørn Lindahl
##' @importFrom ga.biocode read.biocode.plates
gamap.step.file <- function( input ){

    output <- process.csvfiles( input, "Median" )
    count.data <- process.csvfiles( input, "Count" )

    cn2 <- colnames(output)
    cn3 <- setdiff( cn2, c("File", "Platform", "Location", "Sample", "Total.Events",
                           "Plate", "Coord" ,"Well", "Row", "Col" ) )

    if( !identical( cn3, probe.set("ibs3") ) ) {
        names.too.many <- setdiff(cn2, probe.set("ibs3"))
        names.missing <- setdiff(probe.set("ibs3"), cn2)
        extra <- ""
        if( length(names.too.many) > 0 )
          extra <- sprintf( "Names too many: %s\n", paste(names.too.many,collapse = ", ") )
        if( length(names.missing) > 0 )
          extra <- paste0( extra, sprintf( "Names missing: %s", paste(names.missing,collapse = ", ") ) )

        stop( sprintf( "Names read on data in file do not match the reference names for ibs3.0\n%s", extra ) )
    }

    attr( output, "count" ) <- count.data

    class( output ) <- append( "gamap.file", class( output ) )

    return( output )
}

##' print method for the file data of the algorithm
##'
##' Shows only the most commonly inspected contents of the data frame
##' @title print file data from gamap algorihtm
##' @param x data to print
##' @param ... extra arguments to print.data.frame
##' @return a subset of the data as a data.frame, or just the object
##' @author Torbjørn Lindahl
##' @export
print.gamap.file <- function(x, ... ) {

    columns.to.exclude <- c(
        grep( "^[AI]G\\d+$", colnames(x), value=TRUE ),
        c("Total.Events","Coord","Well","Row","Col")
    )

    i <- colnames(x) %in% columns.to.exclude

    if( all(x$Platform %in% "lx200") ) {
        i <- i | grepl("^BLANK[12]$",colnames(x) )
    }

    print.data.frame( y <- x[,!i] )

}

`[.gamap.file` <- function( x, i, j, ... ) {

    y <- `[.data.frame`(x, i, j, ... )

    ## If we subsetted the columns, we drop this class
    if( !missing(j) )
        class(y) <- setdiff( class(y), "gamap.file" )

    return( y )

}

##' biocode meta data
##'
##' Returns columns from biocode data other than the probe measurements (eg filename, rundate, samplenames etc)
##' @title fetch biocode meta data
##' @param x biocode data to fetch meta data from
##' @param ... additional parameters passed to methods
##' @return data.frame with meta data
##' @author Torbjørn Lindahl
##' @export
meta <- function( x, ... ) {
    UseMethod("meta")
}

##' @author Torbjørn Lindahl
##' @importFrom ga.data probe.re
meta.gamap.file <- function(x ) {
    x[, !grepl( probe.re( include.technical=TRUE ), colnames(x) ) ]
}
