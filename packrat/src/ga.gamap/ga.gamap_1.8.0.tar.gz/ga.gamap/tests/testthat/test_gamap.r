library(ga.gamap)

biocode.file <- file.path( "data", "Q2-005-K1515_II-BC1511.csv" )

context( "gamap step 1 - read biocode file" )

test_that( "files are read", {

    step1 <- gamap( biocode.file, stop.at = "file", batch="PS1408" )

    expect_is( step1, "data.frame" )
    expect_equal( dim(step1), c(68,68) )

    expect_equal(
      gamap( biocode.file, stop.at = "file", start.with = "file", batch="PS1408" ),
      step1
      )

    expect_true( "count" %in% names(attributes(step1)))

})

context( "gamap step 2 - probe data" )

test_that( "raw data is ok", {

    step2 <- gamap( biocode.file, stop.at = "raw", batch="PS1408" )
    expect_is( step2, "matrix" )
    expect_equal( dim(step2), c(68,54) )

    expect_equal(
      gamap( biocode.file, stop.at = "raw", start.with = "file", batch="PS1408" ),
      step2
      )

})

context( "gamap step 3 - hyb adjusted" )

test_that( "hyc adjustment works", {

    step3 <- gamap( biocode.file, stop.at = "hyb", batch="PS1408" )
    expect_is( step3, "matrix" )
    expect_equal( dim(step3), c(68,54) )

    expect_equal(
      gamap( biocode.file, stop.at = "hyb", start.with = "file", batch="PS1408" ),
      step3
      )

})

context( "gamap step 4 - qcc30 adjusted" )

test_that( "qcc30 adjustment works", {

    step4 <- gamap( biocode.file, stop.at = "qcc", batch="PS1408" )
    expect_is( step4, "matrix" )
    expect_equal( dim(step4), c(68,54) )

})

context( "gamap step 5 - batchcorrected" )

test_that( "batchcorrection works", {

    step5 <- gamap( biocode.file, stop.at = "batchadjusted", batch="PS1512" )
    expect_is( step5, "matrix" )
    expect_equal( dim(step5), c(68,54) )

})

context( "gamap step 6 - bg" )

test_that( "bg adjustement works", {

    step6 <- gamap( biocode.file, stop.at = "bg", batch="PS1512" )
    expect_is( step6, "matrix" )
    expect_equal( dim(step6), c(68,54) )

})

context( "gamap step 7 - center" )

test_that( "centering works", {

    step7 <- gamap( biocode.file, stop.at = "center", batch="PS1512" )
    expect_is( step7, "matrix" )
    expect_equal( dim(step7), c(68,54) )

})

context( "gamap step 8 - scores" )

test_that( "scores calc works", {

    step8 <- gamap( biocode.file, stop.at = "scores", batch="PS1512" )
    expect_is( step8, "matrix" )
    expect_equal( dim(step8), c(68,15) )

})

context( "gamap step 9 - scores" )

test_that( "scores calc works", {

    step9 <- gamap( biocode.file, stop.at = "t2res", batch="PS1512" )
    expect_is( step9, "data.frame" )
    expect_named( step9, c("T2","Qres","Sample"), ignore.order = TRUE )
    expect_is( step9$T2, "numeric" )
    expect_is( step9$Qres, "numeric" )

})

context( "gamap step 10 - di class" )

test_that( "di result is right", {

    step10 <- gamap( biocode.file, stop.at = "dysbiosis", batch="PS1512" )
    expect_is( step10, "character" )

    expect_equal(
      as.numeric(table(step10)),
      c(24,44)
      )

})

context( "gamap step 11 - numeric di" )

test_that( "numeric di is right", {

    target.din <- structure(c(4.99999999999999, 4.16824624998625,
                              4.46856524811841, 0.416115101239748, 5,
                              0.206258814167644, 0.591873643510826,
                              0.395697134169967, 1.25145554682858,
                              0.671065358551229, 0.641876541436065,
                              0.305633061387293, 0.811036415299598,
                              0.897552281129546, 1.29276210264055,
                              4.08162394433002, 4.95367201191685,
                              4.12502307839692, 1.10979943124038,
                              2.27640121489939, 0.577503799570219,
                              0.270984105953023, 0.520095872250806,
                              1.24403842829705, 2.47285914126725,
                              1.21716572989413, 2.68544392888919,
                              0.514577247045946, 0.919758575435497,
                              0.704389445283689, 1.38749210640546,
                              0.779068101891071, 2.16074968479092,
                              2.49818708936356, 1.4118531635787,
                              0.045721682424616, 0.213705473361709,
                              0.145619221993075, 1.11542493653638,
                              2.5552077002417, 1.13127070983609,
                              0.71166486211571, 4.99999999999999,
                              4.10982947531014, 4.71633951758853,
                              0.436487710934932, 4.99999999999998,
                              2.7283952940351, 0.171440366710349,
                              0.743680890141907, 1.4896679949967,
                              0.438458768412093, 1.1612304944931,
                              3.32367135156895, 1.32077763648049,
                              0.279895098936429, 1.16664106688851,
                              2.94380105125372, 1.39832526586379,
                              0.379332124080501, 2.15908784761668,
                              2.23095183107947, 2.78824847584904,
                              2.27858820172556, 1.00186736050324,
                              0.76725835043128, 0.269215490794061,
                              0.0852921697331918 ), .Names =
                              c("QCC30_A", "QCC29_A", "QCC23_A",
                              "QCC33_A", "QCC30_B", "N019_B",
                              "N021_A", "N022_A", "N024_A", "N025_A",
                              "N026_B", "N027_B", "PC 36281",
                              "PC 36651", "PC 37451", "PC 37521",
                              "PC 38061", "PC 38361", "PC 38711",
                              "PC 38931", "N030_A", "N031_A",
                              "N032_A", "N033_A", "N034_B", "N037_A",
                              "PC 42711", "PC 44741", "PC 46401",
                              "PC 46821", "PC 47201", "PC 50111",
                              "PC 50161", "PC 50261", "N038_A",
                              "N039_A", "N043_A", "N044_A", "N045_A",
                              "N046_A", "N047_A", "N048_A", "QCC30_C",
                              "QCC29_B", "QCC23_C", "QCC33_C",
                              "QCC30_D", "PC 53571", "PC 54531",
                              "PC 54571", "PC 54671", "PC 54701",
                              "PC 55371", "PC 55441", "N077_C",
                              "N078_B", "N079_B", "N081_A", "N085_A",
                              "N087_A", "N088_A", "N089_A", "N091_A",
                              "N092_A", "N097_A", "N098_A", "N099_A",
                              "N100_B"))

    din <- gamap( biocode.file, stop.at = "numeric", batch = "PS1512" )

    expect_equivalent(
      din,
      target.din
      )

})
