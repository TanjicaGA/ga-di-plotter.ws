##' check if x is empty
##'
##' Check if something is 'empty'. This currently goes for zero length
##' variables, empty strings, NULL and 0-row objects that have 2 or
##' more dimensions
##' @title is empty
##' @param x value to test
##' @return logical
##' @author Torbjorn Lindahl
##' @export
empty <- function(x) {

    if( length(dim(x)) > 1 )
        return( dim(x)[1] == 0 )
    else if( length(x) == 0 )
        ## this also takes care of x being NULL
        return( TRUE )
    else if( is.character(x) )
        return( x == "" )

    return( FALSE )

}
