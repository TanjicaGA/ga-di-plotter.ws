library(testthat)
library(ga.data)

context( "bacteria.table.ranges" )

test_that( "bacteria.table.ranges is right", {

    br <- bacteria.table.ranges( "IG0005", revision="rev3" )
    expect_equal( as.vector(br), c("0","+3") )

    br2 <- bacteria.table.ranges( "IG0005", return.type="numeric", revision="rev3" )
    expect_equal( as.vector(br2), c(0,3) )

    br3 <- bacteria.table.ranges( c("IG0005","AG0651"), revision="rev4" )
    expect_equal( dim(br3), c(2,2) )
    expect_equivalent( br3, cbind( c("-1","+3"),c("-3","0") ) )

    ## this one has only one item
    br4 <- bacteria.table.ranges("AG1225")
    expect_equivalent( br4, c("0","+1"))

})

context( "issue 2019-11-11 - wrong ranges reported" )

test_that( "AG0732 gets right", {

    br <- bacteria.table.ranges( "AG0732", revision="rev3" )
    expect_equal( as.vector(br), c("-1","+3") )

})
