library(ga.software)
library(jsonlite)
library(readr)
library(ga.utils)

context( "prepare test data" )

test.file <- "data/COP-1404_plate1.csv"

check.json <- function( data, json.file ) {

    json <- read_file( json.file )
    ## json <- gsub( "NaN", "null", json )
    target <- fromJSON(json)

    expect_equal(
        sort( names(data) ),
        sort( names(target) )
    )

    ## header:
    expect_equal(
        sort(unlist(data$header)),
        sort(unlist(target$header))
    )

    ## Version, should be a date
    test_that( "VERSION", {
        expect_true(
            grepl( "\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}", data$VERSION )
        )
    })

    ## some plain comparisons
    nn <- c("probe","location","sample","batch_used","median","count","hyb","qcc",
            "batch", "bg", "center", "scores", "t2", "qres", "diagnosis",
            "t2_scaled", "qres_scaled", "radius", "DI_float", "greyzone",
            "DI_final", "probe_level_names", "probe_levels")

    for( n in setdiff(nn,"probe_levels") ) {
        test_that( paste0("test: ",n), {
            expect_equal(
                data[[n]],
                target[[n]],
                info=paste0(n),
                tolerance=1e-5
            )
        })
    }

}

test_that( "data gets right", {

    l <- prepare.biocode.testdata( test.file, batch="PS1408" )

    expect_is( l, "list" )

    expect_is( l$header, "list" )
    expect_equal( l$header$Date, "2014-10-09T11:24:00" )

    expect_true( all(grepl( "^[A-H]\\d{1,2}$", l$location ) ) )
    expect_true( all(grepl( "^\\d{1,3}$", l$probe ) ) )

    expect_equal( l$sample,
                 c("QCC30_A", "QCC29_A", "QCC23_A", "QCC33_A", "QCC30_B", "SU0161",
                   "SU0811", "SU0622", "SU0042", "SU0032", "SU0752", "SU0201", "KI0072",
                   "SU0452", "SU0221", "SU0872", "AS0052", "SU0041", "SU0572", "KI0011",
                   "SU0411", "SU0542", "SU0812", "AS0011", "SU0222", "SU0571", "SU0321",
                   "SU0101", "SU0421", "SU0621", "SU0311", "SU0661", "SU0741", "SU0341",
                   "SU0431", "AS0012", "SU0192", "SU0202", "SU0191", "SU0822", "SU0441",
                   "SU0742", "SU0422", "SU0451", "SU0541", "SU0412", "SU0141", "QCC30_C",
                   "QCC29_B", "QCC23_B", "QCC33_B", "QCC30_D", "SU0751", "SU0821",
                   "SU0142", "KI0071", "SU0442", "SU0082", "SU0662", "KI0012", "SU0102",
                   "SU0031", "SU0322", "SU0871", "SU0312", "SU0172", "SU0162", "SU0401",
                   "SU0402", "SU0432", "SU0081", "SU0642", "SU0641", "SU0171", "AS0051",
                   "SU0342")
                 )

    expect_equal( l$batch_used, "PS1408" )

    expect_named( l, c("header", "probe", "location", "sample",
                       "batch_used", "median", "count", "hyb", "qcc",
                       "batch", "bg", "center", "scores", "t2", "qres",
                       "diagnosis", "t2_scaled", "qres_scaled", "radius",
                       "DI_float", "greyzone", "DI_final", "VERSION",
                       "probe_level_names", "probe_levels", "QC"), ignore.order=TRUE )

    check.json( l, "data/COP-1404_plate1.json" )

})

if( grepl( "(1|true)", tolower(Sys.getenv("TESTALL"))) ) {

    ## Test the rest
    csv.files  <- dir( "data/csv", full.name=TRUE )
    batches <- c(
        "CLS-1404.csv"            = "PS1404",
        "COP-1404_plate1.csv"     = "PS1408",
        "COP-1406.csv"            = "PS1502",
        "IBS01-1401-1_plate2.csv" = "PS1404",
        "IBS01-1401-1_plate3.csv" = "PS1404",
        "IBS01-1401-1_plate4.csv" = "PS1404"
    )
    for( f in csv.files ) {
        context( basename(f) )
        j <- sub( ".csv$", ".json", f )
        j <- sub( "/csv/", "/json/", j)
        b <- NULL
        if( basename(f) %in% names(batches) ) {
            b <- batches[ basename(f) ]
        }
        else {
            b <- "PS0000"
        }
        names(b) <- NULL
        l <- prepare.biocode.testdata( f, batch=b )
        check.json( l, j )
    }
}
