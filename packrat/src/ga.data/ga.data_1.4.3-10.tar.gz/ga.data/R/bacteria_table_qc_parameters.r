##' Report the bacteria table qc parameters
##'
##' List the qc parameters necessary to perfrom QC based on bacteria table
##' @title bacteria table based qc parameters
##' @return list
##' @author Torbjørn Lindahl
##' @importFrom jsonlite fromJSON
##' @export
bacteria.table.qc.parameters <- function() {

    f <- system.file(
      "bacteria_table_qc.json",
      package="ga.data",
      mustWork=TRUE
      )

    json <- read_file(f)

    fromJSON(json)

}
