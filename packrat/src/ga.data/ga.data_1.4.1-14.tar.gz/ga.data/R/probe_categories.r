##' Report probe importance for a number of probes
##'
##' Looks up the provided probes in the probe category definition and
##' returns category
##' @title probe importance category
##' @return importance category for each probe
##' @author Torbjørn Lindahl
##' @export
##' @param ... one or more probes to lookup
probe.importance <- function( ... ) {

    prns <- probe.numbers( unlist(list(...) ))

    m <- probe.category.definition()

    importances <- sapply( prns, function(prn) {
        i <- sapply( names(m), function(n) {
            prn %in% m[[n]]
        })
        names(m)[i][1]
    })

}

##' Probe category definitions
##'
##' A simple list wiht probes that belong to each category, currently
##' uses 'Normal', 'High' and 'Critical'
##' @title probe category definition lists
##' @return list with named category titles, each with a vector of
##'     probe numbers
##' @author Torbjørn Lindahl
##' @export
##' @importFrom readr read_file
probe.category.definition <- function() {

    f <- system.file(
        "probe_categories.json",
        package="ga.data",
        mustWork=TRUE
    )

    json <- read_file(f)

    jsonlite::fromJSON(json)

}

##' probes with category 'Critical'
##'
##' Lists probes with category 'Critical'
##' @title critical probes
##' @return probe codes of critical probes
##' @author Torbjørn Lindahl
##' @export
critically.important.probes <- function() {

    m <- probe.category.definition()

    probe.codes( m$Critical )

}

##' probes with category 'High'
##'
##' Lists probes with category 'High'
##' @title high probes
##' @return probe codes of high probes
##' @author Torbjørn Lindahl
##' @export
highly.important.probes <- function() {

    m <- probe.category.definition()

    probe.codes( m$High )

}

##' probes with category 'Normal'
##'
##' Lists probes with category 'Normal'
##' @title normal probes
##' @return probe codes of normal probes
##' @author Torbjørn Lindahl
##' @export
normally.important.probes <- function() {

    m <- probe.category.definition()

    probe.codes( m$Normal )

}
