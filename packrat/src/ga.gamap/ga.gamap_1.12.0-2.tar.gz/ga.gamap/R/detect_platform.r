##' detect instrument plaform
##'
##' Accepts lines read from file and checks for known patterns for known platforms.
##'
##' lx200: Looks for "SN","LX\\d+"
##' biocode: Looks for "SN","None"
##' magpix: Looks for "Program".*"MAGPIX"
##'
##' Returns NULL if platform is unknown
##' @title detect platform
##' @param x lines from file to test
##' @return string indicating platform, either "lx200" or "biocode"
##' @author Torbjørn Lindahl
detect.platform <- function(x) {

    if( !is.character(x) || length(x) < 12 )
        stop( "Invalid input, shold be at least 12 lines from the csv file" )

    ## lx200
    if( sum( grepl( '^"SN","LX\\d+"$', x ) ) == 1 ) {
        return( "lx200" )
    }

    ## biocode
    if( sum( grepl( '^"SN","None"$', x ) ) == 1 ) {
        return( "biocode" )
    }

    ## magpix
    if( sum( grepl( '^"Program".*"MAGPIX"', x ) ) == 1 ) {
        return( "magpix" )
    }

    return(NA_character_)

}

##' Guess platform of each of a vector of filenames
##'
##' Checks inside each file to try to determine what platform it
##' is. Uses \link{detect.platform} for this.
##'
##' Returns one of "biocode", "magpix", "lx200" for each file
##' @title detects platform from files
##' @param x files to guess platform from
##' @return character with platform indicators
##' @author Torbjorn Lindahl
##' @export
detect.platform.from.file <- function(x) {

    sapply( x, function(file) {
        try( detect.platform( readLines( file, n=20 ) ) )
    })

}
