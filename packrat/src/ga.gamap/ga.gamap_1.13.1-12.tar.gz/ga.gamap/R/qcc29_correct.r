##' qcc29 correction
##'
##' Perfroms QCC29 correction on matrix x, typically created with
##' \code{gamap( ..., stop.at="hyb" )}.
##'
##' The function looks for a 'plate' attribute and uses that to do
##' within-plate QCC29 correction on the input matrix.
##'
##' QCC29 samples are identified from rownames on input matrix x,
##' using the regular expression provided.
##'
##' For the 'mean' variant, the correction is then performed by
##' subtracting all samples on the plate with the mean of the QCC29
##' samples for each probe.
##'
##' For the 'regression' variant, a simple linear regression is
##' performed with the QCC29 samples on the plate, and this is used
##' for correction. This requires (and checks), that no samples are
##' positioned outside of the QCC29 samples on the plate.
##'
##' Any negative values following this operation are set to zero.
##' @title qcc29 correction
##' @return data after qcc29 correction
##' @author Torbjørn Lindahl
##' @param x Data to perform QCC29 correction on. It needs to include
##'     QCC29 samples
##' @param qcc29.rx Regex to identify the QCC29 samples by. Defaults
##'     to ^QCC29 (eg. caps required)
##' @param variant What type of correction to perform. Currently only
##'     'mean' is supported.
##' @param warn.if.plate.not.found Logical, default TRUE. Warn if no
##'     'plate' attribute is found on the data
##' @param x.variable.by optional, an x-index regime, currently
##'     supports 'order', 'row' and 'column'. Set the x-value for the
##'     regression from this. 'order' would use the order of the
##'     sample in the file as the x-value. 'row' or 'column' uses this
##'     as the x-value with the exception that empty rows and columns
##'     are not counted.
##' @param meta.data optional meta data. If it is the same size as x,
##'     contains vectors $Sample and $Col, then these vectors are
##'     assumed to be sample names and column values for the samples
##'     in x. This is used to qualify use of QCC29 correction by
##'     regression.
##' @importFrom stats lm predict
##' @export
qcc29.correct <- function( x, qcc29.rx = "^QCC29", variant=c("mean","regression"),
                          warn.if.plate.not.found=TRUE, x.variable.by=c("order","row","column"), meta.data
                          ) {

    has.meta.data <- !missing(meta.data) && !is.null(meta.data)

    plate <- attr( x, "plate" )

    variant <- match.arg( variant )

    if( is.null( plate ) && warn.if.plate.not.found ) {
        warning( "'plate' not found as an attribute -> will assume all samples were run on the same plate" )
        plate <- rep( 1, nrow(x) )
    }

    if( length(plate) != nrow(x) )
        stop(sprintf(
            "Plate vector of data (%d elements) does not match data size (%d rows)",
            length(plate), nrow(x)))

    if( is.null(rownames(x) ))
        stop( "The 'x' argument must have rownames" )

    up <- unique( plate )
    x2 <- x
    i.29 <- grepl( qcc29.rx, rownames(x) )

    for( p in up ) {

        variant.i <- variant

        i.p <- plate == p
        i.29.i <- i.29[ i.p ]

        ii <- i.p & i.29

        if( any(ii) ) {

            if( variant.i == "regression" ) {

                x.variable.by <- match.arg( x.variable.by )

                if( !x.variable.by %in% "order" ) {
                    warning( "Currently only regression by x-value by order is supported" )
                    x.variable.by <- "order"
                }

                ## Calculate an index along all samples on the plate
                idx <- 1:sum(i.p)

                ## indeces of the other samples on this plate
                i.non.qcc <- grep( "^QCC", rownames(x)[i.p], invert=TRUE )
                column.check <- FALSE
                count.check <- sum(ii) >= 2

                ## if qcc29 are in columns 1||2, and 11||12, then we're good anyway
                if(has.meta.data && nrow(meta.data) == nrow(x) && all("Col" %in% colnames(meta.data)) ) {

                    meta.i <- meta( meta.data )[ ii, ]
                    columns.29 <- meta.i[,"Col"]

                    min.col <- min( meta.i$Col )
                    max.col <- max( meta.i$Col )

                    ## recalculate x values for qcc29
                    meta.p <- meta.data[i.p,]
                    idx <- rank( meta.p$Well )
                    idx.29 <- idx[ i.29.i ]

                    if( any(c(min.col,min.col+1) %in% columns.29 && any( c(max.col-1,max.col) %in% columns.29 )) ) {
                        column.check <- TRUE
                    }
                } else {
                    warning( "Don't have meta.data to gow ith the regression based qcc29 correction. This is generally considered unsafe" )
                }

                idx.29 <- idx[ i.29.i ]

                if( !count.check ) {
                    warning(sprintf("Don't have enough QCC29 samples on plate %s, need at least 2. Reverting to mean", p ))
                } else if( !column.check && any(i.non.qcc < min(idx.29)) && any(i.non.qcc > max(idx.29)) ) {
                    warning( sprintf("Non-QCC samples on plate %s found outside the range of the QCC29 samples - reverting to mean correction", p ))
                    variant.i <- "mean"
                } else {

                    data.i <- x[ ii, , drop=FALSE ]
                    i.na.ok <- colSums(!is.na(data.i)) >= 2

                    if(any(i.na.ok)) {

                        m <- try( lm( y ~ x, data=data.frame( y = I(data.i[,i.na.ok]), x=idx.29) ) )

                        if( inherits(m, "try-error" ) )
                            browser()

                        qcc29.estimate <- predict( m, newdata=data.frame( x = idx ) )

                        x2[ i.p, i.na.ok ] <- x[ i.p, i.na.ok, drop=FALSE ] - qcc29.estimate

                    }

                    if( any(!i.na.ok) ) {
                        x2[ i.p, !i.na.ok ] <- NA
                    }

                }

            }

            if( variant.i == "mean" ) {

                x.29 <- colMeans( x[ ii,, drop=FALSE ] )
                x2[ i.p, ] <- sweep( x[ i.p, ], 2, x.29, FUN="-" )

            }

        } else {
            warning( sprintf("No QCC29 samples found for plate %s - this plate did not get corrected", p) )
        }

    }

    x2[ x2 < 0 ] <- 0

    return( x2 )

}
