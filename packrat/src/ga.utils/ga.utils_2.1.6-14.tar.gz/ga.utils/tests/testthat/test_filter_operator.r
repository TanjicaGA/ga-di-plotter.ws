library(ga.utils)

context( 'Normal filtering' )

test_that( 'Vectors can be filtered', {

    v <- 1:20

    v[10] <- NA
    expect_equal( sum(v %>>% is.na), 1 )

    v[11] <- NA
    expect_equal( sum(v %>>% is.na), 2 )

})

test_that( 'Vector can be assigned to', {

    v <- 1:20

    v[10] <- NA

    v %>>% is.na <- 0

    expect_true( !anyNA(v) )

})

test_that( 'Vectors can be assigned to and filtered with regex', {

    v <- LETTERS[1:10]
    expect_equal( v %>>% "[A-C]", c(rep(TRUE,3),rep(FALSE,7)) )

    v %>>% "[A-C]" <- 1:3
    
    expect_equal( v, c("1","2","3",LETTERS[4:10]) )
    
})
