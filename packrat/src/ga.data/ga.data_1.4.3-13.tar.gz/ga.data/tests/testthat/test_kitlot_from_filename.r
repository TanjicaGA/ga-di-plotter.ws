library(testthat)
library(ga.data)

context( "kitlot from filename" )

test_that( "kitlot can be found in filename", {

    expect_equal( kitlot.from.filename("Q2-012 L1921 LX1819 LO.csv"), "L1921" )
    expect_equal(
        kitlot.from.filename(c("Q2-012 L1921 LX1819 LO.csv","Q2-011 L1817_III LX1734 VWP.csv")),
        c("L1921","L1817")
    )

    expect_error( kitlot.from.filename("Q2-011 L1920_L1921 New buffer LX1734 LO.csv"), "many" )
    expect_warning( kitlot.from.filename("Q2-011 L1920_L1921 New buffer LX1734 LO.csv", how.to.handle.many.matches="warn") )
    expect_equal( kitlot.from.filename("Q2-011 L1920_L1921 New buffer LX1734 LO.csv", how.to.handle.many.matches="first"), "L1920")

})
