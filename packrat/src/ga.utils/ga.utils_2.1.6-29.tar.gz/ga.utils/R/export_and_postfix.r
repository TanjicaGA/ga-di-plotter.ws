##' Export variables from an environment into another environment with
##'
##' Exports variables from one environment to another with an optional
##' postfix applied to all variable names
##' @title export all objects in environment into callers space or a
##'     specified environment
##' @return variable names exportedf, with their postfixed name
##' @author Torbjørn Lindahl
##' @export
##' @param envir environment to export variables from
##' @param postfix optional postfix to append to variable names
##' @param where what environment to export the variables to
export.and.postfix <- function( envir, postfix = "", where = parent.frame() ) {

    vars <- sapply( ls(envir), function(n) {
        new.name <- paste0( n, postfix )
        assign( new.name, get(n,envir), envir=where )
        new.name
    })

    names(vars) <- ls(envir)

    invisible(vars)

}
