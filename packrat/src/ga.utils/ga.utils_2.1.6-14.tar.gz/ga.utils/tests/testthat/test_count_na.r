library(ga.utils)

context("count.na() counts na")

test_that( "basic usage", {

  test.matrix <- matrix( 1:16, nrow=4 )
  test.matrix[ 1, 2 ] <- NA
  test.matrix[ 2, 3 ] <- NA

  expect_that(
    count.na( test.matrix ),
    equals( c(0,1,1,0) )
    )

  expect_that(
    count.na( test.matrix, 2 ),
    equals( c(0,1,1,0) )
    )

  expect_that(
    count.na( test.matrix, 1 ),
    equals( c(1,1,0,0) )
    )

  expect_that(
    count.na( NULL, 2 ),
    throws_error("positive length")
    )

})
