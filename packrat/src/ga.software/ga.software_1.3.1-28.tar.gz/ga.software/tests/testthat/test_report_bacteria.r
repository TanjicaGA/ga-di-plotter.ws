context( "report bacteria names" )

test_that( "data seems right", {

    bn <- report.bacteria.names()

    ## There should be 39 names
    expect_length( bn, 39 )

    ## All names should be 3 digit codes
    expect_true( all( grepl( "^\\d{3}$", names(bn) ) ) )

    ## None of the names should be the emtpy string
    expect_true( !any( unlist(bn) == "" ) )

    ## all codes and names should be unique
    expect_length( unique(bn), 39 )
    expect_length( unique(names(bn)), 39 )

})
