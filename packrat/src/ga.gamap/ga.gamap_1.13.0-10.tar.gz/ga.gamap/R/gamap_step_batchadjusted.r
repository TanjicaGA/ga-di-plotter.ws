##' Batchadjustment step of gamap
##'
##' Batchadjustment step of gamap. Essentially corrects back to the
##' BioCode step. An important change has been introduced with this.
##'
##' For Lx200 files, the 'batchcorrection' step corrects back to
##' PS1801L.
##' @title Batchadjustment step of gamap
##' @param input qcc30 adjusted data
##' @param batch batch name to use
##' @param platform platform that the data originated from, typically
##'     'biocode' or 'lx200'
##' @return batchadjusted data from the input
##' @author Torbjørn Lindahl
##' @importFrom ga.data batch.correction
##' @importFrom ga.batchcorrection correct
##' @importFrom ga.batchcorrection inverse.correct
##' @importFrom ga.data lx200.missing.probes
gamap.step.batchadjusted <- function( input, batch, platform ) {

    if( inherits( batch, "batchcorrection" ) ) {

        output <- correct( batch, input )
        attr( output, "batches.used.for.correction" ) <-
            rep( batch$kitlot, nrow(output) )

    }
    else {

        output <- input

        if( length(batch) == 1 ) {
            batch <- rep( batch, nrow(input) )
        }

        for( b in unique(batch) ) {
            i <- batch %in% b
            bcf <- batch.correction(b)
            output[i,] <- correct( bcf, output[i,] )
        }

        attr( output, "batches.used.for.correction" ) <- batch

    }

    ## Accomodate for missing values for lx200
    p <- lx200.missing.probes( colnames(output) )
    pl <- attr( input, "platform" )

    if( missing(platform) ) {
        if( is.null(pl) ) {
            warning( "gamap.step.batchadjustment: platform not supplied as argument or a named attribute of the input data to gamap.step.batchadjusted, using 'biocode'" )
            pl <- rep("biocode", nrow(input) )
        }
    } else {
        if( length(platform) == 1 ) {
            pl <- rep( "biocode", nrow(input) )
        }
        else if( length(platform) != nrow(input) ) {
            stop( sprintf(
                "gamap.step.batchadjusted: The supplied platform argument (%d values) does not match the data size (%d rows)" ,
                length(platform), nrow(input)
            ))
        }
        else {
            pl <- platform
        }
    }

    jj <- pl %in% "lx200"

    ## Insert average values from the norm ref population model to
    ## impute probes not in lx200
    if( any(jj) && all(is.na(output[jj,p] ))) {
        pca <- ga.data::model.pca()
        cv <- pca$center
        output[ jj, p ] <- rep( cv[p], each=nrow(output[jj,]) )
    }

    return( output )

}
