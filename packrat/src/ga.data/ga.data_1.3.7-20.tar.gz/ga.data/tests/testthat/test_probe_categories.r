library(ga.data)

context( "probe categories" )

test_that( "categories have the right probes", {

    expect_equal(
        sort( critically.important.probes() ),
        sort(

            c("AG0865", "AG1226", "AG0377", "AG0651", "IG0053",
              "AG0703", "IG0020", "IG0005", "IG0133", "AG0815")

        )
    )

    expect_equal(
        sort( highly.important.probes() ),
        sort(

            c("IG0028", "AG1225", "IG0060", "AG1099", "IG0023",
              "IG0012", "IG0058", "AG0515", "AG0930", "AG0581",
              "AG0974", "AG0608", "AG0638", "AG1034", "AG1687",
              "AG1152", "IG0079", "IG0044", "AG1698")

        )
    )

    expect_equal(
        sort( normally.important.probes() ),
        sort(

            c("IG0314", "AG0416", "AG0863", "AG0686", "AG0895",
              "AG0931", "AG0620", "AG1061", "IG0081", "AG0732")

        )
    )

})

test_that( "arbitrary category lookups work", {

    expect_equal(
        probe.importance( "AG0651" ),
        c("Critical")
    )

    expect_equal(
        probe.importance( "AG0651","AG0651" ),
        c("Critical","Critical")
    )

    expect_equal(
        probe.importance(

            c("AG0865", "AG1226", "AG0377", "AG0651", "IG0053",
              "AG0703", "IG0020", "IG0005", "IG0133", "AG0815")

        ),

        c("Critical","Critical","Critical","Critical","Critical",
          "Critical","Critical","Critical","Critical","Critical")

    )

    expect_equal(
        probe.importance( "IG0058" ),
        c("High")
    )

    expect_equal(
        probe.importance( "IG0058","IG0058" ),
        c("High","High")
    )

    expect_equal(
        probe.importance(

            c("IG0028", "AG1225", "IG0060", "AG1099", "IG0023",
              "IG0012", "IG0058", "AG0515", "AG0930", "AG0581",
              "AG0974", "AG0608", "AG0638", "AG1034", "AG1687",
              "AG1152", "IG0079", "IG0044", "AG1698")

        ),

        c("High","High","High","High","High","High","High","High",
          "High","High","High","High","High","High", "High","High",
          "High","High","High")

    )

    expect_equal(
        probe.importance( "AG1061" ),
        c("Normal")
    )

    expect_equal(
        probe.importance( "AG1061","AG1061" ),
        c("Normal","Normal")
    )

    expect_equal(

        probe.importance(

            c("IG0314", "AG0416", "AG0863", "AG0686", "AG0895",
              "AG0931", "AG0620", "AG1061", "IG0081", "AG0732")

        ),

        c("Normal","Normal","Normal","Normal","Normal","Normal",
          "Normal","Normal", "Normal","Normal")

    )

    ## the entire profile
    expect_equal(
        probe.importance(

            c("AG0342", "AG0377", "AG0393", "AG0396", "AG0416",
              "AG0515", "AG0581", "AG0608", "AG0620", "AG0638",
              "AG0651", "AG0686", "AG0703", "AG0732", "AG0777",
              "AG0815", "AG0854", "AG0863", "AG0865", "AG0895",
              "AG0912", "AG0930", "AG0931", "AG0974", "AG1034",
              "AG1046", "AG1061", "AG1099", "AG1118", "AG1152",
              "AG1225", "AG1226", "AG1267", "AG1647", "AG1652",
              "AG1661", "AG1687", "AG1698", "IG0005", "IG0011",
              "IG0012", "IG0020", "IG0023", "IG0028", "IG0044",
              "IG0053", "IG0058", "IG0060", "IG0063", "IG0079",
              "IG0081", "IG0133", "IG0197", "IG0314", "UNI05",
              "HYC01", "BLANK1", "BLANK2")

        ),

        c(NA, "Critical", NA, NA, "Normal", "High", "High", "High", "Normal",
          "High", "Critical", "Normal", "Critical", "Normal", NA, "Critical",
          NA, "Normal", "Critical", "Normal", NA, "High", "Normal", "High",
          "High", NA, "Normal", "High", NA, "High", "High", "Critical",
          NA, NA, NA, NA, "High", "High", "Critical", NA, "High", "Critical",
          "High", "High", "High", "Critical", "High", "High", NA, "High",
          "Normal", "Critical", NA, "Normal", NA, NA, NA, NA)

    )

})
