##' Create xls file with batch correction data
##'
##' Create xls file with batch correction data. Uses the psf.name name
##' in the object as filename if 'where' argument is path to a
##' directory.
##' @title write out batch xls
##' @param bcf batch correction object
##' @param where where to put the file, may be a filename or a
##'     directory. If it's a directory, the filename will be auto
##'     generated from the psf.name name, ie PS1512 will become
##'     PS1512.xls
##' @param verbose logical default TRUE, say things
##' @param force logical default TRUE, overwrite existing file
##' @param digits number of digits for floating point numbers, default
##'     25
##' @param csv2xls path to csv2xls script, will be looked up in path
##'     if missing
##' @return invisible data.frame, returns the content written to the
##'     xls file
##' @author Torbjørn Lindahl
##' @export
batch_xls <- function( bcf, where="./", verbose=TRUE, force=FALSE, digits=25, csv2xls ) UseMethod("batch_xls")

##' @export
##' @importFrom ga.utils say
##' @importFrom ga.data probe.set
##' @importFrom stats coef
##' @importFrom utils capture.output
batch_xls.batchcorrection <- function( bcf, where="./", verbose=TRUE, force=FALSE, digits=25, csv2xls ) {

    if( missing( csv2xls ) ) {
        csv2xls <- Sys.which( "csv2xls" )
    }

    if( dir.exists(where) ) {
        fpart <- paste0( bcf$psf.name, ".xls" )
        where <- file.path( where, fpart )
    }

    if( grepl( "\\.xlsx", where ) )
        stop( "Requires a .xls suffix on the file" )

    if( !grepl( "\\.xls$", where ) ) {
        warning( "Added a .xls suffix" )
        where <- paste0( where, ".xls" )
    }

    if( file.exists( where ) ) {

        if( !force ) {
            stop( "File exists - wont overwrite without force" )
        }
        else if( verbose ) {
            say( "File exists, overwriting..." )
        }

    }

    f <- function(x){
        i <- !x %in% c(1,0)
        x[i] <- sprintf( paste0("\"%.",digits,"f\""), x[i] )
        x[!i] <- paste0('"',x[!i],'"')
        x
    }

    cf <- coef(bcf)
    pr <- probe.set("ibs3",include.technical = FALSE)

    if( bcf$type == "difference" ) {

        n <- names(cf)
        if( length(n) != 54 ) {
            if( all(grepl("^[AI]G\\d{4}$", n ))) {
                m <- match( pr, n )
                v <- cf[m]
                names(v) <- pr
                v[is.na(v)] <- 0
                cf <- v
            } else {
                stop("PSF correction vector isn't 54 probes long and doesn't have [AI]G probe codes only (so cannot know how to align it to matach ibs3)")
            }
        }

        dd <- data.frame( Correction=cf,
                         Shift=1, Scale=1,
                         stringsAsFactors=FALSE)

    }
    else if( bcf$type == "log.scale" ) {

        cf <- .align.coef.table.to.ibs3(cf)

        d <- as.data.frame(t(cf))
        dd <- data.frame(
            Correction=0,
            Shift=d$sft, Scale=d$shr,
            stringsAsFactors=FALSE
        )
    }
    else if( bcf$type == "exponential" ) {

        cf <- .align.coef.table.to.ibs3(cf)

        d <- as.data.frame(t(cf))
        dd <- data.frame(
            Correction=0,
            Shift=d$sft, Scale=d$shr,
            stringsAsFactors=FALSE
        )
    }
    else if( bcf$type == "null" ) {
        dd <- data.frame(
            Correction=0,
            Shift=1, Scale=1,
            stringsAsFactors=FALSE )
    }
    else {
        stop(paste("Unknown batch correction type:", bcf$type ))
    }

    rownames(dd) <- NULL

    dd.xls <- dd
    for( n in names(dd.xls)) dd.xls[,n] <- f(dd.xls[,n])
    dd.xls <- as.matrix( dd.xls )

    to.csv <- c(
        c("\"Correction\",\"Shift\",\"Scale\""),
        apply( dd.xls, 1, function(r)paste(r,collapse=",") )
    )

    tmp.csv <- tempfile( fileext = ".csv" )
    writeLines( to.csv, con=tmp.csv )

    target.xls <- sub(".xls$","",where)

    stderr <- capture.output(
        output <- system(
            paste( shQuote(c( csv2xls, "-f", "-n", "BCF", "-o", target.xls, tmp.csv )), collapse=" "),
            ignore.stderr = TRUE,
            intern=TRUE
        ), type = "message" )

    if(!file.exists(where) ) {
        stop( "Failed writing xls file" )
    }

    if( verbose ) {
        say( "Wrote", normalizePath(where) )
    }

    unlink( tmp.csv )

    invisible(dd)

}

##' @importFrom ga.data probe.set
.align.coef.table.to.ibs3 <- function(cf) {

    pr <- probe.set("ibs3",include.technical = FALSE)

    if( ncol(cf) != 54 ) {

        if( all(grepl("^[AI]G\\d{4}$",colnames(cf))) ) {

            d2 <- matrix( nrow=2, ncol=54, dimnames=list( rownames(cf), pr ) )
            m <- match( colnames(d2), colnames(cf) )
            d2[,] <- cf[,m]
            d2[ is.na(d2) ] <- 1

            cf <- d2

        } else {
            stop("PSF correction vector isn't 54 probes long and doesn't have [AI]G probe codes only (so cannot know how to align it to matach ibs3)")
        }

    }

    cf
}
