library(ga.utils)

context("Normal grep1")

test_that( "Simple usage works", {

    expect_equal(
      grep1( "A", LETTERS, value=TRUE ),
      "A"
      )

    expect_error(
      grep1( "A|B", LETTERS, value=TRUE ),
      "more than"
      )

    expect_equal(
      grepl1( "A", LETTERS[1:4] ),
      c(TRUE,FALSE,FALSE,FALSE)
      )

    expect_error(
      grep1( "A|B", LETTERS[1:4], value=TRUE ),
      "more than"
      )

})

test_that( "Names are handled correctly", {

    ll <- LETTERS[1:3]
    names(ll) <- paste0("L",1:3)

    expect_equal(
      grepl1( "B", ll ),
      c(FALSE,TRUE,FALSE)
      )

    expect_equal(
      grep1( "B", ll ),
      c(2)
      )

    expect_equal(
      grep1( "B", ll, value=TRUE ),
      c("L2"="B")
      )

})

context( "Grep1 many values" )

test_that( "more than one input works", {

    ll <- LETTERS[1:3]
    names(ll) <- paste0("L",1:3)

    expect_equal(
      grep1( c("A", "C"), ll ),
      c(1,3)
      )

    expect_equal(
      grep1( c("A", "C"), ll, value=TRUE ),
      c("L1"="A", "L3"="C")
      )

    expect_equal(
      grepl1( c("A","C"), ll ),
      c(TRUE,FALSE,TRUE)
      )

})
