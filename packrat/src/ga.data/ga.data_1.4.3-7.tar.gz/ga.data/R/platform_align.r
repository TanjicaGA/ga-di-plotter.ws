##' Align argument to work with other platform
##'
##' Umbrella method for obejcts that can be aligned (typically by
##' adding or removing probes) between platforms
##' @title align between platforms
##' @param x object to align
##' @param ... extra arguments passed to and from methods
##' @return result of alignment
##' @author Torbjørn Lindahl
##' @export
platform_align <- function( x, ...) {
    UseMethod("platform_align")
}

##' align batch correction to other format
##'
##' Align a batch correction object to match the columns of a given
##' platform. If no platform is specified, it detects the current
##' platform and adjusts to the other.
##'
##' If aligning a 48 column batch correction, it inserts neutral
##' values for the 6 extra probes.
##' @title aligh batch correction object
##' @param x batch correction object to align
##' @param to.platform platform to align to, one of "lx200" or
##'     "biocode"
##' @param ... arguments passed to and from methods
##' @return batch correction factor adjusted to something else
##' @author Torbjørn Lindahl
##' @importFrom stats coef
##' @export
platform_align.batchcorrection <- function( x, to.platform, ... ) {

    cf <- coef(x)

    cn <- sort( colnames(cf) )
    lx200 <- sort( lx200.probes(include.technical=FALSE) )
    bioc <- sort( probe.set("ibs3", include.technical=FALSE) )

    if( missing( to.platform ) ) {
        if( identical( cn , lx200 ) ) {
            to.platform <- "biocode"
        }
        else if( identical( cn , bioc ) ) {
            to.platform <- "lx200"
        }
        else {
            stop( "Failed detecting current platform of batch correction object, thus can't guess what to transform it to" )
        }
    }

    if( !to.platform %in% c("lx200","biocode") ) {
        stop( "to.platform should be one of 'lx200' or 'biocode'" )
    }

    if( to.platform == "lx200" ) {
        cf2 <- cf[, colnames(cf) %in% lx200 ]
        x$coefficients <- cf2
    }
    else if( to.platform == "biocode" ) {
        cf2 <- array( 1, dim=c(2, length(bioc) ) )
        m <- match( colnames(cf), probe.set("ibs3", include.technical=FALSE) )
        cf2[,m] <- cf
        rownames(cf2) <- rownames(cf)
        colnames(cf2) <- probe.set("ibs3", include.technical=FALSE)
        x$coefficients <- cf2
    }

    return( x )

}
