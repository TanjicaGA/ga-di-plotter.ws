library(ga.utils)

context( "last_true" )

test_that( "last_true works",  {

    expect_equal( last_true( c(F,F,T) ), 3 )
    expect_equal( last_true( c(T,F,F) ), 1 )

    expect_equal( last_true( c(T,T,T) ), 3 )
    expect_equal( last_true( c(T) ), 1 )

    expect_equal( last_true( c(F,F,F) ), NA )
    expect_equal( last_true( c(F) ), NA )

    expect_equal( last_true( c(NA,NA) ), NA )

    expect_equal( last_true( c(F,NA,T) ), 3 )
    expect_equal( last_true( c(T,NA,F) ), 1 )
    expect_equal( last_true( c(F,NA,F) ), NA )
    expect_equal( last_true( c(T,NA,T) ), 3 )

    expect_equal( last_true( c(NA,NA,T) ), 3 )
    expect_equal( last_true( c(NA,NA,F) ), NA )
    expect_equal( last_true( c(NA,F,F) ), NA )
    expect_equal( last_true( c(NA,T,F) ), 2 )


})
