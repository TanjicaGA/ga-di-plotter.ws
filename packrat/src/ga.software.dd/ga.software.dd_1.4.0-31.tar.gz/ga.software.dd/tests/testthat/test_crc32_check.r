library(ga.software.dd)
library(testthat)

context( "crc32 check" )

test_that( "crc32 control works", {

    ## Control
    local({
        the.string <- "line 1
line 2
line 3

"
        toupper( digest::digest( the.string, algo="crc32", serialize=FALSE ) )
})

    foo <- "line 1
line 2
line 3

-- CRC --
CRC32: DA334063
"

    expect_true( ga.software.dd:::.check.crc32( foo ) )

})
