##' GA Logo colors
##'
##' The GA logo has 6 dots with colors ranging from orange to
##' gray. These area the 6 color codes.
##' @title The 6 colors in the 6 dots in the GA logo
##' @return a character vector of rgb strings
##' @author Torbjørn Lindahl
logo.colors <- function() {
    c( "#f57f22", "#f8a665", "#fbcca7", "#cbcacb", "#a4a3a4", "#7d7b7c" )
}
