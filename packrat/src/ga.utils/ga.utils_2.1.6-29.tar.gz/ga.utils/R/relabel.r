##' change values of a vector
##'
##' Changes values of a vector by a given translation table (typically
##' a character), using a name based lookup.
##'
##' Also handles factors, updating levels accordingly.
##' @title relabel
##' @param x data to relabel
##' @param ... extra arguments passed to and from methods
##' @return relabeled object
##' @author Torbjørn Lindahl
##' @export
relabel <- function(x, ... ) {
    UseMethod( "relabel", x )
}

relabel.character <- function(x, translation ) {

    if( is.null(names(translation)) || length(names(translation)) != length(translation) ) {
        stop( "All arguments to relabel need to be named" )
    }

    v <- as.character(x)

    for( i in seq_along(translation)) {
        n <- names(translation)[i]
        t <- translation[[i]]
        v[ v %in% n ] <- t
    }

    return( v )

}

relabel.factor <- function(x, translation ) {

    lvl <- levels(x)
    v <- as.character(x)

    f <- relabel.character(v, translation)
    lvl2 <- c(
        setdiff( lvl, names(translation) ),
        setdiff( f, v )
    )

    factor( f, levels=lvl2 )

}

relabel.default <- function(x, ... ) {
    return( relabel.character( x, ... ) )
}
