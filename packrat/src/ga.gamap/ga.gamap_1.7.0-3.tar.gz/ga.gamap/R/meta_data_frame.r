##' return non probe columns from data.frame
##'
##' returns only columns of a data.frame that do not look like known probe names
##' @title get columns that are not probe names from a data.frame
##' @param x data.frame
##' @param ... other arughments passed to and from methods
##' @return data.frame without probe data in it
##' @author Torbjørn Lindahl
##' @export
meta.data.frame <- function( x, ... ) {
    return( meta.gamap.file( x, ... ) )
}
