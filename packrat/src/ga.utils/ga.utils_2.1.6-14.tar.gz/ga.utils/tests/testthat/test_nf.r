library(ga.utils)

context( "nf" )

test_that( "normal usage work", {

    expect_equal(
        nf(LETTERS),
        seq_along(LETTERS)
    )

    expect_equal(
        nf( rep("A",65) ),
        rep(1, 65 )
    )

    expect_equal(
        nf( c("A","A","B","B") ),
        c( 1, 1, 2, 2 )
    )

})
