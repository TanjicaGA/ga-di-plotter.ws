library(ga.utils)

options(stringsAsFactors=FALSE)

context( "get.sample.names" )

test_that( "it fetches sample names correctly", {

    ## 'Sample' column from a data frame
    x1 <- data.frame( Sample=LETTERS, value=seq_along(LETTERS))
    rownames(x1) <- letters

    expect_equal(
        get.sample.names( x1 ),
        LETTERS
    )

    ## rownames from an array
    x2 <- array( dim=c(26,10), dimnames=list( letters, 1:10 ) )
    expect_equal(
        get.sample.names( x2 ),
        letters
    )


    ## names from a vector, or the vector itself its a character
    x3 <- seq_along(LETTERS)
    names(x3) <- letters

    ## if it's a vector that isn't a character, return its names
    expect_equal(
        get.sample.names( x3 ),
        letters
    )
    
    x3[] <- LETTERS
    ## if it's a character, return that
    expect_equivalent(
        get.sample.names(x3),
        LETTERS
    )
    
    ## if it doesn't have names, and isn't a character, throw
    expect_error(
        get.sample.names( 1L:2L )
    )
    
})
