##' Trim text columns in an array or data frame
##'
##' Iterates through an object and trims text vectores (removing leading and trailing whitespace)
##' @title trim text columns
##' @return object where text columns are trimmed
##' @author Torbjørn Lindahl
##' @importFrom gdata trim
##' @export
##' @param x input object
##' @param ... extra arguments to gdata::trim
trim_text_columns <- function(x, ... ) {

    if( is.data.frame(x) ) {
        chs <- which( sapply( 1:ncol(x), function(i)is.character(x[[i]]) ) )
        for( j in chs ){ x[[j]] <- trim(x[[j]], ... ) }
    }
    else if( !is.null(dim(x) ) ) {
        chs <- which( sapply( 1:ncol(x), function(i)is.character(x[,i]) ) )
        for( j in chs ){ x[,j] <- trim(x[,j], ... ) }
    }
    else {
        stop( "Invalid input to trim.text.columns: should be a data.frame or something with at least 2 dimensions" )
    }

    return( x )

}
