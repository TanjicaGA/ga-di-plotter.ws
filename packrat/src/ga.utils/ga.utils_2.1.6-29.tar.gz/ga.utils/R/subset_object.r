##' Subset an object and all its attributes
##'
##' A subset of the inpub object is returned, taking care to subset
##' all attributes that have a matching number of elements.
##'
##' If dimensionless, (dim is null), Any attribtue with the same
##' length as the input object is also subset'ed. If it has
##' dimensions, any attribute with whose dim()[1] matches the input
##' object is also subset'ed.
##'
##' The following attributes are always left untouched:
##' dimnames, names, class, dim and levels.
##' @title subset an object with attributes
##' @param x Input data to subset. Anything that could always be operated on with [ or [[.
##' @param idx Index of the subset, anything that could be put inside [...] or [[...]] to subset x.
##' @param warn.other.attributes Default TRUE, warns if it finds
##' attributes that does not match the dimensions of the input object
##' (and are thuse left untouched).
##' @param cleared.attributes Default empty, does not warn for
##' attribute names listed here.
##' @return A subset of x, according to idx.
##' @author Torbjørn Lindahl
##' @export subset_deep
subset_deep <- function(x, idx, warn.other.attributes=TRUE, cleared.attributes=c() ) {

    n <- object.element.count(x)

    if( is.logical(idx) && length(idx) != n ) {
        stop( "Length of logical idx doent match number of elements" )
    }
    else if( is.numeric(idx) && any(idx > n ) ){
        stop( "There are numeric indeces in idx that are higher than the number of elements" )
    }

    na <- setdiff( names( attributes(x) ), c("dimnames","names","class","dim","levels") )

    if( is.null(dim(x)) )
      x.new <- x[idx]
    else
      x.new <- x[idx,,drop=FALSE]

    for( nn in na ) {

        xx <- attr( x, nn )

        n2 <- object.element.count(xx)

        if( n2 == n ) {
            attr( x.new, nn ) <- subset_deep( xx, idx, cleared.attributes = cleared.attributes )
        }
        else {
            ## attr( x.new, nn ) <- xx
            if( is.logical(warn.other.attributes) ) {
                if( warn.other.attributes && ! nn %in% cleared.attributes )
                  warning( paste0("Not slicing attribute '",
                                  nn, "' because its dimentions doesn't match" ) )
            }
        }

    }

    class( x.new ) <- class(x)

    return( x.new )


}

##' The number of rows in an array or the length of a vector.
##'
##' If x has dim, returns the number of rows. If not returns the length.
##' @title Number of rows or elements
##' @param x object to count rows in
##' @return An integer, the count calculated.
##' @author Torbjørn Lindahl
object.element.count <- function(x) {

    if( is.null( dim(x) ) )
      n <- length(x)
    else
      n <- nrow(x)

    return( n )

}
