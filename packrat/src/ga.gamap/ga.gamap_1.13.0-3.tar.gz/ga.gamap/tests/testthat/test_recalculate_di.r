library(ga.gamap)
library(ga.utils)

lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )

context( "DI recalc" )

test_that( "DI recalculation works", {

    din <- gamap( lx200.file, batch="PS1901L" )
    set.qcc.indeces(din, verbose=FALSE)
    n <- names(din)
    i.p <- !i.qcc & din %between% c(2,3)
    i.n <- !i.qcc & din %between% c(1,2)

    ## 2 over and one under, the lower gets changed
    local({
        j <- c( which( i.p )[1:2], which(i.n)[1:1] )
        n[ j ] <- "MYDONOR"
        din.re <- recalculate.di.in.set( lx200.file, batch="PS1901L", group=n )
        expect_gt( din.re[j[3]], din[j[3]] )
        expect_equal( din.re[j[1:2]], din[j[1:2]] )
    })

    ## 2 under and one over, the higher gets changed
    local({
        j <- c( which( i.p )[3], which(i.n)[2:3] )
        n[ j ] <- "MYDONOR"
        din.re <- recalculate.di.in.set( lx200.file, batch="PS1901L", group=n )
        expect_lt( din.re[j[1]], din[j[1]] )
        expect_equal( din.re[j[2:3]], din[j[2:3]] )
    })

    ## 2 over and 2 under, the difference matters now, the upper side should be closer
    local({
        j <- c( which( i.p )[c(18,17)], which(i.n)[c(2,15)] )
        n[ j ] <- "MYDONOR"
        stopifnot( mean( din[j[1:2]] )-2 < 2-mean( din[j[2+(1:2)]] ) )
        din.re <- recalculate.di.in.set( lx200.file, batch="PS1901L", group=n )
        expect_lt( din.re[j[1]], din[j[1]] )
        expect_lt( din.re[j[2]], din[j[2]] )
        expect_equal( din.re[j[3:4]], din[j[3:4]] )
    })

    ## 2 over and 2 under, the difference matters now, this time the lower side should be closer
    local({
        j <- c( which( i.p )[c(1,11)], which(i.n)[c(10,11)] )
        n[ j ] <- "MYDONOR"
        stopifnot( mean( din[j[1:2]] )-2 > 2-mean( din[j[2+(1:2)]] ) )
        din.re <- recalculate.di.in.set( lx200.file, batch="PS1901L", group=n )
        expect_gt( din.re[j[3]], din[j[3]] )
        expect_gt( din.re[j[4]], din[j[4]] )
        expect_equal( din.re[j[1:2]], din[j[1:2]] )
    })

})
