library(ga.utils)

context( "relabel" )

test_that( "character vector gets relabeled", {

    v1 <- LETTERS[1:4]
    expect_equal(
        relabel(v1, list(A=1) ),
        c("1","B","C","D")
    )

    expect_equal(
        relabel(v1, list(A=1,D=4) ),
        c("1","B","C","4")
    )

    expect_equal(
        relabel(v1, list(A=1,B=2,C=3,D=4) ),
        c("1","2","3","4")
    )

})

test_that( "factor gets relabeled", {

    v1 <- LETTERS[1:4]
    f <- factor(v1)

    expect_equivalent(
        relabel(f, list(A=1) ),
        as.factor( c("1","B","C","D") )
    )

    expect_equivalent(
        relabel(f, list(A=1,D=4) ),
        factor( c("1","B","C","4") )
    )

    expect_equivalent(
        relabel(f, list(A=1,B=2,C=3,D=4) ),
        factor( c("1","2","3","4") )
    )



})
