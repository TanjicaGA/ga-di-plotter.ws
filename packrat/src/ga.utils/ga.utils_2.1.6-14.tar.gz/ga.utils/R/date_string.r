##' current date time as string
##'
##' Current datetime as an iso date
##' @title date string
##' @return character, current date time
##' @author Torbjørn Lindahl
##' @export
##' @param date.only report date, not including time
date.string <- function(date.only=FALSE) {
    if( date.only )
        return( format( Sys.time(), "%Y-%m-%d" ) )
    return( format( Sys.time(), "%Y-%m-%d %H:%M:%S" ) )
}
