##' matplot for ggplot2
##'
##' Does a melt on recognized probenames
##' @title something aking to a matplot in ggplot2
##' @return ggplot object
##' @author Torbjorn Lindahl
##' @importFrom reshape2 melt
##' @export
##' @param x data to plot
##' @param geom_aes optional aes to given geom
##' @param variables variables to melt
##' @param geom what geom to use, defaults to geom_line
##' @param add.geom logical default TRUE, if FALSE, don't add the geom
##' @param rotate.x.labels default TRUE, rotate x labels (eg. probe
##'     names)
##' @param ... other arguments to the geom
##' @importFrom ggplot2 geom_line
gg.matplot <- function(x,geom_aes,variables=colnames(x), geom=geom_line, add.geom=TRUE, rotate.x.labels=TRUE, ... ) {

    x2 <- cbind.data.frame( id=1:nrow(x), x )
    xm <- melt( x2, measure.vars=variables )

    if( add.geom ) {
        if(!missing(geom_aes))
            gl <- geom( geom_aes, ... )
        else
            gl <- geom( ... )
    }

    variable <- value <- id <- NULL

    g <- ggplot( xm, aes(x=variable,y=value,group=id) )

    if( add.geom )
        g <- g + gl

    if( rotate.x.labels )
        g <- g + gg_rotate_x_axis()

    return( g )

}
