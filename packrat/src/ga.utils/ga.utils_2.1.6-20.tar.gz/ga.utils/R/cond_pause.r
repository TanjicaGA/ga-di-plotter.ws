##' conditional pause
##'
##' prompts user for input unless current device is one of 'pdf' or
##' 'postscript'
##' @title conditional pause
##' @param ... argument to readline(c(...)) or cat(...)
##' @return nothing
##' @author Torbjorn Lindahl
##' @importFrom grDevices dev.cur
##' @export
cond.pause <- function(...) {
    pause.it <- !names(dev.cur()) %in% c("pdf","postscript") & !grepl("pdf", names(dev.cur()))

    if( exists( ".COND.PAUSE" ) )
      pause.it <- pause.it && as.logical( get(".COND.PAUSE") )

    if(pause.it)
        invisible(readline(c(...)))
    else
        cat( ..., "\n" )
}
