library(ga.gamap)
library(testthat)

context( "read research protocol analyte names" )

tf <- "data/rp/Luminex_#75_R_plate.csv"

test_that( "analyte names are read properly from RP files", {

    d <- gamap( tf, stop.at="file" )

    expect_true( inherits( d, "gamap.file" ) )

    di.raw <- gamap( d, start.from="file", stop.at="raw" )
    expect_equal( dim(di.raw), c(nrow(d), 54) )

})
