##' qcc29 correction
##'
##' Perfroms QCC29 correction on matrix x, typically created with
##' \code{gamap( ..., stop.at="hyb" )}.
##'
##' The function looks for a 'plate' attribute and uses that to do
##' within-plate QCC29 correction on the input matrix.
##'
##' QCC29 samples are identified from rownames on input matrix x,
##' using the regular expression provided.
##'
##' The correction is then performed by subtracting all samples on the
##' plate with the mean of the QCC29 samples for each probe.
##'
##' Any negative values following this operation are set to zero.
##' @title qcc29 correction
##' @return data after qcc29 correction
##' @author Torbjørn Lindahl
##' @param x Data to perform QCC29 correction on. It needs to include
##'     QCC29 samples
##' @param qcc29.rx Regex to identify the QCC29 samples by. Defaults
##'     to ^QCC29 (eg. caps required)
##' @param variant What type of correction to perform. Currently only
##'     'mean' is supported.
##' @param warn.if.plate.not.found Logical, default TRUE. Warn if no
##'     'plate' attribute is found on the data
##' @export
qcc29.correct <- function( x, qcc29.rx = "^QCC29", variant=c("mean","interpolated"), warn.if.plate.not.found=TRUE ) {

    plate <- attr( x, "plate" )

    variant <- match.arg( variant )

    if( variant != "mean" ) {
        stop( "Currently only the 'mean' variant of QCC29 correction is supported" )
    }

    if( is.null( plate ) && warn.if.plate.not.found ) {
        warning( "'plate' not found as an attribute -> will assume all samples were run on the same plate" )
        plate <- rep( 1, nrow(x) )
    }

    if( length(plate) != nrow(x) )
        stop(sprintf(
            "Plate vector of data (%d elements) does not match data size (%d rows)",
            length(plate), nrow(x)))

    if( is.null(rownames(x) ))
        stop( "The 'x' argument must have rownames" )

    up <- unique( plate )
    x2 <- x
    i.29 <- grepl( qcc29.rx, rownames(x) )

    for( p in up ) {

        i.p <- plate == p

        ii <- i.p & i.29

        if( any(ii) ) {
            x.29 <- colMeans( x[ ii,, drop=FALSE ] )
            x2[ i.p, ] <- sweep( x2[ i.p, ], 2, x.29, FUN="-" )
        } else {
            warning( sprintf("No QCC29 samples found for plate %s - this plate did not get corrected", p) )
        }

    }

    x2[ x2 < 0 ] <- 0

    return( x2 )

}
