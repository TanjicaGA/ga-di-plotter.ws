library(ga.utils)

context( "max.where" )

test_that( "max.where works", {

    v <- 11:20

    expect_equal(
        which.max.where( v ),
        10
    )

    expect_equal(
        which.max.where( v, v<16 ),
        5
    )

    expect_equal(
        which.max.where( v, v>16 ),
        10
    )

    which.max.where( v, v>20 )

    ## consistent with which()
    expect_equal(
        which.max.where( v, v>20 ),
        integer()
    )

})
