##' print method for qc object
##'
##' Prints the QC essentials
##' @title print for qc results
##' @param x qc result
##' @param ... not used, but included to match the signature of
##'     print.default
##' @return no return
##' @author Torbjørn Lindahl
##' @importFrom GetoptLong qq
##' @importFrom crayon red green yellow cyan
##' @importFrom utils getFromNamespace
##' @export
print.gamap.qc <- function( x, ... ) {

    i.qcc <- grepl( "^QCC", names(x) )

    sprintf.strings <- list()

    qc.text <- c(
        "FALSE" = "Fail",
        "TRUE" = "Pass",
        "NA" = "NA"
    )
    qc.col <- c(
        "NA" = "yellow",
        "Pass" = "green",
        "Fail" = "red"
    )
    v10 <- v1 <- c(" Sample",names(x[!i.qcc]))
    v20 <- v2 <- c(" QC", qc.text[ paste(x[!i.qcc]) ] )
    j <- v2 %in% names(qc.col)
    v2[ j ] <-
        sapply( v2[ j ], function(q) {
            getFromNamespace( qc.col[ q ], "crayon" )( q )
        })

    args0 <- list( Sample=v1, QC=v2 )
    sprintf.strings[["Sample"]] <- max( nchar( c("Sample",v10)))
    sprintf.strings[["QC"]] <- max( nchar( c("QC",v20)))

    i.qcfail <- x %in% FALSE & !i.qcc
    pd <- attr( x, "PlateData" )
    if( length(unique(pd$File)) > 1 ) {
        ## Add File to the output
        v <- basename(as.character(pd$File))[!i.qcc]
        v0 <- append( " File", v )
        sprintf.strings[["File"]] <-
            max( nchar( c("File", v)))
        args0[["File"]] <- v0
    }
    if( any(i.qcfail) ) {
        v30 <- v3 <- append(
            " Error",
            sapply(
                attr( x, "ErrorMessages" ),
                function(v){ paste( v, collapse = ", " ) }
            )[!i.qcc])
        v3[is.na(v3)] <- ""
        v3[-1] <- cyan(v3[-1])
        sprintf.strings[["Error"]] <- max(nchar( c("ErrorMessages",v30)))
        args0[["Error"]] <- v3
    }

    pt <- ""
    args <- list()
    known.names <- c("File","Sample","QC","Error")

    for( nn in known.names ) {

        if( nn %in% names(sprintf.strings) ) {

            if( pt != "" )
                pt <- paste0( pt, " " )

            s <- "-"

            pt <- paste0( pt, qq("%@{s}@{sprintf.strings[[nn]]}s") )

            args <- append( args, list( args0[[nn]] ) )

        }

    }

    pt <- paste0( pt, "\n" )
    args <- append( pt, args )

    cat( do.call( sprintf, args ) )

}
