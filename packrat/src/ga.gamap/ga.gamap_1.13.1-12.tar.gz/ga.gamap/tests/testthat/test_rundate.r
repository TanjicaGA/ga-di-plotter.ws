library(ga.gamap)

context( "rundates" )

test_that( "rundates are reported correctly", {

    rds <- rundate(
        c(
            "data/Lx200-TestfileA.csv",
            "data/Lx200-TestfileB.csv",
            "data/Biocode-TestFileA.csv",
            "data/LUM05-03-1601.csv"
        ))

    expect_equal(
        paste( rds ),
        c("2017-10-17 13:45:00", "2017-10-18 12:17:00",
          "2017-10-31 12:03:00", "2016-03-11 09:34:00")
    )

})
