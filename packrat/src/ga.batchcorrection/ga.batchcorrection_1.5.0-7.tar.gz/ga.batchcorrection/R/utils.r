##' Adjust sample names for batch correction
##'
##' Adjusts the sample names of new data to match the form they had in
##' the old data
##' @title Adjust sample names
##' @param x New data. Must have rownames.
##' @return changed names
##' @author Torbjørn Lindahl
##' @export
adjust.new.samplenames <- function( x ) {
    rn <- rownames(x)
    rn <- sub( "^PC (\\d+)", "PC_\\1", rn )
    rn
}
