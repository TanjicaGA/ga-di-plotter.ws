library(ga.utils)

add.name.func <- function(x) {
    rownames(x) <- 1:4
    colnames(x) <- LETTERS[1:4]
    return(x)
}
add.name.func2 <- function(x) {
    names(x) <- LETTERS[1:4]
    return(x)
}

for( add.names in c(FALSE,TRUE) ) {

    context( paste0( ifelse(add.names,"named","no name")," arrays and numeric" ) )

    x <- matrix( 1:16, 4 )
    if( add.names )
      x <- add.name.func(x)

    test_that( "normal lookups in matrices - numeric", {

        expect_that(
          subset_deep( x, 1:2 ),
          equals( x[1:2,] )
          )

        expect_that(
          subset_deep( x, 1:4 ),
          equals( x )
          )

        expect_that(
          subset_deep( x, 1 ),
          equals( x[1,,drop=FALSE] )
          )

    })

    test_that( "normal lookups in matrices - logical", {

        expect_that(
          subset_deep( x, c(TRUE,TRUE,FALSE,FALSE) ),
          equals( x[1:2,] )
          )

        expect_that(
          subset_deep( x, rep( TRUE,4 ) ),
          equals( x )
          )

        expect_that(
          subset_deep( x, c(TRUE,FALSE,FALSE,FALSE) ),
          equals( x[1,,drop=FALSE] )
          )

        expect_that(
          subset_deep( x, c(FALSE,FALSE,FALSE,FALSE) ),
          equals( x[integer(0),,drop=FALSE] )
          )

    })

    x <- 1:4
    if( add.names )
      x <- add.name.func2(x)

    test_that( "normal lookups in vectors - numeric", {

        expect_that(
          subset_deep( x, 1:2 ),
          equals( x[1:2] )
          )

        expect_that(
          subset_deep( x, 1:4 ),
          equals( x )
          )

        expect_that(
          subset_deep( x, 1 ),
          equals( x[1] )
          )

        expect_that(
          subset_deep( x, c(TRUE,TRUE,FALSE,FALSE) ),
          equals( x[1:2] )
          )

        expect_that(
          subset_deep( x, rep( TRUE,4 ) ),
          equals( x )
          )

        expect_that(
          subset_deep( x, c(TRUE,FALSE,FALSE,FALSE) ),
          equals( x[1] )
          )

        expect_that(
          subset_deep( x, c(FALSE,FALSE,FALSE,FALSE) ),
          equals( x[integer(0)] )
          )

    })

    test_that( "normal lookups in vectors - logical", {

        expect_that(
          subset_deep( x, c(TRUE,TRUE,FALSE,FALSE) ),
          equals( x[1:2] )
          )

        expect_that(
          subset_deep( x, rep( TRUE,4 ) ),
          equals( x )
          )

        expect_that(
          subset_deep( x, c(TRUE,FALSE,FALSE,FALSE) ),
          equals( x[1] )
          )

        expect_that(
          subset_deep( x, c(FALSE,FALSE,FALSE,FALSE) ),
          equals( x[integer(0)] )
          )

    })

}

context( "arrays with attributes" )

test_that( "matching attributes get sliced", {

    x <- matrix( 1:16, 4 )
    attr( x, "LETTER" ) <- LETTERS[1:4]


    expect_that(
      subset_deep( x, 1:2 ),
      equals( local({
          x2 <- x[1:2,]
          attr( x2, "LETTER" ) <- c("A","B")
          x2
          })))

    expect_that(
      subset_deep( x, 1:4 ),
      equals( x )
      )

    expect_that(
      subset_deep( x, 1 ),
      equals( local({
          x2 <- x[1,,drop=FALSE]
          attr( x2, "LETTER" ) <- "A"
          x2
          })))

});

test_that( "non-matching attributes are preserved", {

    x <- matrix( 1:16, 4 )
    attr( x, "LETTER" ) <- LETTERS[1:3]

    expect_that(
      subset_deep( x, 1:2, warn.other.attributes = FALSE ),
      equals( x[1:2,] )
      )

    expect_that(
      subset_deep( x, 1:4, warn.other.attributes = FALSE ),
      equals( x[1:4,] )
      )

    expect_that(
      subset_deep( x, 1, warn.other.attributes = FALSE ),
      equals( x[1,,drop=FALSE] )
      )

});
