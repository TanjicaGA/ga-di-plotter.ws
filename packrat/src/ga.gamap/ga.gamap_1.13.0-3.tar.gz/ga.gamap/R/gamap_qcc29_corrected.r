##' Reports QCC29 corrected and QCC30 normalized data corresponding to
##' PS1801L levels
##'
##' Goes through a careful list of meticulous steps to achieve QCC29
##' corrected data that handles batch differences.
##'
##' 1. Calculate batch corrected data
##'
##' 2. Adjust this to PS1801L levels
##'
##' 3. Inverse QCC30 normalize this (requires access to raw QCC30
##' profiles, these are found from the ... arguments)
##'
##' 4. Performs QCC29 correction on the resulting data
##'
##' 5. QCC30 normalizes this data
##' @title qcc29 corrected profiles
##' @param ... arguments as used with ga.gamap
##' @param dont.warn.deprecation if FALSE, don't warn about this
##'     deprecated way of normalizing data.
##' @return QCC30 normalized QCC29 corrected profiles
##' @author Torbjorn Lindahl
##' @export
gamap.qcc29.corrected <- function( ..., dont.warn.deprecation=FALSE ) {

    if(!dont.warn.deprecation) {
        .Deprecated(
            new="gamap.batchcorrect.qcc29", package="ga.gamap",
            "QCC29 correction is typically not done after batch correction any more"
        )
    }

    ## We need to know the original QCC30 values for the inverse QCC30
    ## normalization to take data back to hyb normalized data
    di.plate <- gamap( ..., stop.at="file" )
    di.batch <- gamap( ..., stop.at="batch" )

    ## This takes care of batch differences and standardizes it to
    ## PS1801L levels. This profile now represents QCC30 profiles
    ## within the PS1801L period.
    x.1801l <- ps1801l.normalize( di.batch, start.from="batch" )

    ## Get the plate indeces from the processed data
    attr( x.1801l, "plate" ) <- attr( di.batch, "plate" )

    ## Go back from QCC30 to HYB normalized data
    x.hyb <- inverse.qcc30.normalize( x.1801l, di.plate )

    ## Do the QCC29 correction
    x.hyb.qcc29 <- qcc29.correct( x.hyb )

    ## And go back to QCC30 normalized data
    l <- list( ... )
    l$x <- x.hyb.qcc29
    l$stop.at <- "qcc"
    l$start.from <- "hyb"

    x <- do.call( gamap, l )

    return( x )

}
