##' batch correct qcc29 corrected data
##'
##' Does the following:
##' 1) Follows normal algoritm to QCC30 correction
##' 2) Performs QCC29 correction on this
##' 3) Performs batch correction with especially cracted '.9' type batch correction objects
##' @title batch correct based on qcc29 corrected dat
##' @param ... arguments passed to gamap()
##' @param qcc29.correction.variant 'mean' or 'regression' - which qcc29 correction variant to perform
##' @param meta.data meta.data argument for qcc29.correct
##' @return qcc29 based batch corrected data
##' @author Torbjorn Lindahl
##' @importFrom ga.batchcorrection correct na.correction
##' @importFrom ga.data check.psf.name psf.exists psf.from.kitlot
##' @importFrom ga.utils look.up
##' @export
gamap.batchcorrect.qcc29 <- function( ..., qcc29.correction.variant=c("mean","regression"), meta.data=NULL ) {

    qcc29.correction.variant <- match.arg( qcc29.correction.variant )

    args <- list(...)
    batch <- args$batch

    if(is.null(batch)) {
        stop("'batch' argument missing")
    }

    di.qcc <- gamap( ..., stop.at="qcc" )
    di.qcc29 <- qcc29.correct( di.qcc, variant=qcc29.correction.variant, meta.data=meta.data )

    ## If batch is a batchcorrection object
    if( inherits( batch, "batchcorrection" ) ) {

        batch <- check.psf.name(batch)
        psf.name <- batch$psf.name
        if(!grepl("\\.9$", psf.name)) {
            batch <- try( batch.correction( paste0( psf.name, ".9" ) ), silent=TRUE )
            if( inherits( batch, "try-error" ) ) {
                batch <- na.correction()
            }
        }
        output <- correct( batch, di.qcc29 )
        attr( output, "batches.used.for.correction" ) <- rep( "NA", nrow(di.qcc29) )

    } else {

        output <- di.qcc29
        output[] <- NA

        if( length(batch) == 1 ) {
            batch <- rep( batch, nrow(di.qcc29) )
        }

        ## at first, start with no .9 names
        orig.batch <- batch
        batch <- sub( "\\.9$", "", batch )

        ## resolve all the kitlot/psf ids
        ub <- unique(batch)

        dd <- data.frame(
            kitlot=ub,
            psf=Vectorize( function(x){batch.correction(x)$psf.name} ) (ub),
            stringsAsFactors=FALSE
        )

        psfs <- look.up(
            batch,
            dd,
            from="kitlot",
            to="psf"
        )

        i <- !grepl( "\\.9$", psfs )
        psfs[i] <- paste0( psfs[i] , ".9" )
        up <- unique( psfs )
        dd <- cbind.data.frame( up, sapply( up, function(b){ psf.exists(b) } ))
        dd <- dd[ dd[,2], ]

        j <- psfs %in% dd[,1]
        psfs[ !j ] <- "NA"

        for( b in unique(psfs) ) {
            i <- psfs %in% b
            if( b == "NA" ) {
                bcf <- na.correction()
            } else {
                bcf <- batch.correction(b)
            }
            output[i,] <- correct( bcf, di.qcc29[i,] )
        }

        attr( output, "batches.used.for.correction" ) <- orig.batch

    }

    return( output )

}
