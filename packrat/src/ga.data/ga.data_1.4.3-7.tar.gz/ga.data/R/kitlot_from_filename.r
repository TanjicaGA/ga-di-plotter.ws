##' detects kitlots in filenames
##'
##' Searches filenames for kitlot string(s). See argument
##' how.to.handle.many.matches for what happens when there are many
##' possible matches. If set to 'first', the first mathc is silently
##' returned. The default is to throw an error (eg stop)
##' @title find and return a kitlot string in a filename
##' @param filename filename(s) to check for kitlot
##' @param how.to.handle.many.matches set to 'stop' (default), 'warn'
##'     or 'first' to determine how multiple matches are handled.
##' @return kitlot(s) found
##' @author Torbjorn Lindahl
##' @export
##' @importFrom stringr str_match_all
kitlot.from.filename <- function( filename, how.to.handle.many.matches=c("stop","warn","first") ) {

    s <- str_match_all( basename(filename), kitlot_re( anchored=FALSE ) )

    how.to.handle.many.matches <- match.arg(how.to.handle.many.matches)

    f <- stop
    if( how.to.handle.many.matches == "warn" )
        f <- warning

    kl <- sapply( seq_along(s), function(i) {

        m <- s[[i]]

        if( nrow(m) > 1 ) {
            m <- m[1,,drop=FALSE]
            if( how.to.handle.many.matches == "stop" )
                stop( sprintf( "Found too many kitlots in '%s'", basename(filename)[i] ) )
            else if( how.to.handle.many.matches == "warn" )
                warning( sprintf( "Found too many kitlots in '%s', using first match", basename(filename)[i] ) )
        }

        m[1,1]

    })

    return( kl )

}
