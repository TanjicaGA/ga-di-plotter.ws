##' create colors vectors useful for ggplots
##'
##' Creates n colors, or if specified, a number of colors representing
##' the number different values in 'values'
##'
##' If values is provided, it will return a vector of colors named by
##' the levels of values.
##' @title default ggplot colors
##' @return a vector of color names
##' @author Torbjorn Lindahl
##' @param n number of values to return
##' @param values values to fit colors to
##' @importFrom grDevices hcl
##' @export
default.ggplot.colors <- function( values, n ) {

    if( !missing(values) ) {
        uv <- unique(values)
        n <- length(uv)
    }

    hues = seq(15, 375, length = n + 1)
    colors <- hcl(h = hues, l = 65, c = 100)[1:n]

    if(!missing(values)) {
        names(colors) <- paste(uv)
    }

    return( colors )

}
