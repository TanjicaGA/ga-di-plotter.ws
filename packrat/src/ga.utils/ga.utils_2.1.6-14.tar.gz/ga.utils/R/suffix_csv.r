##' make sure filename string has an intended suffix
##'
##' Adds a suffix, default csv, if a file doesn't have it.
##' @title make sure filename has suffix
##' @param x string to have a .csv ending
##' @param suffix suffix to add, default "csv" (without the dot)
##' @return filename
##' @author Torbjørn Lindahl
##' @export
suffix.csv <- function(x, suffix="csv") {

    suffix <- sub( "^\\.", "", suffix )

    re <- paste0( "\\.", suffix, "$" )

    if(!grepl(re, x, ignore.case=TRUE))
        x <- paste0( x, ".", suffix )

    return(x)

}
