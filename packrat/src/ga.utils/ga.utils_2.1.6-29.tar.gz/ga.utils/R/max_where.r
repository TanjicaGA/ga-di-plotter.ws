##' Contidional which.max
##'
##' which.max with a subset.
##' @title which.max on a subset
##' @return max of x with subset
##' @author Torbjørn Lindahl
##' @param x vector to max
##' @param subset subset to test under, defaults to all
##' @param arr.ind return the answer as array indeces, like which(), not yet supported.
##' @param ... extra arguments to which.max
which.max.where <- function( x, subset=rep(TRUE,length(x)), arr.ind ) {

    if( !missing(arr.ind) && arr.ind %in% TRUE ) {
        stop( "which.max.where does not support arr.ind at the moment" )
    }

    i <- seq_along(x)[subset]

    v <- which.max( x[ subset ] )

    return( i[v] )

}
