##' normalize data to PS1801L
##'
##' Conventional batch correction takes profiles back to PS0000, which
##' is meaningful for DI calculation and bacteria table reports etc.
##' @title ps1801l normalization
##' @return matrix with profiles that correspond to PS1801L
##' @author Torbjorn Lindahl
##' @importFrom ga.batchcorrection inverse.correct
##' @importFrom ga.data batch.correction
##' @export
##' @param ... arguments to gamap()
ps1801l.normalize <- function( ... ) {

    di.batch <- gamap( ..., stop.at="batch" )

    di.ps1801l <- inverse.correct(
        batch.correction("PS1801L"),
        di.batch
    )

    return( di.ps1801l )

}
