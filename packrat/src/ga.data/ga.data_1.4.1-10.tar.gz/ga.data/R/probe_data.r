##' fetches probe columns from a data frame
##'
##' Looks for probe.re in columns and returns data for them
##' @title probe.data
##' @return matrix
##' @author Torbjørn Lindahl
##' @param x data to process
##' @param include.technical include technical probes such as
##'     BLANK[12], HYC01 and UNI05, see \code{probe.re}
##' @export
probe.data <- function(x, include.technical=TRUE) {
    return( as.matrix( x[ , grepl( probe.re(include.technical=include.technical), colnames(x)) ] ) )
}
