##' Plot T2/Qres
##'
##' Plots the supplied T2 and Qres plots. DI plot version meant for
##' shiny app.
##' @title T2/Qres plot
##' @param t2 T2
##' @param qres Q-residuals
##' @param unit.scale logical default TRUE, use unit scale for plots
##' @param log.scale logical default TRUE, use log scale
##' @param add.threshold logical default TRUE, add class threshold
##' @param add.di.scale logical default TRUE add DI Scale
##' @param add.normal.backdrop logical default TRUE add normal data in
##'     background
##' @param plot.names show sample names in plot
##' @param selected outline selected samples
##' @param main title of plot
##' @param col color of points in plot
##' @param pch pch of points
##' @param norm.col color of normal samples
##' @param norm.pch pch of normal samples
##' @param sample.prefix text label to prefix samples with
##' @param sample.postfix text label to postfix samples with
##' @param ... other arguments for plot()
##' @return no return
##' @author Torbjørn Lindahl
##' @importFrom ga.data t2.limit qres.limit model.qcc30.data
##' @importFrom graphics axis
##' @export
plot_di <- function( t2, qres,
                    unit.scale=TRUE,
                    log.scale=TRUE,
                    add.threshold=TRUE,
                    add.di.scale=TRUE,
                    add.normal.backdrop=TRUE,
                    plot.names=FALSE,
                    selected=list(),
                    main = "T2 / Q-residuals",
                    col="black",
                    pch=3,
                    norm.col="gray",
                    norm.pch=1,
                    sample.prefix,
                    sample.postfix,
                    ...
                    ) {

    if( unit.scale ) {
        t2 <- t2 / t2.limit()
        qres <- qres / qres.limit()
    }

    nn <- names(t2)
    if(is.null(nn))
      nn <- names(qres)
    if(is.null(nn)) {
        stop("Sample names are fetched from the names attribute of t2 or qres - none of them seemed to have one")
    }

    i.29 <- grepl( "QCC29", names(t2) )
    i.30 <- grepl( "QCC30", names(t2) )
    i.23 <- grepl( "QCC23", names(t2) )
    i.33 <- grepl( "QCC33", names(t2) )

    i.samples <- !i.29 & !i.30 & !i.23 & !i.33

    ## X- and Y-ranges
    xr <- range(t2[!i.30], na.rm=TRUE )
    yr <- range(qres[!i.30], na.rm=TRUE )
    xr[1] <- 0
    xr[2] <- 20
    yr[1] <- 0
    yr[2] <- 25

    ## Plot setup args
    args <- list(
      1,
      type = "n",
      main = main,
      xlab = "T2",
      ylab = "Q-residuals",
      yaxs = "i",
      xaxs = "i",
      axes = FALSE,
      ...
      )

    if( log.scale ) {
        args$log <- "xy"
        if( !xr[1] > 0 )
          xr[1] <- min( c(.05, t2), na.rm=TRUE )
        if( !yr[1] > 0 )
          yr[1] <- min( c(.05, qres), na.rm=TRUE )
    }

    if( !unit.scale ) {

        xr <- xr * t2.limit()
        yr <- yr * qres.limit()

    }

    args$xlim <- xr
    args$ylim <- yr

    ## Initate plot
    do.call( plot, args )

    ## Normal backdrop
    if( add.normal.backdrop ) {

        old <- model.qcc30.data()
        attr( old, "platform" ) <- rep("biocode",nrow(old))
        di.old <- gamap(
            old,
            start.from = "qcc",
            stop.at = "t2res",
            batch="PS0000"
        )
        t2.old <- di.old$T2
        qres.old <- di.old$Qres

        if( unit.scale ) {
            t2.old <- t2.old / t2.limit()
            qres.old <- qres.old / qres.limit()
        }

        args0 <- list(
          qres.old~t2.old,
          col=norm.col,
          pch=norm.pch,
          cex=.8
          )
        do.call( points, args0 )
    }

    ## DI scale
    if( add.di.scale ) {
        add.dysbiosis.scale(
          unit.scale = unit.scale,
          col="darkgray",
          add.class.threshold=FALSE
          )
    }

    ## Class threshold
    if( add.threshold ) {
        add.dysbiosis.thresholds(unit.scale=unit.scale)
    }

    ## Add data
    args2 <- list(
      x=t2[i.samples],
      y=qres[i.samples],
      col=col, pch=pch
      )
    f <- points

    ## sample prefix
    if( !missing(sample.prefix) ) {
        nn <- paste0( sample.prefix[1], nn )
    }
    if( !missing(sample.postfix) ) {
        nn <- paste0( sample.postfix[1], nn )
    }

    if( plot.names ) {
        args2$labels <- nn[i.samples]
        f <- text
    }
    do.call( f, args2 )

    ## Add QCC's
    args3 <- list( qres[i.23]~t2[i.23], col="red", pch=19 )
    do.call( points, args3 )
    args4 <- list( qres[i.33]~t2[i.33], col="green", pch=19 )
    do.call( points, args4 )

    ## selected

    ## Axis
    axis(1); axis(2);

}
