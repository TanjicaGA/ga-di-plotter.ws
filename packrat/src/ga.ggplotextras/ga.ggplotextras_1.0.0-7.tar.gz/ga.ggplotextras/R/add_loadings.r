##' add loadings to a scores plot
##'
##' Calculates loadings from a pca model and creates a geom layer
##' suitable to be abbed to a scores scatter plot
##' @title add loadings
##' @param pca pca object to work on
##' @param geom what geom to create, defaults to label
##' @param comps components
##' @param scale ratio to expand loadings with
##' @param how.many how many variabels to show, ranked from the
##'     highest squared sum
##' @param add.arrow add arrow
##' @param ... other arguments passed to geom function
##' @return a ggplot layer
##' @author Torbjorn Lindahl
##' @importFrom ggplot2 geom_label geom_segment aes_string
##' @importFrom ggrepel geom_label_repel
##' @importFrom plyr ddply
##' @importFrom pls loadings
##' @importFrom grid unit arrow
##' @export
gg_pca_loadings <- function(pca, geom=geom_label_repel, comps=c(1,2), scale=1, how.many, add.arrow=TRUE, ... )  {

    ll <- t( diag( (pca$sdev^2) ^ scale ) %*% t(loadings(pca)[] ))
    colnames(ll) <- colnames(loadings(pca))

    d <- cbind.data.frame(
        Variable=rownames(ll),
        as.data.frame(
            ll[,comps]
        )
    )
    d$Dist <- sqrt( rowSums( ll[,comps] **2 ) )

    d <- d[ order( -d$Dist ), ]

    if( missing( how.many ) )
        how.many <- nrow(ll)

    l <- list()

    d2 <- d[1:how.many,]

    x <- y <- xend <- yend <- NULL

    if( add.arrow ) {
        ld <- ddply( d2, 'Variable', function(dd) {
            with(
                dd,
                data.frame(
                    x = 0,
                    xend = dd[, paste0("PC",comps[1])],
                    y = 0,
                    yend = dd[, paste0("PC",comps[2])]
                )
            )
        })
        l <- append( l, geom_segment( data=ld, aes(x=x,y=y,xend=xend,yend=yend), arrow=arrow( length=unit(.07,"inches")) ) )
    }

    l <- append( l, list(
        geom(
            data=d2,
            aes_string(x=paste0("PC",comps[1]),y=paste0("PC",comps[2]),label="Variable"),
            ...
        )
    ))

}
