##' Sets i.qcc variables in parent frame
##'
##' Processes x and defined i.qcc logical variables in the parent
##' frame.
##' @title sets variables i.qccX from input data, eg i.qcc23, i.qcc33
##'     etc
##' @param x argument to set QCC indeces from
##' @param verbose mute information message
##' @param postfix postfix to add to the variable names, eg '.2' would result in i.qcc23.2
##' @return null
##' @author Torbjørn Lindahl
##' @export
set.qcc.indeces <- function(x,verbose=TRUE,postfix) {

    if( is.character(x) ) {
        n <- x
    } else if( is.null(dim(x)) ) {
        n <- names(x)
    } else if( "sample" %in% tolower(colnames(x)) ) {
        n <- x[, grep1("sample",tolower(colnames(x))) ]
    } else {
        n <- rownames(x)
    }

    e <- parent.frame()

    if(missing(postfix))
        f <- identity
    else
        f <- function(x)paste0(x,postfix)

    g <- function(...)get(f(...),e,inherits=FALSE)

    for( v in c(23,33,30,29)) {
        i <- grepl( paste0("QCC",v), n )
        assign( f(paste0("i.qcc",v)), i, e )
    }

    assign( f("i.qcc"), g("i.qcc23") | g("i.qcc33") | g("i.qcc30") | g("i.qcc29"), e )

    if( any(grepl("^BLANK",n)) ) {
        assign( f("i.blank"), grepl("^BLANK",n), e )
        assign( f("i.qcc"), g("i.qcc") | g("i.blank"), e )
    }

    if( verbose )
        say( paste0(
            "Defined indeces",
            f("i.blank"), ", ",
            f("i.qcc"), ", ",
            f("i.qcc23"), ", ",
            f("i.qcc33"), ", ",
            f("i.qcc30"), ", ", "and ",
            f("i.qcc29")
        ))

}
