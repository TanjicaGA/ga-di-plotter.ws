library(ga.gamapqc)
library(ga.gamap)
library(ga.data)
library(ga.utils)

## TEMPORARY:
qc.set="IBS02-1305-2"
skip.upper.hyc=TRUE
simplify=TRUE
bg.probes=c("BLANK1","BLANK2")
hyc.probe="HYC01"
uni.probe="UNI05"
##

## testfile.1 <- ga.path( "Projects", "Software", "Testing", "SystemTestFiles", "Files", "TestFile1.csv" )
## testfile.1 <- "data/TestFile1-four_low_count_hyc_qcc30-four_low_uni_qcc30.csv"
testfile.1 <- "data/TestFile1.csv"

pd0 <- plate.data <- gamap( testfile.1, stop.at = "file", batch="PS1408" )
cd0 <- count.data <- attr( plate.data, "count" )
di0 <- di.num <- ceiling( gamap( testfile.1, batch="PS1408" ) )

temp <- cd0
levels( temp$Plate ) <- paste0(1:3)
count.data.3 <- rbind( temp, temp, temp )
count.data.3$Plate <- as.factor( rep( 1:3, each = nrow(temp) ) )

temp <- pd0
levels( temp$Plate ) <- paste0(1:3)
plate.data.3 <- rbind( temp, temp, temp )
plate.data.3$Plate <- as.factor( rep( 1:3, each = nrow(temp) ) )

di.num.3 <- rep( di0, 3 )

qc.vector <-
  structure(c(2, 2, 4, 14694, 13850, 14352, 14489, 7655, 7538,
7466, 8004, 0, 10, 14134, 5939, 31, 5, 9, 15134, 9900, 156, 5,
10, 17159, 8545, 77, 2, 18, 16964, 8301, 78, 2, 1e6, 1e6, 1e6, 1e6), .Names = c("QCC23.count.on.plate",
"QCC33.count.on.plate", "QCC30.count.on.plate", "QCC30.HYC01.1",
"QCC30.HYC01.2", "QCC30.HYC01.3", "QCC30.HYC01.4", "QCC30.UNI05.1",
"QCC30.UNI05.2", "QCC30.UNI05.3", "QCC30.UNI05.4", "QCC30.missing.values",
"QCC23.1.LowCount", "QCC23.1.HYC01", "QCC23.1.UNI05", "QCC23.1.HighBG",
"QCC23.1.DI", "QCC23.2.LowCount", "QCC23.2.HYC01", "QCC23.2.UNI05",
"QCC23.2.HighBG", "QCC23.2.DI", "QCC33.1.LowCount", "QCC33.1.HYC01",
"QCC33.1.UNI05", "QCC33.1.HighBG", "QCC33.1.DI", "QCC33.2.LowCount",
"QCC33.2.HYC01", "QCC33.2.UNI05", "QCC33.2.HighBG", "QCC33.2.DI",
"QCC30.TS.1","QCC30.TS.2","QCC30.TS.3","QCC30.TS.4"
))

context("GAmap support functions")

## Expected error codes
qcc23.generic.error <- 22
qcc23.bg.error <- 16
qcc23.class.error <- 18
qcc23.hyc.error <- 5
qcc23.low.count <- 9
qcc23.uni.error <- 13
qcc30.count.error <- 11
qcc30.hyc.error <- 7
qcc30.uni.error <- 21
qcc33.bg.error <- 17
qcc33.class.error <- 19
qcc33.hyc.error <- 6
qcc33.low.count <- 10
qcc33.uni.error <- 14
qcc33.generic.error <- 23

## qcc23.bg.error <- 22
## qcc23.class.error <- 18
## qcc23.hyc.error <- 22
## qcc23.low.count <- 22
## qcc23.uni.error <- 22
## qcc30.count.error <- 11
## qcc30.hyc.error <- 7
## qcc30.uni.error <- 21
## qcc33.bg.error <- 23
## qcc33.class.error <- 19
## qcc33.hyc.error <- 23
## qcc33.low.count <- 23
## qcc33.uni.error <- 23

## test_that( "Pos/Neg names are correct" , {
## })

test_that( "QC vector parsing works", {

    f <- gamap.qc.parse.qc.vector

    r1 <- f( qc.vector, "count.on.plate" )

    expect_equal(
      dim(r1), c(3,2)
      )

    expect_equal(
      r1[,1], c(2,2,4)
      )

    expect_equal(
      r1[,2], c("QCC23","QCC33","QCC30")
      )

})

context("Check Integrity")

test_that( "Integrity works", {

    f <- gamap.qc.check.integrity

    ## at first all is ok
    f( plate.data, count.data, di.num )

    ## ## error 1: di.num2 contains floating points
    ## di.num2 <- di.num
    ## di.num2[1] <- di.num2[1]+.5

    ## expect_error( f( plate.data, count.data, di.num2 ),
    ##              "" )

    ## error 2: count.data has wrong names
    count.data2 <- count.data
    i <- grep( probe.re(), colnames( count.data2 ) )[1]
    names( count.data2 )[i] <- "foo"

    expect_error(
        f( plate.data, count.data2, di.num ),
        "names.*identical"
    )

    ## error 3: not matching dimensions
    count.data3 <- count.data[-1,]

    expect_error( f( plate.data, count.data3, di.num ),
                 "identical.*is not" )

})

context("Checkpoint 01")

test_that( "QCC counts works", {

    f <- gamap.qc.plate.cp.01.qcc.count
    r <- f( plate.data )

    expect_is( r, "list" )

    expect_equivalent(
      unlist(r),
      c(2,2,4)
      )

    expect_equal(
      names( r[[1]] ),
      c("QCC23.count.on.plate","QCC33.count.on.plate","QCC30.count.on.plate")
      )

})

context("Checkpoint 02")

test_that( "QCC30 QC works", {

    f <- gamap.qc.plate.cp.02.qcc30.checks
    r <- f( plate.data, count.data )

    expect_is( r, "list" )

    ru <- unlist(r)

    expect_true(
      all( ru[ grepl("UNI|HYC", names(ru)) ] > 0 )
      )

    expect_true(
      all( grepl( "^QCC30\\.((HYC01|UNI05|TS)\\.\\d+|missing\\.values)$|^QCC29\\.TS\\.\\d+$", names( r[[1]] ) ) )
      )

})

context("Checkpoint 03")

for( n in c("QCC23","QCC33") ) {

    ctrl.type <- gamap.qc.pos.neg.name(n)

    test_that( sprintf("checkpoints 03 - %s QC works",n), {

        f <- gamap.qc.plate.cp.03.pos.neg.qc
        r <- f( plate.data, count.data, di.num, n )

        expect_is( r, "list" )

        r1 <- r[[1]]
        rn <- names(r1)

        ## 5 things are being tested
        expect_equal(
          length(r1) %% 5, 0 )

        expect_true(
          all( grepl( paste0("^",n,"\\."), rn )))

        expect_true(
          all( r1[ grep("\\.LowCount$",rn) ] > 2 ))

        expect_true(
          all( r1[ grep("\\.HYC01$",rn) ] > 14000 ))

        expect_true(
          all( r1[ grep("\\.UNI05$",rn) ] > 5500 ))

        expect_true(
          all( r1[ grep("\\.HighBG$",rn) ] < 160 ))

        if( n == "QCC23" ) {
            expect_true(
              all( r1[ grep("\\.DI$",rn) ] == 5 ))
        } else if( n == "QCC33" ) {
            expect_true(
              all( r1[ grep("\\.DI$",rn) ] == 2 ))
        }

        expect_true(
          all( grepl( paste0("^",n,"\\."), rownames(r) ))
          )

    })

}

context( "Evaluate 01 - QCC Count" )

test_that( "qcc count eval works", {

    f <- function(...)gamap.qc.evaluation.01.qcc.count(..., platform="biocode")

    ## all passes in this data
    expect_true( f(qc.vector) )

    ## 0 is too low
    qc.vect2 <- qc.vector
    qc.vect2[1] <- 0
    expect_false( f(qc.vect2) )

    ## empty vector gives false
    qc.vect3 <- integer()
    expect_false( f(qc.vect3) )

    test.vect3 <- c( QCC23.count.on.plate=1, QCC33.count.on.plate=1, QCC30.count.on.plate=1 )

    ## one qcc missing, one at a time
    test.vect3[] <- 1:3
    expect_true( f( test.vect3 ) )
    test.vect3[] <- 1:3
    test.vect3[1] <- 0
    expect_false( f( test.vect3 ) )
    test.vect3[] <- 1:3
    test.vect3[2] <- 0
    expect_false( f( test.vect3 ) )
    test.vect3[] <- 1:3
    test.vect3[3] <- 0
    expect_false( f( test.vect3 ) )

})

context( "Evaluate 02 - QCC30 QC" )

test_that( "QCC30 HYC01 is correctly evaluated", {

    f <- function(...)gamap.qc.evaluation.02.qcc30.qc(..., platform="biocode")

    ## all passes in this data
    expect_true( f(qc.vector) )

    qc.vect <- qc.vector

    qc.vect["QCC30.HYC01.1"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.HYC01.2"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.HYC01.3"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.HYC01.4"] <- 0
    r <- f(qc.vect)
    expect_false( f(qc.vect) ) ## Now FALSE!

    expect_equal(
      attr(r,"ErrorNumbers"), qcc30.hyc.error )

    expect_true(
      grepl(
        "hybridization",
        attr(r,"ErrorMessages"),
        ignore.case = TRUE
        ) &&
      grepl(
        "End-labeling ctrl pos",
        attr(r,"ErrorMessages")
        )
      )

})

test_that( "QCC30 UNI05 is correctly evaluated", {

    f <- function(...)gamap.qc.evaluation.02.qcc30.qc(..., platform="biocode")

    ## all passes in this data
    expect_true( f(qc.vector) )

    qc.vect <- qc.vector

    qc.vect["QCC30.UNI05.1"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.UNI05.2"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.UNI05.3"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.UNI05.4"] <- 0
    r <- f(qc.vect)
    expect_false( f(qc.vect) ) ## Now FALSE!

    expect_equal(
      attr(r,"ErrorNumbers"), qcc30.uni.error )

    expect_true(
      grepl(
        "template.*not present",
        attr(r,"ErrorMessages"),
        ignore.case = TRUE
        )
      )

})

test_that( "QCC30 HYC01 UNI05 mixture is correctly evaluated", {

    f <- function(...)gamap.qc.evaluation.02.qcc30.qc(..., platform="biocode")

    ## all passes in this data
    expect_true( f(qc.vector) )

    qc.vect <- qc.vector

    qc.vect["QCC30.UNI05.1"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.UNI05.2"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.HYC01.3"] <- 0
    expect_true( f(qc.vect) )
    qc.vect["QCC30.HYC01.4"] <- 0
    r <- f(qc.vect)
    expect_false( f(qc.vect) ) ## Now FALSE!

    expect_equal(
      sort(attr(r,"ErrorNumbers")), c(qcc30.hyc.error, qcc30.uni.error) )

    expect_true(
      all(grepl(
        "End-labeling ctrl pos",
        attr(r,"ErrorMessages")
        )) &&
      any(grepl(
        "template.*not present",
        attr(r,"ErrorMessages"),
        ignore.case = TRUE
        )) &&
      any(grepl(
        "hybridization",
        attr(r,"ErrorMessages"),
        ignore.case = TRUE
        )
      ))

    ## Now all HYC fail - unchanged
    qc.vect["QCC30.HYC01.1"] <- 0
    qc.vect["QCC30.HYC01.2"] <- 0
    r2 <- f(qc.vect)

    expect_false( r2 ) ## Still FALSE!

    expect_equal(
      sort(attr(r2,"ErrorNumbers")), c(qcc30.hyc.error,qcc30.uni.error) )

    expect_true(
      all(grepl(
        "End-labeling ctrl pos",
        attr(r2,"ErrorMessages")
        )) &&
      any(grepl(
        "template.*not present",
        attr(r2,"ErrorMessages"),
        ignore.case = TRUE
        )) &&
      any(grepl(
        "hybridization",
        attr(r2,"ErrorMessages"),
        ignore.case = TRUE
        )
      ))

    ## Now all UNI fail
    qc.vect["QCC30.UNI05.3"] <- 0
    qc.vect["QCC30.UNI05.4"] <- 0
    r3 <- f(qc.vect)

    expect_false( r3 ) ## Still FALSE!

    expect_equal( ## Now only 11 - for UNI05
      sort(attr(r3,"ErrorNumbers")), qcc30.uni.error )

    expect_true(
      all(grepl(
        "End-labeling ctrl pos",
        attr(r3,"ErrorMessages")
        )) &&
      any(grepl(
        "template.*not present",
        attr(r3,"ErrorMessages"),
        ignore.case = TRUE
        ))
      )

    expect_false(
      any(grepl(
        "hybridization",
        attr(r3,"ErrorMessages"),
        ignore.case = TRUE
        ))
      )

})

context( "Evaluate 03 - QCC23/33 QC" )

test_that( "QCC23/33 is correctly evaluated", {

    f <- function(...)gamap.qc.evaluation.03.pos.neg.qc(..., platform="biocode")

    qcr <- gamap.qc.ranges()

    e <- function(r)attr(r,"ErrorNumbers")
    m <- function(r,reg,...)grepl(reg,attr(r,"ErrorMessages"),...)

    ## all passes in this data
    expect_true( f(qc.vector) )

    qc.vect2 <- qc.vector
    ## First QCC23.1
    qc.vect2["QCC23.1.LowCount"] <- 0
    expect_true( f(qc.vect2) )
    qc.vect2["QCC23.1.HYC01"] <- 0
    expect_true( f(qc.vect2) )
    qc.vect2["QCC23.1.UNI05"] <- 0
    expect_true( f(qc.vect2) )
    qc.vect2["QCC23.1.HighBG"] <- qcr$Background.upper + 50
    expect_true( f(qc.vect2) )
    qc.vect2["QCC23.1.DI"] <- 2
    expect_true( f(qc.vect2) )
    ### Then .2
    qc.vect2["QCC23.2.LowCount"] <- 0
    expect_false( r <- f(qc.vect2) )
    expect_equal( e(r), qcc23.generic.error )
    expect_true( m(r,"Kit ctrl pos",ignore.case=TRUE) && m(r,"Kit ctrl pos") )
    qc.vect2["QCC23.2.LowCount"] <- 20
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC23.2.HYC01"] <- 0
    expect_false( r <- f(qc.vect2) )

    expect_equal( sort(e(r)), unique(sort(c(qcc23.generic.error))) )
    expect_true( all(m(r,"Kit ctrl pos",ignore.case=TRUE)) && all(m(r,"Kit ctrl pos") ))
    qc.vect2["QCC23.2.HYC01"] <- qcr$HYC01.range[1] + 4000
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC23.2.UNI05"] <- 0
    expect_false( r <- f(qc.vect2) )
    expect_equal( sort(e(r)), unique(c(qcc23.generic.error)) )
    expect_true( all(m(r,"Kit ctrl pos",ignore.case=TRUE)) && all(m(r,"Kit ctrl pos") ))
    qc.vect2["QCC23.2.UNI05"] <- qcr$UNI05.lower + 500
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC23.2.HighBG"] <- qcr$Background.upper + 50
    expect_false( r <- f(qc.vect2) )
    expect_equal( sort(e(r)), sort(unique(c(qcc23.generic.error))) )
    expect_true( all(m(r,"Kit ctrl pos",ignore.case=TRUE)) && all(m(r,"Kit ctrl pos") ))
    qc.vect2["QCC23.2.HighBG"] <- 20
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC23.2.DI"] <- qcr$Pos.Ctrl.lower-0.001 ## just below
    expect_false( r <- f(qc.vect2) )
    expect_equal( sort(e(r)), c(qcc23.class.error) )
    expect_true( all(m(r,"classification",ignore.case=TRUE)) && all(m(r,"Kit ctrl pos") ))
    qc.vect2["QCC23.2.DI"] <- qcr$Pos.Ctrl.lower+0.001 ## just above
    expect_true( f(qc.vect2) )

    ## Same, only with QCC33
    ## First QCC33.1
    qc.vect2["QCC33.1.LowCount"] <- 0
    expect_true( f(qc.vect2) )
    qc.vect2["QCC33.1.HYC01"] <- 0
    expect_true( f(qc.vect2) )
    qc.vect2["QCC33.1.UNI05"] <- 0
    expect_true( f(qc.vect2) )
    qc.vect2["QCC33.1.HighBG"] <- qcr$Background.upper + 50
    expect_true( f(qc.vect2) )
    qc.vect2["QCC33.1.DI"] <- 2
    expect_true( f(qc.vect2) )
    ### Then .2
    qc.vect2["QCC33.2.LowCount"] <- 0
    expect_false( r <- f(qc.vect2) )

    qc.vect2["QCC33.2.LowCount"] <- 20
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC33.2.HYC01"] <- 0
    expect_false( f(qc.vect2) )
    qc.vect2["QCC33.2.HYC01"] <- qcr$HYC01.range[1] + 4000
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC33.2.UNI05"] <- 0
    expect_false( f(qc.vect2) )
    qc.vect2["QCC33.2.UNI05"] <- qcr$UNI05.lower + 500
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC33.2.HighBG"] <- qcr$Background.upper + 50
    expect_false( f(qc.vect2) )
    qc.vect2["QCC33.2.HighBG"] <- 20
    expect_true( f(qc.vect2) )
    ##
    qc.vect2["QCC33.2.DI"] <- 5
    expect_false( f(qc.vect2) )
    qc.vect2["QCC33.2.DI"] <- 2
    expect_true( f(qc.vect2) )

})

context( "Complete Plate QC")

test_that( "Plate QC works", {

    f <- gamap.qc.plate.qc
    r <- f( plate.data, count.data, di.num )
    expect_equal( r, list(TRUE) )

})
