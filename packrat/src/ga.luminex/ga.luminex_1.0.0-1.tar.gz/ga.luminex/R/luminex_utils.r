##' Parse luminex location strings
##'
##' Parses the well coordinate from the locaiton, ie 1(1,A1) becomes
##' "A1"
##' @title parse well coordinate from location strings
##' @param location input location strings
##' @return well coordinates as character strings
##' @author Torbjørn Lindahl
##' @export
luminex.plate.coord <- function( location ) {
    return(
        sub( "\\d+\\(\\d+,([A-H]\\d+)\\).*", "\\1", location  )
    )
}
