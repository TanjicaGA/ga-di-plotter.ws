##' A suitable filename for a variable name
##'
##' Creates a character from the variable name that is meaningful as a
##' filename. It takes care that there is a single '.' before the
##' suffix. Also handles special characters:
##'
##' '.' is translated to _ in rest of the filename
##'
##' @title Create filename from variable name
##' @param var.name The variable name to create a file name from
##' @param suffix suffix to use
##' @return A character suitable for filename
##' @author Torbjørn Lindahl
filename.from.varname <- function( var.name, suffix ) {

    var.name <- sub( "\\.+$", "", var.name )
    var.name <- gsub("\\.", "_", var.name)

    suffix <- sub( "^\\.+", "", suffix )

    var.name <- paste0( var.name, ".", suffix )

    return( var.name )

}
