##' tidy ffmanova
##'
##' Tidys up ffmanova models. Largely fetched from print.ffmanova
##' @title broom's tidy for ffmanova models
##' @param x ffmanova model
##' @param ... other arguments to brooms tidy
##' @return tidy'd data frame
##' @author Torbjørn Lindahl
tidy.ffmanova <- function( x, ... ) {

    tab <- with(
        x,
        data.frame(
            df, exVarSS,
            c(nPC, NA),
            c(nBU, NA),
            c(exVarPC, NA),
            c(exVarBU, NA),
            c(pValues, NA)
        )
    )

    dimnames(tab) <- list(
        c(x$termNames, "Residuals"),
        c("Df", "exVarSS", "nPC", "nBU", "exVarPC", "exVarBU", "p.value")
    )

    tab <- tab[-1, ]

    tab

}
