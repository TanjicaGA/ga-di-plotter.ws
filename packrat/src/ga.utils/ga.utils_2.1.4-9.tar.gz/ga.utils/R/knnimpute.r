##' pamr's knn imputation function
##'
##' Imputes missing values using knnimpute in pamr. Expects samples in rows and variables in columns.
##' @title knnimpute data
##' @param data data to inn impute
##' @param standardize wether or not to standardize data first
##' @param reference.data reference data to use for imputation
##' @param use.wrong.scale included for historical reasons, standardizez with a slightly different scale
##' @param ... extra arguments to pamr.knnimpute
##' @return data with misisng values imputed
##' @author Torbjørn Lindahl
##' @importFrom pamr pamr.knnimpute
##' @export
knn.impute <- function(data, standardize=TRUE, reference.data=NULL, use.wrong.scale=FALSE, ...){

  if(!is.null(reference.data))
    data <- rbind( reference.data, data )

  if( standardize )
    data <- .my.stdize( data, use.wrong.scale=use.wrong.scale )

  temp <- list()
  temp$x <- t( data )

  temp2 <- pamr.knnimpute(temp, ...)

  if( standardize ){
    if(!"stdized:scale" %in% names(attributes(temp2$x)))
      attr(temp2$x,"stdized:scale") <- attr( data, "stdized:scale" )
    if(!"stdized:center" %in% names(attributes(temp2$x)))
      attr(temp2$x,"stdized:center") <- attr( data, "stdized:center" )
  }

  if( standardize )
    data <- .my.unstdize( t(temp2$x) )
  else
    data <- t(temp2$x)

  if(!is.null(reference.data))
    data <- data[ -(1:nrow(reference.data)),,drop=F ]

  return( data )

}

##' @importFrom stats sd
.my.stdize <- function (x, center = TRUE, scale = TRUE, use.wrong.scale )
  {
    nc <- ncol(x)
    if (is.logical(center)) {
      if (center) {
        center <- colMeans(x, na.rm = TRUE)
        x <- sweep(x, 2, center)
      }
    }
    else if (is.numeric(center) && length(center) == nc)
      x <- sweep(x, 2, center)
    else stop("invalid 'center'")
    if (is.logical(scale)) {
      if (scale) {
        if( use.wrong.scale ){
          scale <- sqrt(
                        colSums(
                                sweep(x, 2, colMeans(x, na.rm=TRUE))^2,
                                na.rm=TRUE
                                )
                        / (nrow(x) - 1)
                        )
        }
        else {
          scale <- apply( x, 2, sd, na.rm=TRUE )
        }
        x <- sweep(x, 2, scale, "/")
      }
    }
    else if (is.numeric(scale) && length(scale) == nc)
      x <- sweep(x, 2, scale, "/")
    else stop("invalid 'scale'")
    if (is.numeric(center))
      attr(x, "stdized:center") <- center
    if (is.numeric(scale))
      attr(x, "stdized:scale") <- scale
    class(x) <- c("stdized", "matrix")
    return(x)
  }

.my.unstdize <- function(xs) {

  ## multiplies with scale and adds center
  x <- xs * rep(attr(xs,"stdized:scale"),each=nrow(xs)) +
    rep(attr(xs,"stdized:center"),each=nrow(xs))

  attr( x, "stdized:center" ) <- NULL
  attr( x, "stdized:scale" ) <- NULL
  class(x) <- setdiff( class(x), "stdized" )

  x

}
