library(ga.data)

context( "customer.bacteria.names" )

test_that( "they are correct", {

    a1 <- customer.bacteria.names()

    target.names <- c("Anaerotruncus colihominis",
                      "Bacteroides fragilis",
                      "Bacteroides pectinophilus", "Bacteroides spp.",
                      "Bacteroides stercoris", "Clostridium sp.",
                      "Dorea spp.", "Eubacterium hallii",
                      "Eubacterium rectale", "Eubacterium siraeum",
                      "Faecalibacterium prausnitzii",
                      "Parabacteroides johnsonii",
                      "Ruminococcus gnavus",
                      "Streptococcus salivarius ssp.thermophilus",
                      "Acinetobacter junii",
                      "Akkermansia muciniphila",
                      "Bacillus megaterium",
                      "Bacteroides zoogleoformans",
                      "Bifidobacterium spp.",
                      "Catenibacterium mitsuokai",
                      "Clostridium methylpentosum",
                      "Dialister invisus",
                      "Dialister invisus & Megasphaera micronuciformis",
                      "Eubacterium biforme", "Lachnospiraceae",
                      "Lactobacillus spp. 2",
                      "Lactobacillus ruminis & Pediococcus  acidilactici",
                      "Parabacteroides spp.", "Prevotella nigrescens",
                      "Ruminococcus albus & R. bromii",
                      "Alistipes onderdonkii", "Alistipes",
                      "Pseudomonas spp.", "Atopobium rimae",
                      "Desulfitispora alkaliphila",
                      "Coprobacillus cateniformis",
                      "Phascolarctobacterium  sp.",
                      "Mycoplasma hominis", "Proteobacteria",
                      "Enterobacteriaceae", "Bacilli",
                      "Streptococcus salivarius ssp. thermophilus and S. sanguinis",
                      "Firmicutes", "Actinobacteria",
                      "Veillonella spp.", "Lactobacillus spp.",
                      "Clostridia",
                      "Bacteroides spp. & Prevotella spp.",
                      "Firmicutes (various)", "Streptococcus spp.",
                      "Streptococcus agalactiae and Eubacterium rectale",
                      "Shigella spp. & Echerichia spp.",
                      "Streptococcus spp. 2", "Actinomycetales")

    ## plain lookup
    expect_equal(
        a1,
        target.names
    )

    ## from other source of probe numbers
    expect_equal(
        customer.bacteria.names( probe.numbers( probe.set("ibs3")[1:54] ) ),
        target.names
    )
    expect_equal(
        customer.bacteria.names("AG0342"),
        "Anaerotruncus colihominis"
    )
    expect_equal(
        customer.bacteria.names(c("AG0377", "AG0393")),
        c("Bacteroides fragilis","Bacteroides pectinophilus")
    )

})
