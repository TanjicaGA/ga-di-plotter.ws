##' abundancy table qc
##'
##' Performs abundancy table qc
##' @title perform abundancy table qc
##' @return TRUE or FALSE per plate analyzed
##' @author Torbjørn Lindahl
##' @param ... arguments as passed to gamap()
##' @param report.per.sample default TRUE. Create one TRUE/FALSE value
##'     per sample instead of one per plate.
##' @importFrom ga.gamap gamap.probe.levels
##' @importFrom ga.data bacteria.table.qc.parameters
##' @importFrom foreach foreach %do%
##' @importFrom utils capture.output
##' @export
abundancy.table.qc <- function( ..., report.per.sample=TRUE ) {

    args2 <- args <- list(...)
    args2$start.from <- NULL

    di.plate <- gamap( ..., stop.at="file" )
    bt <- do.call(
        gamap.probe.levels,
        append( list(di.plate, start.from="file", use.bacteria.names=FALSE), args2 )
    )

    up <- unique( di.plate$Plate )
    qc.ranges <- bacteria.table.qc.parameters()

    i.qcc23 <- grepl("^QCC23_", di.plate$Sample)
    i.qcc33 <- grepl("^QCC33_", di.plate$Sample)

    p <- NULL
    qc.output <- foreach( p=up, .final=function(x){names(x) <- up; x} ) %do% {

        i <- di.plate$Plate == p

        if(!any(i & i.qcc23)) {
            stop(sprintf( "There are NO QCC23 samples on plate %s",p ))
        }

        if(!any(i & i.qcc33)) {
            stop(sprintf("There are NO QCC33 samples on plate %s",p ))
        }

        qcs.23 <- lapply( which(i & i.qcc23), function(j) {
            qc.i <- bacteria.table.vector.qc( bt[j,], "QCC23" )
            list( qc=qc.i, sample=di.plate$Sample[j], probes=attr(qc.i,"events-per-probe"), reason=attr( qc.i, "reason" ) )
        })

        qcs.33 <- lapply( which(i & i.qcc33), function(j) {
            qc.i <- bacteria.table.vector.qc( bt[j,], "QCC33" )
            list( qc=qc.i, sample=di.plate$Sample[j], probes=attr(qc.i,"events-per-probe"), reason=attr( qc.i, "reason" ) )
        })

        qc.evaluations <- append( qcs.23, qcs.33 )

        qc.result <- Reduce( function(a,b){ a & b$qc }, qc.evaluations, init=TRUE )
        qc.message <- ""

        if(!qc.result) {
            qc.messages <- sapply( qc.evaluations, function(q) {
                sprintf( "%s / %s: %s", di.plate$File[i][1], q$sample, q$reason )
            })
            qc.message <- capture.output( writeLines( unlist(qc.messages) ) )
        }

        ## fetch any failures, report eg "QCC23_A: x probes ±1", etc.
        list( qc=qc.result, message=qc.message, plate=p, qc.data=list( QCC23=qcs.23, QCC33=qcs.33 ) )

    }

    ret <- NULL

    if( report.per.sample ) {

        ret <- unlist(sapply( 1:length(qc.output), function(i) {
            rep( qc.output[[i]]$qc, sum( di.plate$Plate == up[i] ) )
        }))

        ret.messages <- unlist(sapply( 1:length(qc.output), function(i) {
            rep( qc.output[[i]]$message, sum( di.plate$Plate == up[i] ) )
        }))

        attr( ret, "reason" ) <- ret.messages
        names(ret) <- di.plate$Sample

    } else {

        init <- TRUE
        attr( init, "reason" ) <- character()

        ret <- sapply( qc.output, function(e)e$qc )
        attr( ret, "reason" ) <- capture.output(writeLines(unlist(sapply( 1:length(qc.output), function(i) {
            qc.output[[i]]$message
        }))))

        l <- lapply( qc.output, function(e)e$qc.data )
        names(l) <- paste(lapply( qc.output, function(e)e$plate ))
        attr( ret, "qc.data" ) <- l

        names(ret) <- up
    }

    return( ret )

}

##' bacteria table vector qc
##'
##' Calculates a single vector's QC
##' @title bacteria table qc of a single vector
##' @param vector bacteria table vector
##' @param qcc.name qcc.name of said vector
##' @return TRUE/FALSE for QC for a single vector
##' @author Torbjorn Lindahl
bacteria.table.vector.qc <- function( vector, qcc.name ) {

    l <- bacteria.table.qc.parameters()
    if( !qcc.name %in% names(l) ) {
        stop(sprintf("QC parameters for %s does not exist", qcc.name ))
    }

    bt.ranges <- l[[qcc.name]]$ranges
    bt.limits <- l[[qcc.name]]$limits

    ev <- events.from.vector( vector, bt.ranges )
    s <- summarize.events( ev )

    qc <- evaluate.qc( s, bt.limits )

    attr( qc, "events-per-probe" ) <-
        attr( s, "events-per-probe" )

    return( qc )

}

##' check a single probe
##'
##' Checks QC for a measurement. Reference values with accepted values
##' must be provided. Returns a number of 0, 1, 2 or 3 depending on
##' the severity of the deviation of the measurement. 0 being the
##' lowest.
##' @title check qc of a single probe
##' @param value bacteria table value for a given probe
##' @param ref reference values for this probe, ie accepted bacteria
##'     table values
##' @return a number of integers ranging from 0 to 3
##' @author Torbjørn Lindahl
##' @importFrom ga.utils clamp
evaluate.probe <- function( value, ref ) {

    diff <- clamp(
        min( abs( value - ref ) ),
        c(0,3)
    )

    if( length(ref) == 1 ) {
        ## just keep the diff as it is
    } else if( length(ref) == 2 ) {
        ## ±2 (and ±3) counts double
        if( diff > 1 )
            diff <- rep( diff, 2 )
    } else if( length(ref) == 3 ) {
        ## all deviations are escalated one step
        if( diff != 0 )
            diff <- clamp( diff+1, c(0,3) )
    }

    return( diff )

}

##' check bacteria table vector
##'
##' QC check a vector of bacteria table values. Evaluate every single
##' measurement against the provided list of reference values per
##' probe.
##' @title check bacteria table vector
##' @param v vector with bacteria table measurements
##' @param refs list of accepted values per probe
##' @return The number and types of events for each probe of occurences of different events.
##' @author Torbjørn Lindahl
events.from.vector <- function( v, refs ) {

    if( is.null(names(v)) ) {
        stop( "the vector must have names" )
    }

    qc.events <- lapply( names(v), function(n) {
        evaluate.probe( v[n], refs[[n]] )
    })

    names( qc.events ) <- names(v)

    return( qc.events )

}

##' evaluate events
##'
##' Check the frequeny of events
##' @title evaluate bacteria table events to true or false
##' @return checks the cumulative sums of events towards the qc spec
##' @author Torbjørn Lindahl
##' @param qc.events qc events as calculated per spec
summarize.events <- function( qc.events ) {

    qc.events <- as.list(qc.events)

    v <- structure( rep( 0, 4 ), .Names=paste(0:3) )
    t <- table( unlist( qc.events ) )
    v[ names(t) ] <- t

    v[-1] <- rev( cumsum( rev( v[-1] ) ) )

    l <- list(
        "\u00b11" = names(qc.events[sapply(qc.events, function(e)1 %in% e )]),
        "\u00b12" = names(qc.events[sapply(qc.events, function(e)2 %in% e )]),
        "\u00b13" = names(qc.events[sapply(qc.events, function(e)3 %in% e )])
    )

    attr( v, "events-per-probe" ) <- l

    return( v )

}

##' evaluate.qc
##'
##' Check the summarized events for qc failure
##' @title evaluate.qc
##' @param summarized.events output from summarize.events
##' @param refs list of acceptable limits
##' @return TRUE or FALSE
##' @author Torbjørn Lindahl
evaluate.qc <- function( summarized.events, refs ) {

    messages <- c()
    qc.result <- TRUE

    for( i in 1:3 ) {
        if( summarized.events[paste(i)] > refs[[paste(i)]] ) {
            messages <- append( messages, sprintf( "%d \u00b1%d-events [limit is %d]", summarized.events[paste(i)], i, refs[[paste(i)]] ) )
            qc.result <- FALSE
        }
    }

    attr( qc.result, "reasons" ) <- messages

    return( qc.result )

}
