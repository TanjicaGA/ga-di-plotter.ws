library(ga.software.dd)
library(ga.utils)

context( "aa.bacteria.table" )

test_that( "bacteria table is calculated correctly", {

    tf1 <- normalizePath( "data/lx200-files/TestFile-01-ONE-QCC29-IN-MIDDLE.csv" )
    di.plate <- gamap( tf1, stop.at="file" )

    new.bact.table <- load.get( "data/bact-table/nyBaktTab.Rdata", verbose=FALSE )

    ow <- options(GamapQcOverride = list(QCC30.total.signal = c(550000, 1100000)))
    on.exit(options(ow), add = TRUE)

    suppressWarnings(bt <- aa.bacteria.table(
        tf1, kitlot="L1902",
        bacteria.table.revision=new.bact.table
    ))

    suppressWarnings(bt.mean <- gamap.probe.levels(
        tf1, batch="L1902",
        bacteria.table.revision=new.bact.table,
        qcc29.correction.variant="mean",
        check.at.qcc29.corrected.before.batch=TRUE
    ))

    suppressWarnings(bt.reg <- gamap.probe.levels(
        tf1, batch="L1902",
        bacteria.table.revision=new.bact.table,
        qcc29.correction.variant="reg",
        check.at.qcc29.corrected.before.batch=TRUE,
        meta.data=di.plate
    ))

    suppressWarnings(bt.aa <- gamap.probe.levels(
        tf1, batch="L1902",
        bacteria.table.revision=new.bact.table,
        qcc29.correction.variant="aa",
        check.at.qcc29.corrected.before.batch=TRUE
    ))

    expect_equal( bt, bt.aa )
    expect_false( isTRUE( all.equal( bt, bt.mean ) ) )
    expect_false( isTRUE( all.equal( bt, bt.reg ) ) )

})
