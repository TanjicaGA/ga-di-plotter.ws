##' plot abundancy table qc
##'
##' Plots the QC evlauteion absed on abundancy table for a single
##' specified QCC sample
##' @title plot dd abundancy table qc
##' @return ggplot object
##' @author Torbjorn Lindahl
##' @param ... arguments to gamap()
##' @param sample_rx regular expression for sample to plot
##' @importFrom ga.gamap gamap.probe.levels
##' @importFrom ga.data bacteria.table.qc.parameters bacteria.limits probe.codes
##' @importFrom ga.utils tint.color %between%
##' @importFrom ga.ggplotextras gg_rotate_x_axis
##' @importFrom tibble rownames_to_column
##' @importFrom stringr str_match
##' @importFrom dplyr %>% arrange
##' @importFrom reshape2 melt
##' @importFrom ggplot2 ggplot aes geom_tile geom_line geom_point scale_fill_manual scale_y_continuous scale_color_manual theme element_blank
##' @export
plot_abundancy_qc <- function( ..., sample_rx ) {

    bt <- gamap.probe.levels( ..., use.bacteria.names=FALSE )
    rn <- rownames(bt)

    if( sum( grepl( sample_rx, rn )) != 1 ) {
        stop("Can't plot abundanty table qc: qcc sample specifier matches too many samples")
    }

    colnames(bt) <- probe.numbers( colnames(bt) )

    qc.ranges <- bacteria.table.qc.parameters()

    i <- grepl( sample_rx, rn )
    set <- str_match( rn[i], "^QCC[23]3" )[,1]

    xm <- within(
        rownames_to_column( melt( bt[i,], value.name="Value" ), var="Probe" ),
        Probe <- factor( Probe, levels=(colnames(bt)) )
    ) %>% arrange(Probe)

    pr <- bacteria.limits()$Probe

    ok.ranges <- t(sapply( qc.ranges[[set]]$ranges[pr], function(v)range(unlist(rep(v,2))) ))
    probe.ok <- xm$Value >= ok.ranges[,1] & xm$Value <= ok.ranges[,2]
    xm$ProbeOk <- c( "FALSE"="Fail", "TRUE"="Pass" )[ paste(probe.ok) ]

    pd <- t( sapply( colnames(bt), probe.value.status, set=set ) )
    colnames( pd ) <- paste( -3:3 )
    pd2 <- melt(pd, value.name="Event" )
    colnames(pd2)[1:2] <- c("Probe","Value")
    pd2$Probe <- factor( pd2$Probe, levels=(colnames(bt)) )

    Value <- Event <- ProbeOk <- NULL
    ggplot( pd2, aes(x=Probe,y=Value) ) +
        geom_tile( aes(fill=Event), alpha=.5 ) +
        geom_line( data=xm, aes(group=1) ) +
        geom_point( data=xm, aes(col=ProbeOk), pch=15, size=5 ) +
        scale_fill_manual(
            values=list(
                "\u00b10"  = tint.color("green", -.2 ),
                "\u00b11"  = tint.color("yellow", -.2 ),
                "\u00b12"  = tint.color("orange", -.2 ),
                "\u00b12*" = tint.color("darkorange", -.4 ),
                "\u00b13"  = tint.color("red", -.2 )
            )
        ) + theme(
                panel.grid.major = element_blank(),
                panel.grid.minor = element_blank(),
                panel.background = element_blank()
            ) +
        scale_y_continuous( breaks=-3:3, trans="reverse" ) +
        scale_color_manual( values=list("Fail" = "red", "Pass" = "black" ) ) +
        gg_rotate_x_axis()

}

## gives status for all values of said probe for said qcc sample
probe.value.status <- function( set, probe ) {

    obj <- bacteria.table.qc.parameters()[[set]]
    probe.code <- probe.codes( probe )

    ok.values <- obj$ranges[[probe.code]]
    mn <- min( ok.values )
    mx <- max( ok.values )

    vv <- NULL

    if( length( ok.values ) == 1 ) {

        v <- seq( ok.values-6, ok.values+6 )
        vv <- paste( clamp( v - ok.values, c(-3,3) ) )
        vv <- paste0( "\u00b1", sub( "-", "", vv ) )
        vv <- vv[ v %between% c(-3,3) ] # get changes in relevant range

    } else if( length( ok.values ) == 2 ) {

        v <- c( seq( mn-5, mn ), seq( mx, mx+5 ) )
        vv0 <- vv <- c( seq( mn-5, mn )-mn, seq( mx, mx+5 )-mx )
        vv <- clamp( vv, c(-3,3) )
        vv <- paste0( "\u00b1", sub( "-", "", vv ) )
        vv[ abs(vv0) == 2 ] <- paste0( vv[ abs(vv0) == 2 ], "*" ) # counts double
        vv <- vv[ v %between% c(-3,3) ] # get changes in relevant range

    } else if( length( ok.values ) == 3 ) {

        v <- c( seq( mn-4, mn ), ok.values[2], seq( mx, mx+4 ) )
        vv <- c( seq( mn-4, mn )-mn, 0, seq( mx, mx+4 )-mx )
        vv[ vv < 0 ] <- vv[ vv < 0 ]-1
        vv[ vv > 0 ] <- vv[ vv > 0 ]+1
        vv <- clamp( vv, c(-3,3) )
        vv <- paste0( "\u00b1", sub( "-", "", vv ) )
        vv <- vv[ v %between% c(-3,3) ] # get changes in relevant range

    } else {
        stop( sprintf("qc values of probe %s of sample %s doesnt have 1, 2 or 3 values", probe, set ) )
    }

    return( vv )

}
