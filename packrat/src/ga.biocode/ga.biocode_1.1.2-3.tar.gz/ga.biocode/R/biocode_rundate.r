##' Parse rundate for bicoode files
##'
##' Reads the date string from the file
##' @title biocode rundate
##' @param x files to read
##' @return dates
##' @author Torbjørn Lindahl
##' @export
biocode.rundate <- function( x ) {
    dates <- sapply( x, function(f) {
        as.numeric( read.biocode(f)$header$Date )
    }, USE.NAMES = FALSE)
    class( dates ) <- c("POSIXct", "POSIXt" )
    return( dates )
}
