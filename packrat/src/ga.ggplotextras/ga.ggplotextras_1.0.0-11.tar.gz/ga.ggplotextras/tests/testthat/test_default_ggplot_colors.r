library(testthat)
library(ga.ggplotextras)

context( "default ggplot colors" )

test_that( "the default colors are right", {

    l <- default.ggplot.colors( n=4 )

    expect_length( l, 4 )
    expect_equal( length(unique(l)), 4 )

    x <- col2rgb(l)
    expect_equal( dim(x), c(3,4) )

    ## None of them are black esentially
    expect_true( all(apply( x, 2, function(v){ length(unique(v)) > 1 } )) )

})

test_that( "it works with values", {

    values <- c("foo","bar","baz")
    l <- default.ggplot.colors( values )
    l2 <- default.ggplot.colors( n=3 )

    ## the colors should be the same as with any 3 colors
    expect_equivalent( l, l2 )
    ## but they should now have names
    expect_named( l, values )

})
