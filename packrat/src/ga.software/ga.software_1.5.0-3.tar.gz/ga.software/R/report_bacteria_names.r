##' report form bacterianames
##'
##' Returns a list mapping probe numbers (eg 203) to bacteria name, as
##' shown on the report form for the english standard report.
##' @title bacteria names as shown on report.
##' @return list where names are probe numbers and values are bacteria
##'     names as shown on the report form.
##' @author Torbjørn Lindahl
##' @export
report.bacteria.names <- function() {

    f <- system.file(
      "report_bacteria_names.json",
      package="ga.software",
      mustWork=TRUE
      )

    as.list( jsonlite::fromJSON(f) )

}
