##' gamap simple report
##'
##' Generates a simmple report for one or more csv files
##' @title gamap simple report
##' @return TRUE upon success
##' @author Torbjorn Lindahl
##' @export
##' @param ... arguments to gamap()
##' @param kitlot.info named lookup to map files basenames to kiltots
##' @param save.where directory to save xml files generated
##' @param appVersion appVersion to put in xml
##' @param bacteria.table.revision argument to gamap.probe.levels
##' @param sample.register sample info data.frame
##' @importFrom XML saveXML
gamap.simple.report <- function( ..., kitlot.info=character(), save.where=".", appVersion, bacteria.table.revision, sample.register ) {

    args0 <- list(...)
    arg.files <- unlist( args0[ sapply( args0, is.character ) ] )
    ## arg.files <- arg.files[ file.exists( arg.files ) ]
    arg.gamap.file <- args0[ sapply( args0, function(a)inherits(a,"gamap.file") ) ]

    if( length(arg.files) ) {
        uf <- arg.files
    } else if(length(arg.gamap.file)) {
        di.plate <- arg.gamap.file[[1]]
        uf <- unique( di.plate$File )
    } else {
        stop("Failed processing input arguments")
    }

    ## process each file
    for( datafile in uf ) {

        bf <- basename(datafile)
        xml.file <- sub( "\\.csv$", ".xml", bf )
        kitlot <- kitlot.info[ bf ]

        if(is.na(kitlot) ) {
            kitlot <- kitlot.from.filename( bf )
        }

        if(is.na(kitlot)) {
            stop( "Could not determine kitlot for ", bf )
        }

        args <- list(
            datafile, batch=kitlot,
            appVersion=appVersion
        )

        if(!missing(bacteria.table.revision))
            args$bacteria.table.revision <- bacteria.table.revision
        if(!missing(sample.register))
            args$sample.register <- sample.register

        doc <- do.call( create.simple.report, args )

        saveXML( doc, file=file.path( save.where, xml.file ), prefix="" )

    }

    return( TRUE )

}

##' generate simple report
##'
##' Produces a simple report per spec
##' @title produce a simple report
##' @param ... arguments to gamap()
##' @param rundate rundate of csv file, to be used in <analysisdate>
##' @param appVersion gamap dysbiosis analyzer version to put in the xml
##' @param bacteria.table.revision revision to use with the bacteria table
##' @param sample.register sample register data
##' @return xml document
##' @author Torbjorn Lindahl
##' @importFrom ga.data kitlot.from.filename
##' @importFrom dplyr coalesce
##' @importFrom ga.gamap gamap
create.simple.report <- function( ..., rundate, appVersion, bacteria.table.revision, sample.register ) {

    args <- list( ... )
    args$stop.at <- "file"
    di.plate <- do.call( gamap, args )

    if(length(unique(di.plate$File)) > 1 ) {
        stop("Can only create simple report for one file at a time")
    }


    filename <- as.character( di.plate$File[1] )
    kitlot <- args$batch
    if(is.null(kitlot)) {
        kitlot <- kitlot.from.filename( filename )
    }

    if( missing(rundate) ) {
        ## try to find it from the csv file
        args.without.named <- args[ names(args) == "" & sapply( args, is.vector ) ]
        possible.file <- coalesce( c( args$x, args[[1]] ) )
        if( file.exists( possible.file ) ) {
            rundate <- ga.gamap::rundate( possible.file )
        } else {
            rundate <- NA
            warning("Unable to find rundate (which goes into <analysisdate>, using NA")
        }
    }

    args2 <- list( di.plate, start.from="file", batch=kitlot )
    if(!missing(bacteria.table.revision))
        args2$bacteria.table.revision <- bacteria.table.revision

    bt <- do.call( gamap.probe.levels, args2 )
    di <- gamap( di.plate, start.from="file", batch=kitlot )

    doc <- initiate.report.xml(
        filename = filename,
        kitlot = kitlot,
        analysisdate=rundate,
        appVersion=appVersion
    )

    i.qcc <- grepl("^QCC", di.plate$Sample )

    if(any(!i.qcc)) {

        s.tag <- doc$children[[ length(doc$children) ]]

        for( i in which(!i.qcc) ) {
            ## append to the samples tag
            s.tag$children[[ length(s.tag$children) + 1 ]] <-
                generate.sample.xml(
                    plate.data.row=di.plate[i,],
                    bacteria.table.row=bt[i,],
                    di=di[i]
                )
        }

        doc$children[[ length(doc$children) ]] <- s.tag

    }

    return( doc )

}

##' initialize simple report xml
##'
##' Initialized an XML document for a simple report. It contains a
##' complete simple report without <sample> tags.
##' @title Generate XML for a simple report.
##' @param filename biocode file to process
##' @param reportdate date to use as report date, defaults to
##'     Sys.time()
##' @param date.format format for report date, defaults to \%d.\%m.\%Y
##' @param kitlot kitlot to put in xml
##' @param analysisdate date to use as date of analysis
##' @param appVersion softwarea version to put in
##' @return xml node representing the report
##' @author Torbjørn Lindahl
##' @importFrom XML xmlNode
##' @importFrom ga.utils grep1
##' @importFrom ga.data kitlot_re
initiate.report.xml <- function( filename,
                                reportdate = Sys.time(),
                                date.format="%d.%m.%Y",
                                kitlot, analysisdate, appVersion ) {

    if( missing( reportdate ) )
        reportdate <- format( Sys.Date(), format=date.format )

    if( missing(kitlot) )
        kitlot <- grep1( kitlot_re( anchored=FALSE ), filename, value=TRUE )

    filename <- basename( filename )
    filename <- sub( "\\..*", "", filename )

    # create /report
    l <- xmlNode("report")
    # create /report/version
    l$children[[1]] <- xmlNode( "version", 2 )

    # create /report/reportinfo
    l2 <- xmlNode( "reportinfo" )
    l2$children[[1]] <- xmlNode("samplefile", filename)
    l2$children[[2]] <- xmlNode("reportdate", reportdate)
    l2$children[[3]] <- xmlNode("reagentkitlot", kitlot)
    l2$children[[4]] <- xmlNode("analysisdate", analysisdate)
    l2$children[[5]] <- xmlNode("appVersion", appVersion)
    l$children[[2]] <- l2

    # create /report/plate_error
    l$children[[3]] <- xmlNode("plate_error", xmlNode("num",0) )

    # create /report/samples
    l$children[[4]] <- xmlNode("samples")

    return( l )

}

##' generate xml for one sample
##'
##' Generates the XML needed to represent one sample in a simple
##' report
##' @title Generate XML for one sample to use in simple report
##' @param plate.data.row a row from a plate.data representing this
##'     sample
##' @param sample.register.row a row from a sample register for this
##'     sample
##' @param bacteria.table.row a row from a table of probe levels for
##'     this sample
##' @param di Dysbiotic indicator value
##' @param di.comment Report comment
##' @param error.strings QC error result string
##' @param di.error QC error detail string
##' @return xml node representing a single sample, to be inserted into
##'     a simple report
##' @author Torbjørn Lindahl
generate.sample.xml <- function( plate.data.row, sample.register.row, bacteria.table.row,
                                di, di.comment="None.",
                                error.strings="Passed.", di.error="" ) {

    if( is.na( di ) ) {
        di <- -1
        di.result <- "DISQUALIFIED"
    } else if( di %between% c(0,2) ) {
        di.result <- "NEGATIVE"
    } else if( di %between% c(2,5) ) {
        di.result <- "POSITIVE"
    } else {
        stop( "Invalid di value: ", di )
    }

    di2 <- ceiling( di )

    if( !is.vector(bacteria.table.row) && nrow(bacteria.table.row) == 1 ) {
        bacteria.table.row <- bacteria.table.row[1,,drop=TRUE]
    }

    if(!is.vector(bacteria.table.row) ) {
        stop("bacteria.table.row should be a vector")
    }

    plate.data.row[ is.na( plate.data.row ) ] <- NaN
    bacteria.table.row[ is.na( bacteria.table.row ) ] <- NaN

    di.result.message.map <- list(
      POSITIVE = "The GA-map\u00ae does identify dysbiosis",
      NEGATIVE = "The GA-map\u00ae does not identify dysbiosis",
      DISQUALIFIED = "The GA-map\u00ae disqualifies the entire run"
      )

    sample.node <- xmlNode("sample")

    sample.node$children[[ length(sample.node$children) + 1 ]] <-
        xmlNode( "id", plate.data.row$Sample )
    sample.node$children[[ length(sample.node$children) + 1 ]] <-
        xmlNode( "location", as.character(plate.data.row$Location) )

    ## current sample register layout:

    ## > names(d)
    ##   [1] "X"
    ##   [2] "Sample.file"
    ##   [3] "Sample.ID"
    ##   [4] "GA.sample.ID"
    ##   [5] "Patient.first.name"
    ##   [6] "Patient.last.name"
    ##   [7] "Gender"
    ##   [8] "Date.of.birth..yy.mm.dd."
    ##   [9] "Social.security.number"
    ##  [10] "Sample.receive.date.at.GA..YYMMDD."
    ##  [11] "Sample.collection.date..YYMMDD."
    ##  [12] "Requisition.form"
    ##  [13] "Sufficient.sample.material..Y.N."
    ##  [14] "From.clinic"
    ##  [15] "Clinic.address.line.1"
    ##  [16] "Clinic.address.line.2"
    ##  [17] "Salutation"
    ##  [18] "From.doctor"
    ##  [19] "AID.no..AIDYYMMDD."
    ##  [20] "Sample.status.........see.A.01.Protocol.for.details."
    ##  [21] "Sign..Operator"
    ##  [22] "Comments"

    tag.sr.field.map <- c(
        physician        = "From.doctor",
        salutation       = "Salutation",
        clinic           = "From.clinic",
        addressLine1     = "Clinic.address.line.1",
        addressLine2     = "Clinic.address.line.2",
        aid              = "AID.no..AIDYYMMDD.",
        requisition      = "Requisition.form",
        sampledate       = "Sample.collection.date..YYMMDD.",
        samplerecdate    = "Sample.receive.date.at.GA..YYMMDD.",
        patientFirstName = "Patient.first.name",
        patientLastName  = "Patient.last.name",
        dateofbirth      = "Date.of.birth..yy.mm.dd.",
        personalId       = "Social.security.number",
        gender           = "Gender"
    )

    for( tag.name in names(tag.sr.field.map) ) {

        sr.value <- ""

        ## if(!missing(sample.register.row)) {
        if(!missing(sample.register.row)) {
            sr.field <- tag.sr.field.map[ tag.name ]
            sr.value <- unlist( sample.register.row[1, sr.field] )
            if( is.na(sr.value) )
                sr.value <- ""
        }

        sample.node$children[[ length(sample.node$children) + 1 ]] <- xmlNode( tag.name, sr.value )

    }

    ## bead values
    probes <- probe.set("ibs3")
    beads <- probe.set("ibs3",type="bead.number")

    for( i in seq_along(probes)) {

        probe.code <- probes[i]
        probe.bead.number <- as.numeric(beads[i])

        bead.values <- xmlNode( "value" )

        bead.values$children[[ length(bead.values$children) + 1 ]] <- xmlNode(
            "bead",
            sprintf( "%04d", probe.bead.number )
        )

        bead.values$children[[ length(bead.values$children) + 1 ]] <-
            xmlNode( "raw_value", unlist(plate.data.row[ 1, probe.code ]) )

        m <- match( probe.code, colnames( bacteria.table.row ) )

        if( !is.na(m) ) {
            bead.values$children[[ length(bead.values$children) + 1 ]] <- xmlNode( "class", bacteria.table.row[,m] )
        }

        sample.node$children[[ length(sample.node$children) + 1 ]] <- bead.values

    }

    ## result section
    result.node <- xmlNode( "result", di.result )
    result.message.node <- xmlNode( "result_message", di.result.message.map[[ di.result ]] )
    di.node <- xmlNode( "DI", di2 )

    dysbiosis <- xmlNode( "dysbios", result.node, result.message.node, di.node )

    sample.node$children[[ length(sample.node$children) + 1 ]] <- dysbiosis

    sample.node$children[[ length(sample.node$children) + 1 ]] <- xmlNode("comment", di.comment )

    sample.node$children[[ length(sample.node$children) + 1 ]] <- xmlNode("error", di.error )

    error.strings.node <- xmlNode("error_strings")

    for( error.string in error.strings ) {
        error.strings.node$children[[ length(error.strings.node$children) + 1 ]] <-
          xmlNode( "sample_error", error.string )
    }

    sample.node$children[[ length(sample.node$children) + 1 ]] <- error.strings.node

    return( sample.node )

}
