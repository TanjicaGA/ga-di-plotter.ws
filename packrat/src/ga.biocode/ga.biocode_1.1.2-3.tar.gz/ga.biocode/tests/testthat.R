library(testthat)
library(ga.biocode)

test_check("ga.biocode")
