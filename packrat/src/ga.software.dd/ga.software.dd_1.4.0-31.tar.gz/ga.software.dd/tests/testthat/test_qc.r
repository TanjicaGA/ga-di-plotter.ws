library(ga.software.dd)
library(ga.data)
library(ga.utils)
library(ga.gamap)
library(testthat)

options( stringsAsFactors=FALSE )

context( "calculate qc" )

tf1 <- normalizePath( "data/lx200-files/TestFile-01.csv" )
tf2 <- normalizePath( "data/lx200-files/TestFile-02.csv" )

test_that( "evaluate.probe work", {

    ## single probes

    expect_equal( 0, ga.software.dd:::evaluate.probe( 0, c(0) ) )

    expect_equal( 1, ga.software.dd:::evaluate.probe( -1, c(0) ) )
    expect_equal( 2, ga.software.dd:::evaluate.probe( -2, c(0) ) )
    expect_equal( 3, ga.software.dd:::evaluate.probe( -3, c(0) ) )

    expect_equal( 1, ga.software.dd:::evaluate.probe( 1, c(0) ) )
    expect_equal( 2, ga.software.dd:::evaluate.probe( 2, c(0) ) )
    expect_equal( 3, ga.software.dd:::evaluate.probe( 3, c(0) ) )

    expect_equal( 3, ga.software.dd:::evaluate.probe( 3, c(-1) ) )
    expect_equal( 3, ga.software.dd:::evaluate.probe( -3, c(1) ) )

    ## dual probes

    expect_equal( 0, ga.software.dd:::evaluate.probe( 0, c(0,1) ) )
    expect_equal( 0, ga.software.dd:::evaluate.probe( 1, c(0,1) ) )

    expect_equal( 1, ga.software.dd:::evaluate.probe( -1, c(0,1) ) )
    expect_equal( 1, ga.software.dd:::evaluate.probe(  2, c(0,1) ) )

    ## ±2 count double for dual probes
    expect_equal( c(2,2), ga.software.dd:::evaluate.probe( -2, c(0,1) ) )
    expect_equal( c(2,2), ga.software.dd:::evaluate.probe(  3, c(0,1) ) )

    ## triple probes

    expect_equal( 0, ga.software.dd:::evaluate.probe( 0, c(0,1,2) ) )
    expect_equal( 0, ga.software.dd:::evaluate.probe( 1, c(0,1,2) ) )
    expect_equal( 0, ga.software.dd:::evaluate.probe( 2, c(0,1,2) ) )

    ## differences count double for triple probes
    expect_equal( 2, ga.software.dd:::evaluate.probe( -1, c(0,1,2) ) )
    expect_equal( 2, ga.software.dd:::evaluate.probe(  3, c(0,1,2) ) )

    expect_equal( 3, ga.software.dd:::evaluate.probe( -2, c(0,1,2) ) )
    expect_equal( 3, ga.software.dd:::evaluate.probe(  3, c(-1,0,1) ) )

})

test_that( "events.from.vector works", {

    l <- bacteria.table.qc.parameters()
    v <- sapply( l$QCC23$ranges, function(e)e[1] )
    names(v) <- names( l$QCC23$ranges )

    v2 <- unlist( ga.software.dd:::events.from.vector( v, l$QCC23$ranges ) )
    expect_true( all( v2 == 0 ), "test vector is all zeros" )

    v3 <- v
    v3["AG0895"] <- 2

    ## v3b <- ga.software.dd:::events.from.vector( v3, l$QCC23$ranges )
    ## cat("\n")
    ## print( attr( v3b, "events-per-probe" ) )

})

test_that( "evaluate.events work", {

    l <- bacteria.table.qc.parameters()

    f <- function(x) {
        if( missing(x) )
            x <- rep( 0, 39 )
        names( x ) <- names(l$QCC23$ranges)
        x
    }

    v <- f()
    expect_equivalent( ga.software.dd:::summarize.events(f()), c(39,0,0,0) )
    v[1] <- 1
    expect_equivalent( ga.software.dd:::summarize.events(  v), c(38,1,0,0) )
    v[2] <- 1
    expect_equivalent( ga.software.dd:::summarize.events(  v), c(37,2,0,0) )
    v[3] <- 2
    expect_equivalent( ga.software.dd:::summarize.events(  v), c(36,3,1,0) ) # the 2 adds to the 1s too
    v[4] <- 2
    expect_equivalent( ga.software.dd:::summarize.events(  v), c(35,4,2,0) ) # the 2 adds to the 1s too
    v[5] <- 3
    expect_equivalent( ga.software.dd:::summarize.events(  v), c(34,5,3,1) ) # the 2 adds to the 1s too

})

test_that( "evaluating qc works", {

    l <- list( "1"=2, "2"=1, "3"=0 )

    expect_true ( ga.software.dd:::evaluate.qc( c("0"=39,"1"=0,"2"=0,"3"=0), l ))
    expect_true ( ga.software.dd:::evaluate.qc( c("0"=38,"1"=1,"2"=0,"3"=0), l ))
    expect_true ( ga.software.dd:::evaluate.qc( c("0"=37,"1"=2,"2"=0,"3"=0), l ))
    expect_false( ga.software.dd:::evaluate.qc( c("0"=36,"1"=3,"2"=0,"3"=0), l ))

    expect_true ( ga.software.dd:::evaluate.qc( c("0"=39,"1"=1,"2"=1,"3"=0), l ))
    expect_false( ga.software.dd:::evaluate.qc( c("0"=39,"1"=2,"2"=2,"3"=0), l ))

    expect_false( q <- ga.software.dd:::evaluate.qc( c("0"=39,"1"=2,"2"=2,"3"=1), l ))

    m <- attr( q, "reason" )
    expect_length( m, 2 ) # it fails both ±2 and ±3 only

})

test_that( "checking a bt vector works", {

    l <- bacteria.table.qc.parameters()

    f <- function(x) {
        if( missing(x) )
            x <- rep( 0, 39 )
        names( x ) <- names(l$QCC23$ranges)
        x
    }

    v1 <- sapply( l$QCC23$ranges, function(e)e[1] )
    v <- f()

    expect_true( qc1 <- ga.software.dd:::bacteria.table.vector.qc( v1, "QCC23", qc.ranges=l ) ) # a vector from accepted values should pass
    l1 <- unlist( attr( qc1, "events-per-probe" ) )
    expect_length( l1, 0 ) # should be nothing here for all accepted values
    l1.r <- unlist( attr( qc1, "reason" ) )
    expect_length( l1.r, 0 ) # should be no reason for failure

    expect_false( qc2 <- ga.software.dd:::bacteria.table.vector.qc( v, "QCC23", qc.ranges=l ) ) # all 0s should not pass
    l2 <- unlist( attr( qc2, "events-per-probe" ) )
    expect_gt( length(l2), 0 ) # should have 1 or more things going on in it
    l2.r <- unlist( attr( qc2, "reason" ) )
    expect_length( l2.r, 2 ) # it should fail on both ±1 and ±2

})

test_that( "qc on a whole plate works", {

    ## per sample

    qc <- abundancy.table.qc( tf1, batch="PS1404" ) # give it a really weird kitlot
    expect_true( all(!qc), "qc is FALSE" )

    qc2 <- abundancy.table.qc( tf1, batch="L1906" ) # an ok kitlot
    expect_true( all(qc2), "qc is TRUE" )

    ## per plate

    qc3 <- abundancy.table.qc( tf1, batch="PS1404", report.per.sample=FALSE ) # give it a really weird kitlot
    expect_length( qc3, 1 )
    expect_false( qc3 )

    ## multiple plates
    qc4 <- abundancy.table.qc( c(tf1,tf2), batch="PS1404" )
    expect_gt( length(qc4), length(qc) ) # should be more values this time
    expect_true( all(!qc4), "none of the plastes pass" )

    qc5 <- abundancy.table.qc( c(tf1,tf2), batch="L1902", report.per.sample=FALSE )
    expect_true( all(qc5) )
    expect_length( qc5, 2 )

})

test_that( "from data.frame works", {

    x <- gamap(tf1,stop.at="file")
    qc <- abundancy.table.qc( x, start.from="file", batch="L1906" )
    expect_true( all(qc) )

})
