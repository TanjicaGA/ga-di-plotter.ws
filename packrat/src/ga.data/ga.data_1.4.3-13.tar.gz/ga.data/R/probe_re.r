##' regex for probe names
##'
##' A regular expression that matches probe names
##' @title probe regex
##' @return a regex
##' @author Torbjørn Lindahl
##' @export
##' @param include.technical include regexp for technical probes HYC, UNI and BLANK
##' @param anchor add ^ and $ to the regex, first and last
probe.re <- function(include.technical=FALSE, anchor=FALSE ) {

    rx <- "([AI]G\\d{4})"

    if( include.technical )
        rx <-  "([AI]G\\d{4}|UNI\\d+|HYC\\d+|BLANK\\d+)"

    if( anchor )
        rx <- paste0( "^", rx, "$" )

    rx

}
