##' Operator for setting missing defaults
##'
##' Sets the RHS value to the LHS name if its missing in a function body
##' @title Set missing defaults
##' @param a variable to assign to
##' @param value default value
##' @return Invissibly returns the value of a
##' @author Torbjørn Lindahl
##' @usage a \%?<-\% value
##' @export
`%?<-%` <- function( a,value ) {

    var.name <- as.character(substitute(a))
    its.missing <- eval( parse( text=paste0('missing(',var.name,')') ),
                        envir=parent.frame() )

    if( its.missing ) {
        assign( var.name, value, envir=parent.frame() )
    }
    else {
        value <- a
    }

    invisible(value)

}

##' Filtering for vectors
##'
##' Simple filtering using an operator. The RHS is evaluated as a
##' function with the LHS as argument.
##' @title Filter operator
##' @name vector-filter
##' @rdname vector-filter
##' @param a Expression to be filtered
##' @param b Filter, evaluated as a function that takes one argument, a
##' @return The input a filtered through b
##' @author Torbjørn Lindahl
##' @usage a \%>>\% b
##' @examples x <- c(1,2,3,NA,5)
##' @examples x %>>% is.na
##' @examples ## c(FALSE,FALSE,FALSE,TRUE,FALSE)
##' @export
`%>>%` <- function(a,b) {
    if(inherits( b, "function" )) {
        return( b(a) )
    }
    else {
        return( `%~%`(a,b) )
    }
}

##' @rdname vector-filter
##' @param value new value to assign to matching indeces
##' @usage a \%>>\% b <- value
##' @examples x %>>% is.na <- 99
##' @examples ## x: c(1,2,3,99,5)
##' @export
`%>>%<-` <- function(a,b,value) {
    a[ `%>>%`(a,b) ] <- value
    return( a )
}

##' Assign to values matching a == comparison
##'
##' Easily assigns to LHS variable on == subindex
##' @title Assign values matching ==
##' @name equals-set
##' @param a LHS
##' @param b RHS
##' @param value New value
##' @return a with new values for == b
##' @author Torbjørn Lindahl
##' @usage a == b <- value
##' @export
`==<-` <- function(a,b,value) {
    a[ a == b ] <- value
    a
}

##' @rdname equals-set
##' @usage a != b <- value
`!=<-` <- function(a,b,value) {
    a[ a != b ] <- value
    a
}

##' between
##'
##' Checks all values of x against the inclusive range defined by the
##' next two numbers
##' @title TRUE for values between the provided range
##' @param x value to test for
##' @param ... values defining the range
##' @return logical
##' @author Torbjørn Lindahl
##' @export
`%between%` <- function(x,...) {
  y <- range( unlist(c(...)) )
  return( x >= y[1] & x <= y[2] )
}

##' short hand for "not in"
##'
##' The same as doing: ! (x \%in\% table), see %in%.
##' @name not in
##' @usage x \%!in\% table
##' @title not in
##' @param x value to check against a vector
##' @param table vector to check against
##' @return logical, correspoinding to ! (x \%in\% table)
##' @author Torbjørn Lindahl
##' @rdname notin
##' @export
`%!in%` <- function( x, table ) {
    return( ! `%in%`( x, table ) )
}

##' Perl'ish regexp operator
##'
##' Allows operator evalutaion of regular expressions. Uses plain
##' grepl for now.
##' @title regexp operator
##' @param a regexp
##' @param b data
##' @usage a %~% b
##' @return logical corresponding to grepl(b,a), or !grepl(b,a) for %!~%
##' @author Torbjørn Lindahl
##' @rdname regexop
##' @export
`%~%` <- function(a,b) {
    grepl( b, a, perl=TRUE )
}

##' @rdname regexop
##' @export
`%~*%` <- function(a,b) {
    grepl( b, a, perl=TRUE, ignore.case=TRUE )
}


##' @rdname regexop
##' @usage a %!~% b
##' @usage NULL
##' @export
`%!~%` <- function(a,b) {
    !grepl( b, a, perl=TRUE )
}

##' @rdname regexop
##' @export
`%!~*%` <- function(a,b) {
    grepl( b, a, perl=TRUE, ignore.case=TRUE )
}


##' @rdname regexop
##' @usage a %~% b <- value
##' @export
`%~%<-` <- function(a,b,value) {
    a[ `%~%`(a,b) ] <- value
    return( a )
}

##' @rdname regexop
##' @usage a %!~% b <- value
##' @export
`%!~%<-` <- function(a,b,value) {
    a[ `%!~%`(a,b) ] <- value
    return( a )
}
