library(ga.utils)

context("capwords() caps words")

test_that( "Simple one word cases work", {

  expect_that(
    capwords("hello"),
    is_identical_to("Hello")
    )

  expect_that(
    capwords("HELLO" ),
    is_identical_to("HELLO")
    )

  expect_that(
    capwords("HELLO", strict=TRUE ),
    is_identical_to("Hello")
    )

  expect_that(
    capwords("HELLO", strict=FALSE ),
    is_identical_to("HELLO")
    )

})

test_that( "Same tests with two words cases work", {

  expect_that(
    capwords("hello you"),
    is_identical_to("Hello You")
    )

  expect_that(
    capwords("HELLO YOU" ),
    is_identical_to("HELLO YOU")
    )

  expect_that(
    capwords("HELLO YOU", strict=TRUE ),
    is_identical_to("Hello You")
    )

  expect_that(
    capwords("HELLO YOU", strict=FALSE ),
    is_identical_to("HELLO YOU")
    )

})
