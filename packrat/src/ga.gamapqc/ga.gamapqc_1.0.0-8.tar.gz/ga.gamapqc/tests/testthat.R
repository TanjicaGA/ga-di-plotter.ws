library(testthat)
library(ga.gamapqc)

test_check("ga.gamapqc")
