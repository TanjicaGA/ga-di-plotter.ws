dd.plate.qc <- function( plate.data ) {

## gamap.qc.plate.qc <- function(  ) {

    count.data <- attr( plate.data, "count" )

    ## 1. CHECK 01 - ALL 3 QCC'S ARE PRESENT
    qc.check.01 <- ga.gamapqc:::gamap.qc.plate.cp.01.qcc.count( plate.data )

    ## 2. CHECK SAMPLE QCC30
    qc.check.02 <- ga.gamapqc:::gamap.qc.plate.cp.02.qcc30.checks( plate.data, count.data )

    up <- unique(plate.data$Plate)
    plate.count <- length(up)

    ## 4. Compose all sources of plate QC into one matrix.
    qc.checks <- lapply( 1:plate.count, function(i) {
        return( c(
            qc.check.01[[i]],
            qc.check.02[[i]]
            ## qc.check.03.qcc23[[i]],
            ## qc.check.03.qcc33[[i]]
            ))
    })

    ## Evaluate each plate
    evaluators <- c(
        ga.gamapqc:::gamap.qc.evaluation.01.qcc.count,
        ga.gamapqc:::gamap.qc.evaluation.02.qcc30.qc
        ## "gamap.qc.evaluation.03.pos.neg.qc"
    )

    plate.qc <- lapply( 1:plate.count, function(i) {
        plate.status <- TRUE
        plt <- up[i]
        platform <- plate.data$Platform[ plate.data$Plate %in% plt ][1]
        for( ev.func in evaluators ) {
            plate.status <- ev.func( qc.checks[[i]], platform=platform )
            if( !plate.status )
                break
        }
        plate.status
    })

    return( plate.qc )

}
