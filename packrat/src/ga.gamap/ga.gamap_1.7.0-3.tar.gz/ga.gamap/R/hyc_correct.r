##' HYC01 correction of data
##'
##' Divides the matrix by the provided vector.
##' @title hyc adjust
##' @param x input matrix
##' @param hyc.vector HYC01 vector
##' @return matrix, data after adjustment
##' @author Torbjørn Lindahl
##' @export
hyc.correct <- function(x, hyc.vector) {

  if( missing( hyc.vector ) ){
    hyc.vector <- x[,"HYC01"]
    x <- x[, colnames(x) != "HYC01",drop=FALSE]
  }

  x <- sweep( x, 1, hyc.vector, FUN="/" )

  return( x )

}
