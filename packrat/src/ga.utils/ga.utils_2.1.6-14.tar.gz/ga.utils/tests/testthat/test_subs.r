library(ga.utils)

context( "subs and gsubs" )

test_that( "bad arguments are handled", {

    expect_error(
      subs( 1:5, 1:4, 1 ),
      "same length"
      )

    # One of either works:
    subs( 1:5, 1, 1 )
    subs( 1, 1:5, 1 )
    subs( 1:5, 1:5, 1 )

})

test_that( "Normal operations work", {

    ## one pattern
    expect_equal(
      subs( "A", "B", "A" ),
      "B"
      )

    ## two patterns, going there and back again
    expect_equal(
      subs( c("A","B"), c("B","A"), "A" ),
      "A"
      )

    ## more complex operation
    expect_equal(
      subs( LETTERS[1:2], LETTERS[3:4], "ABC" ),
      "CDC"
      )

})
