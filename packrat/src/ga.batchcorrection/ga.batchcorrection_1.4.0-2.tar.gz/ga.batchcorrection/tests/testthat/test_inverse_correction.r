library(ga.batchcorrection)
library(ga.gamap)
library(ga.data)

lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )

context( "inverse correction" )

test_that( "inverse correction works", {

    x <- gamap( lx200.file, stop.at="qcc" )

    bcf <- batch.correction("PS1801L")

    expect_equal(
        inverse.correct( bcf, correct( bcf, x ) ),
        x
    )

    bcf2 <- batch.correction("PS1504")

    expect_equal(
        inverse.correct( bcf2, correct( bcf2, x ) ),
        x
    )

    bcf3 <- batch.correction("PS0000")

    expect_equal(
        inverse.correct( bcf3, correct( bcf3, x ) ),
        x
    )

    bcf4 <- structure(
        class="batchcorrection",
        .Data=list(
            coefficients=c(
                rep( .8, 54 )
            ),
            type="ratio",
            psf.name="PS1234",
            outliers=list(),
            model=NULL
        )
    )

    expect_equal(
        inverse.correct( bcf4, correct( bcf4, x ) ),
        x
    )

})
