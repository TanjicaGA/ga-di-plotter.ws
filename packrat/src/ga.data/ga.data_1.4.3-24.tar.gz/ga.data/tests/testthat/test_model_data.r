library(ga.data)

context( "model data" )

test_that( "model data seems right", {

    expect_is( model.qcc30.data(), "matrix" )

})
