##' Get batch correction object
##'
##' Returns the batch correction object specified.
##' @title batch correction
##' @param batch.name name of batch to fetch, PS number of K number
##' @return batchcorrection object
##' @author Torbjørn Lindahl
##' @export
batch.correction <- function(batch.name) {

    if( !exists( batch.name ) ) {
        batch.name <- psf.from.kitlot( batch.name )
    }

    if(!exists(batch.name)) {
        stop("batch",batch.name,"is not available")
    }

    invisible(get(batch.name))
}

##' Look up PSF for a kitlot
##'
##' Looks up the kitlot in the json mapping file and returns PS names
##' @title Kitlot to PS lookup
##' @param kitlot kitlot to look up
##' @param allow.fail logical default FALSE, if TRUE, gives an error
##' if the kitlot is not found
##' @return psf name, eg PS0000
##' @author Torbjørn Lindahl
##' @importFrom jsonlite fromJSON
##' @export
psf.from.kitlot <- function( kitlot, allow.fail=FALSE ) {

    map <- .kitlot.json()

    if( !kitlot %in% names(map) ) {

        if( !allow.fail ) {
            stop( paste("kitlot", kitlot, "not available") )
        }

        return()

    }

    psf <- map[[kitlot]]

    if( !grepl("^PS\\d{4}L?$", psf ) ) {
        warning( "PSF name", psf, "doesnt look normal" )
    }

    return( psf )

}

##' List available batches
##'
##' Lists all PS names registered and all kitlots that map to them
##' @title List available matches
##' @return character with names of batches
##' @author Torbjørn Lindahl
##' @export
available.batches <- function() {

    e <- getNamespace("ga.data")
    ps.names <- grep( "^PS\\d{4}L?$", ls(e), value=TRUE )

    map <- .kitlot.json()

    return( c( ps.names, names(map) ) )

}

##' Parses kiltot json to list
##'
##' Internal - parses kiltot json to list
##' @title Parses kiltot json to list
##' @return list
##' @author Torbjørn Lindahl
##' @rdname kitlot-json
##' @importFrom readr read_file
.kitlot.json <- function() {

    f <- system.file(
      "kitlot_mapping.json",
      package="ga.data",
      mustWork=TRUE
      )

    json <- read_file(f)

    map <- jsonlite::fromJSON(json)

}
