##' turn something into numbers via factors
##'
##' Converts seomthing to factor and then to numbers to make numeric
##' something that wasn't in the first place.
##'
##' Useful if you eg. need colors for categories in a plot: plot( ...,
##' col=nf(sample.classes) ) # if sample.classes are "Normal", "IBD"
##' and "IBS", they now get numbers 1:3 (in alphabetical order)
##' @title turn something into numbers
##' @param ... arguments to as.factor
##' @return numbers
##' @author Torbjorn Lindahl
##' @export
nf <- function(...)as.numeric(as.factor(...))
