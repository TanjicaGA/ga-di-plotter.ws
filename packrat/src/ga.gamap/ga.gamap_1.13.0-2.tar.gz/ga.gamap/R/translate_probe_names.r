##' Translate biocode probes to internal codes
##'
##' Translates the probe numbers found in biocode data to internal
##' codes
##' @title Translate probe names of object
##' @return character
##' @author Torbjørn Lindahl
##' @param x data to translate names of
##' @export
##' @importFrom ga.data probe.set
translate.probe.names <- function(x) {

    if( !is.null(dim(x)) ){
        cn0 <- colnames(x)
    }
    else if( is.character(x) ) {
        cn0 <- x
    }
    else {
        cn0 <- names(x)
    }

    i <- grepl( "^X?\\d+$", cn0 )
    i.ag <- grepl( "^[AI]G\\d+|BLANK[12]|UNI05|HYC01$", cn0 )

    cn <- sub( "^X", "", cn0[i] )

    ag <- cn0[i.ag]

    ## re-written from when the sql backend was used
    d <- data.frame(
      platform_probe=ga.data::probe.set("ibs3","bead.number"),
      probe=ga.data::probe.set("ibs3","code"),
      stringsAsFactors=FALSE
      )

    cn0.trans <- rep( NA, length(cn0) )

    m <- match( cn, d$platform_probe )
    cn0.trans[i] <- d$probe[m]

    m2 <- match( ag, d$probe )

    if( length(m2) > 0 )
      cn0.trans[i.ag] <- d$platform_probe[m2]

    ## keep names not translated in any direction
    cn0.trans[ is.na(cn0.trans) ] <- cn0[ is.na(cn0.trans) ]

    return( cn0.trans )

}
