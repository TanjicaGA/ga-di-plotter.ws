##' Translate kit names to QCC names
##'
##' Any kit specific QCC samples names gets translated to their QCC
##' equivalent
##' @title Translate to QCC names
##' @param sn.names input names to translate
##' @return character, translated qcc names
##' @author Torbjørn Lindahl
##' @export
translate.qcc.names <- function( sn.names ) {

    qcc.names <- data.frame(
      qcc      = c("QCC30","QCC23","QCC33"),
      kit = c("End-labeling ctrl pos","Kit ctrl pos","Kit ctrl neg"),
      stringsAsFactors = FALSE
    )

    for( j in 1:nrow(qcc.names) ) {
        sn.names <- sub( paste0( "^", qcc.names$kit[j] ), qcc.names$qcc[j], sn.names )
    }

    return( sn.names )

}

##' Translate QCC names to kit names
##'
##' Translate QCC names to kit names
##' @title translate kit names to QCC names
##' @param qcc.names QCC names to translate
##' @return character, translated names
##' @author Torbjørn Lindahl
##' @export
kit.name.from.qcc.name <- function( qcc.names ) {

    qcc.name.system <- data.frame(
      qcc      = c("QCC30","QCC23","QCC33"),
      kit = c("End-labeling ctrl pos","Kit ctrl pos","Kit ctrl neg"),
      stringsAsFactors = FALSE
    )

    return( qcc.name.system$kit[ match( qcc.names, qcc.name.system$qcc )  ] )

}
