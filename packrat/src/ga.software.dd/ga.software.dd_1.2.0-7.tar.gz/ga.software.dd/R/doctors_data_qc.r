## ##' Perform QC for DD
## ##'
## ##' Does the usual QC, except no assessment on DI
## ##' @title doctor's data QC
## ##' @param ... arguments to ga.gamap()
## ##' @return logical, one value per sample in the input
## ##' @author Torbjørn Lindahl
## ##' @importFrom ga.gamap gamap
## ##' @export
## doctors.data.qc <- function( ... ) {

##     stop("Not using this. This is all taken care of it in the main ab.t.qc.function")

##     plate.data <- gamap( ..., stop.at="file" )
##     count.data <- attr( plate.data, "count" )
##     di.num <- gamap( ... )

##     plate.data$Sample <- ga.gamap::translate.qcc.names( plate.data$Sample )
##     names(di.num) <- ga.gamap::translate.qcc.names( names(di.num) )

##     ab.qc <- abundancy.table.qc( ..., report.per.sample=FALSE )

##     ## This is a list, one value per plate
##     plate.qc <- dd.plate.qc( plate.data, count.data, di.num, ab.qc )

##     return( plate.qc )

## }

## dd.plate.qc <- function( plate.data, count.data, di.num, ab.qc ) {

##     ## something to turn the ga.gamapqc functions' results into
##     ## data.frames instead of lists
##     ff <- function( f ) {
##         function( ... ) {
##             l <- f( ... )
##             Reduce( function(a,b){ a <- rbind.data.frame( a, data.frame(t(b), check.names=FALSE ) ) }, x=l, init=NULL )
##         }
##     }

##     ## 1. CHECK 01 - ALL 3 QCC'S ARE PRESENT
##     qc.check.01 <- ff(ga.gamapqc:::gamap.qc.plate.cp.01.qcc.count)( plate.data )
##     ## 2. CHECK SAMPLE QCC30
##     qc.check.02 <- ff(ga.gamapqc:::gamap.qc.plate.cp.02.qcc30.checks)( plate.data, count.data )
##     ## 3. QCC23/33 up to the DI
##     qc.check.03.qcc23 <- dd.qc.plate.cp.03.QCCX3( plate.data, count.data, di.num, ab.qc, "QCC23" )
##     qc.check.03.qcc33 <- dd.qc.plate.cp.03.QCCX3( plate.data, count.data, di.num, ab.qc, "QCC33" )

##     unique.plates <- unique( plate.data$Plate )
##     plate.count <- length( unique.plates )


##     ## Compose the checks
##     ## qc.checks <- lapply( 1:plate.count, function(i) {
##     ##     return( c(
##     ##         qc.check.01[[i]],
##     ##         qc.check.02[[i]],
##     ##         qc.check.03.qcc23[[i]],
##     ##         qc.check.03.qcc33[[i]]
##     ##         ))
##     ## })
##     qc.checks <- Reduce( cbind, list( qc.check.01, qc.check.02, qc.check.03.qcc23, qc.check.03.qcc33 ) )

##     ## Evaluate the checks
##     ev.funcs <- list(
##         ga.gamapqc:::gamap.qc.evaluation.01.qcc.count,
##         ga.gamapqc:::gamap.qc.evaluation.02.qcc30.qc,
##         dd.specific.gamap.qc.evaluation.03.pos.neg.qc
##     )

##     plate.qc <- lapply( 1:plate.count, function(i) {
##         plate.status <- TRUE
##         plt <- unique.plates[i]
##         platform <- plate.data$Platform[ plate.data$Plate %in% plt ][1]
##         for( ev.func in ev.funcs ) {
##             plate.status <- ev.func( unlist(qc.checks[i,]), platform=platform )
##             if( !plate.status )
##                 break
##         }
##         plate.status
##     })

## }


## ##' @importFrom ga.data gamap.qc.ranges
## dd.qc.plate.cp.03.QCCX3 <- function( plate.data, count.data, di.num, ab.qc, qcc.name ) {

##     qc.data <- attr( ab.qc, "qc.data" )

##     plate.apply <- ga.gamapqc:::gamap.qc.plate.lapplier( plate.data )

##     ## ctrl.type <- gamap.qc.pos.neg.name( qcc.name )
##     ## di.valid <- unlist( qc.ranges[ paste(capitalize(ctrl.type),"Ctrl","valid",sep=".") ] )

##     qccX3.check <- plate.apply( function(plate) {

##         i.this.qcc <- grepl( paste0("^",qcc.name), plate.data$Sample ) & plate.data$Plate == plate

##         pf <- plate.data$Platform[ plate.data$Plate == plate ][1]

##         qc.ranges <- gamap.qc.ranges( pf )

##         pd <- plate.data[, grepl( probe.re(include.technical=TRUE), names(plate.data) ) ]
##         cd <- count.data[, grepl( probe.re(include.technical=TRUE), names(count.data) ) ]

##         pd[ cd < qc.ranges$BeadCount.lower ] <- NA

##         ## A range of QC tests is done for all qccX samples per
##         ## plate. At least one sample must pass on all. QC issues must
##         ## be collected per single qcc sample and then evaluated. So
##         ## this routine starts with this.

##         ## 0. the plate index
##         ## qcc.plate.i <- plate.data$Plate[i.this.qcc]

##         ## a. check count <3
##         i.bio <- grepl( probe.re(), colnames(pd) )

##         if( length(qc.ranges$skip.probes) ) {
##             i.bio <- i.bio & !colnames(pd) %in% qc.ranges$skip.probes
##         }

##         lowest.qcc.count.i <- apply( cd[ i.this.qcc, i.bio, drop=FALSE ], 1, min )
##         names( lowest.qcc.count.i ) <- NULL

##         ## b. hyc01 in range
##         ## qcc.hyc01.in.range.i <- plate.data[ i.this.qcc, "HYC01" ] %between% qc.ranges$HYC01.range
##         qcc.hyc01.i <- pd[ i.this.qcc, "HYC01" ]

##         ## c. uni05 above limit
##         ## qcc.uni05.above.limit.i <- plate.data[ i.this.qcc, "UNI05" ] > qc.ranges$UNI05.lower
##         qcc.uni05.i <- pd[ i.this.qcc, "UNI05" ]

##         ## d. blank below bg
##         ## qcc.bg.i <- apply( plate.data[ i.this.qcc, grepl("^BLANK[12]",colnames(plate.data)) ], 1, function(r) {
##         ##     nr <- na.omit(r)
##         ##     length(nr) && all( nr <= qc.ranges$Background.upper )
##         ## })
##         qcc.highest.bg.i <- apply(
##             pd[ i.this.qcc, grepl("^BLANK[12]",colnames(pd)), drop=FALSE ], 1,
##             function(r) {
##                 if( all(is.na(r) ) )
##                     return(NA)
##                 else
##                     return( max(r,na.rm=TRUE) )
##             })


##         ## e. di
##         qcc.di.i <- di.num[i.this.qcc]

##         ## f. ab-table events, ±1, ±2 and ±3

##         qc.data.i <- qc.data[[paste(plate)]][[qcc.name]]
##         pm1 <- sapply( qc.data.i, function(obj){ length(obj$probes$"\u00b11") } )
##         pm2 <- sapply( qc.data.i, function(obj){ length(obj$probes$"\u00b12") } )
##         pm3 <- sapply( qc.data.i, function(obj){ length(obj$probes$"\u00b13") } )

##         names( pm1 ) <- names( pm2 ) <- names( pm3 ) <- names( qcc.di.i )

##         r <- rbind(
##             LowCount=lowest.qcc.count.i,
##             HYC01=qcc.hyc01.i,
##             UNI05=qcc.uni05.i,
##             HighBG=qcc.highest.bg.i,
##             DI=qcc.di.i,
##             "\u00b11" = pm1,
##             "\u00b12" = pm2,
##             "\u00b13" = pm3
##         )

##         rn <- rownames(r)
##         jj <- rep( 1:ncol(r), each=nrow(r) )
##         r <- as.numeric(r)

##         if( length(r) )
##             names(r) <- paste( qcc.name, jj, rn, sep="." )

##         return( r )

##     })

##     x <- Reduce( function(a,b){ a <- rbind.data.frame( a, data.frame(t(b), check.names=FALSE ) ) }, qccX3.check, init=NULL )

##     return(x)

## }

## ##' @importFrom ga.gamap kit.name.from.qcc.name
## ##' @importFrom ga.data gamap.qc.ranges
## dd.specific.gamap.qc.evaluation.03.pos.neg.qc <- function( qc.vector, platform, skip.upper.hyc=TRUE ) {

##     qc.ranges <- gamap.qc.ranges( platform=platform, skip.upper.hyc = skip.upper.hyc )

##     qc.name.message.map <- list(
##         "QCC23" = list(
##         count = 9,
##         hyc01 = 5,
##         uni05 = 13,
##         blank = 16,
##         class = 18,
##         generic = 22
##         ),
##         "QCC33" = list(
##         count = 10,
##         hyc01 = 6,
##         uni05 = 14,
##         blank = 17,
##         class = 19,
##         generic = 23
##         )
##     )

##     filter.out <- function( qc.data, rep.count ) {
##         i <- grepl( paste0("\\.", rep.count, "\\."), rownames(qc.data) )
##         ## qc.data$data[i] <- NA
##         return( qc.data[!i,] )
##     }
##     match.data.point <- function( qc.data, rep.count, rxp ) {
##         rn <- rownames(qc.data)
##         i <- grep( paste0("\\.", rep.count, "\\.", rxp ), rn )
##         return( i )
##     }

##     qccX3.all.errors <- list()

##     for( qcc.name in c("QCC23","QCC33") ) {

##         qccX3.qc.errors <- list()

##         qc.nr.map <- qc.name.message.map[[qcc.name]]
##         if( is.null(qc.nr.map) ){
##             stop( paste( "Didnt find QC numbers for sample", qcc.name ) )
##         }

##         qc.data <- ga.gamapqc:::gamap.qc.parse.qc.vector( qc.vector, paste0(qcc.name,"\\.\\d\\."), qcc.name )
##         rn <- rownames(qc.data)

##         rep.counts <- unique( sub( ".*\\.(\\d)\\..*", "\\1", rn ) )

##         for( rep.count in rep.counts ) {

##             ## Count
##             i.count <- match.data.point( qc.data, rep.count, "LowCount" )
##             if( is.na(qc.data$data[i.count]) || qc.data$data[i.count] < qc.ranges$BeadCount.lower ) {
##                 err.nr <- qc.nr.map$count
##                 qc.data <- filter.out( qc.data, rep.count )
##                 msg <- sprintf( ga.gamapqc:::gamap.qc.error.message(err.nr), kit.name.from.qcc.name(qcc.name) )
##                 qccX3.qc.errors[["Count"]] <- list( err.nr, msg )
##                 next
##             }
##             if( !nrow(qc.data) ) break

##             ## HYC01
##             i.hyc <- match.data.point( qc.data, rep.count, "HYC01" )
##             if( is.na(qc.data$data[i.hyc]) || !qc.data$data[i.hyc] %between% qc.ranges$HYC01.range ) {
##                 ## err.nr <- ifelse( is.na(qc.data$data[i.hyc]), qc.nr.map$count, qc.nr.map$hyc )
##                 err.nr <- qc.nr.map$hyc01
##                 qc.data <- filter.out( qc.data, rep.count )
##                 msg <- sprintf( ga.gamapqc:::gamap.qc.error.message(err.nr), kit.name.from.qcc.name(qcc.name) )
##                 qccX3.qc.errors[["HYC01"]] <- list( err.nr, msg )
##                 next
##             }
##             if( !nrow(qc.data) ) break

##             ## UNI05
##             i.uni <- match.data.point( qc.data, rep.count, "UNI05" )
##             if( is.na(qc.data$data[i.uni]) || qc.data$data[i.uni] < qc.ranges$UNI05.lower ) {
##                 ## err.nr <- ifelse( is.na(qc.data$data[i.uni]), qc.nr.map$count, qc.nr.map$uni05 )
##                 err.nr <- qc.nr.map$uni05
##                 qc.nr.map$generic
##                 qc.data <- filter.out( qc.data, rep.count )
##                 msg <- sprintf( ga.gamapqc:::gamap.qc.error.message(err.nr), kit.name.from.qcc.name(qcc.name) )
##                 qccX3.qc.errors[["UNI05"]] <- list( err.nr, msg )
##                 next
##             }
##             if( !nrow(qc.data) ) break

##             ## BLANK
##             i.blank <- match.data.point( qc.data, rep.count, "HighBG" )
##             if( !is.infinite(qc.ranges$Background.upper) && is.na(qc.data$data[i.blank]) ||
##                 !is.na(qc.data$data[i.blank]) && qc.data$data[i.blank] > qc.ranges$Background.upper ) {

##                 ## err.nr <- ifelse( is.na(qc.data$data[i.blank]), qc.nr.map$count, qc.nr.map$blank )
##                 err.nr <- qc.nr.map$blank
##                 qc.data <- filter.out( qc.data, rep.count )
##                 msg <- sprintf( gamap.qc.error.message(err.nr), ga.gamap::kit.name.from.qcc.name(qcc.name) )
##                 qccX3.qc.errors[["BLANK"]] <- list( err.nr, msg )
##                 next
##             }
##             if( !nrow(qc.data) ) break

##         }

##         if(!nrow(qc.data)) {
##             ## If no qc.data survived this, it means QC did not pass
##             ## qccX3.all.errors[[qcc.name]] <- qccX3.qc.errors
##             err.nr <- qc.name.message.map[[qcc.name]]$generic
##             msg <- sprintf( ga.gamapqc:::gamap.qc.error.message(err.nr), kit.name.from.qcc.name(qcc.name) )
##             qccX3.all.errors[[qcc.name]] <- list( generic=list( err.nr, msg ) )
##         }
##         else {
##             browser()
##             ##  heck that all QC passing samples have valid DI
##             ctrl.type <- ga.gamapqc:::gamap.qc.pos.neg.name( qcc.name ) ## 'pos' or 'neg'

##             di.range <- unlist( qc.ranges[ paste(ga.utils::capwords(ctrl.type),"Ctrl",c("lower","upper"),sep=".") ] )

##             i.di <- match.data.point( qc.data, "\\d+", "DI" )
##             di.i <- qc.data$data[i.di]

##             ## If the DI's are all NA, or if any of them is out of range, then an error
##             if( all(is.na(di.i)) | (any( (di.i >= di.range[1] & di.i <= di.range[2]) %in% FALSE)) ) {
##                 err.nr <- qc.nr.map$class
##                 msg <- sprintf( ga.gamapqc:::gamap.qc.error.message(err.nr), kit.name.from.qcc.name(qcc.name) )
##                 qccX3.all.errors[[qcc.name]] <- list( DI=list( err.nr, msg ) )
##             }
##         }

##     }

##     ret <- length(qccX3.all.errors) == 0

##     if(!ret) {

##         qc.error.numbers <- integer()
##         qc.error.messages <- character()

##         for( l in qccX3.all.errors ) {

##             for( el in l ) {
##                 qc.error.numbers <- append( qc.error.numbers, el[[1]] )
##                 qc.error.messages <- append( qc.error.messages, el[[2]] )
##             }

##         }

##         i <- duplicated( qc.error.numbers )

##         attr( ret, "ErrorNumbers" ) <- qc.error.numbers[!i]
##         attr( ret, "ErrorMessages" ) <- qc.error.messages[!i]

##     }

##     return( ret )

## }
