##' T2/Qres plot
##'
##' Sets up a T2/Q-res plot from the input data. Expects to find T2
##' and Qres in it.
##' @title T2/Q-residuals plot
##' @return ggplot
##' @author Torbjorn Lindahl
##' @param x data to plot
##' @param ... additional arguments to the geom function
##' @param unit.scale work with unit scale, ie dysboisis thresholds
##'     sdcaled to 1.0
##' @param scale.data scale data to unit scale (meaning it isn't in
##'     unit scale, but needs to be)
##' @param geom which geom function to use for each point, defaults to
##'     point
##' @param log.transform plot log transformed axes
##' @param ylim ylim to use
##' @param xlim xlim to use
##' @param aes.arguments further arguments to the aes of ggplot2()
##' @param add.di.threshold default TRUE, add di threshold lines
##' @param add.di.scores default TRUE, add di score curves
##' @importFrom ga.data t2.limit
##' @importFrom ga.data qres.limit
##' @importFrom ggplot2 ggplot scale_x_log10 scale_y_log10 coord_trans coord_cartesian
##' @importFrom utils modifyList
##' @export
gg_t2_qres_plot <- function( x, ..., unit.scale=TRUE, scale.data=TRUE, geom="point",
                            log.transform=TRUE, ylim, xlim, aes.arguments=list(),
                            add.di.threshold=TRUE, add.di.scores=TRUE ) {

    if(!all( c("T2","Qres") %in% colnames(x) )) {
        stop( "Expects both 'T2' and 'Qres' columns in x" )
    }

    if( scale.data ) {
        x <- within(
            x,
        {
            T2 <- T2 / t2.limit()
            Qres <- Qres / qres.limit()
        })
    }

    ge <- try( getExportedValue( "ggplot2", paste0("geom_",geom) ), silent=TRUE )

    if( inherits(ge, "try-error") ) {
        stop( paste( "function geom_", geom, " not found in ggplot2" ) )
    }

    if( missing(ylim) )
        ylim <- c(NA,NA)

    if( missing(xlim) )
        xlim <- c(NA,NA)

    ## determine limits
    yr <- range( x$Qres, na.rm=TRUE )
    xr <- range( x$T2, na.rm=TRUE   )

    if( is.na(ylim[1]) ) {

        ylim[1] <- yr[1]

        if( log.transform ) {
            ylim[1] <- min( ylim[1], 2500 / qres.limit() )
        } else {
            ylim[1] <- 0
        }

    }
    if( is.na(ylim[2]) ) {
        ylim[2] <- yr[2]
    }
    if( is.na(xlim[1]) ) {

        xlim[1] <- xr[1]

        if( log.transform ) {
            xlim[1] <- min( xlim[1], 3/t2.limit() )
        } else {
            xlim[1] <- 0
        }

    }
    if( is.na(xlim[2]) ) {
        xlim[2] <- xr[2]
    }



    aes <- rename_aes(modifyList( aes(x=T2,y=Qres), aes.arguments ))
    g <- ggplot( x, aes )

    if( log.transform ) {
        g <- g + coord_trans( y="log", x="log", limx=xlim, limy=ylim )
    } else {
        g <- g + coord_cartesian( xlim=xlim, ylim=ylim )
    }

    if( add.di.threshold )
        g <- g + geom_di_threshold()
    if( add.di.scores )
        g <- g + geom_di_ellipses()

    g <- g + ge( ... )


    return( g )

}

##' add di threshold
##'
##' Function to add di threshold lines (using geom_line) to a plot
##' @title geom_di_threshold
##' @importFrom ga.data t2.limit
##' @importFrom ga.data qres.limit
##' @importFrom ggplot2 geom_line
##' @importFrom ggplot2 aes
##' @param unit.scale work with unit scale
##' @param lty line type, defaults to 'dashed'
##' @param ... extra arguments to geom_line
geom_di_threshold <- function( unit.scale=TRUE, lty="dashed", ... ) {

    ## keep check from complaining
    x <- y <- DI <- NULL

    xend <- ifelse( unit.scale, 1, t2.limit() )
    yend <- ifelse( unit.scale, 1, qres.limit() )
    geom_line( data=data.frame( x=c(1e-10,xend,xend), y=c(yend,yend,1e-10) ), aes(x=x,y=y), lty=lty, ... )

}

##' add di ellispes
##'
##' Function to add di score curves to a T2/Qres plot
##' @title geom_di_ellipses
##' @importFrom ga.data t2.limit
##' @importFrom ga.data qres.limit
##' @importFrom ga.data numeric.di.parameters
##' @importFrom ggplot2 geom_line
##' @importFrom ggplot2 aes
##' @importFrom ggrepel geom_text_repel
##' @importFrom shape getellipse
##' @param unit.scale work with unit scale
##' @param ... extra arguments to geom_line
geom_di_ellipses <- function( unit.scale=TRUE, ... ) {

    t2.f <- t2.limit()
    qres.f <- qres.limit()

    if( unit.scale ) {
        t2.f <- 1
        qres.f <- 1
    }

    p <- numeric.di.parameters()

    w.t2 <- p$t2.weight
    w.qres <- p$qres.weight

    logm <- p$meanlog
    logs <- p$sdlog

    mdi.3 <- p$di.3
    mdi.4 <- p$di.4

    a3 <- sqrt( mdi.3**2 / w.t2 ) * t2.f
    b3 <- sqrt( mdi.3**2 / w.qres ) * qres.f
    a4 <- sqrt( mdi.4**2 / w.t2 ) * t2.f
    b4 <- sqrt( mdi.4**2 / w.qres ) * qres.f
    a5 <- sqrt( 1/2 ) * t2.f
    b5 <- sqrt( 1/2 ) * qres.f

    ## keep check from complaining
    T2 <- Qres <- x <- y <- DI <- NULL

    d3 <- as.data.frame( getellipse( rx=a3, ry=b3, from=0, to=pi/2, mid=c(1e-12,1e-12) ) )
    colnames(d3) <- c("T2","Qres")
    g3 <- geom_line( data=d3, aes(x=T2,y=Qres), ... )

    d4 <- as.data.frame( getellipse( rx=a4, ry=b4, from=0, to=pi/2, mid=c(1e-12,1e-12) ) )
    colnames(d4) <- c("T2","Qres")
    g4 <- geom_line( data=d4, aes(x=T2,y=Qres), ... )

    d5 <- as.data.frame( getellipse( rx=a5, ry=b5, from=0, to=pi/2, mid=c(1e-12,1e-12) ) )
    colnames(d5) <- c("T2","Qres")
    g5 <- geom_line( data=d5, aes(x=T2,y=Qres), ... )

    f <- c( 1, 1.35, 2.3, 2.8, 3.7 )
    r <- function(di) {
        theta <- pi/4 * 1.2
        return( c( .2 + acos(theta)*di*f[di]/4, asin(theta)*di*f[di]/4 ) )
    }

    gt <- geom_text_repel( data=data.frame( x=t2.f*r(1:5)[1:5], y=qres.f*r(1:5)[6:10], DI=1:5 ), aes(x=x,y=y,label=DI ), size=12, ... )

    list( g3, g4, g5, gt )

}


## fetching a copy of this from ggplot2
rename_aes <- function(x) {
    names(x) <- ggplot2::standardise_aes_names(names(x))
    duplicated_names <- names(x)[duplicated(names(x))]
    if (length(duplicated_names) > 0L) {
        duplicated_message <- paste0(unique(duplicated_names),
            collapse = ", ")
        warning("Duplicated aesthetics after name standardisation: ",
            duplicated_message, call. = FALSE)
    }
    x
}
