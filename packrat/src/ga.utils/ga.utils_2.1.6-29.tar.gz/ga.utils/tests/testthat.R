library(testthat)
library(ga.utils)

test_check("ga.utils")
