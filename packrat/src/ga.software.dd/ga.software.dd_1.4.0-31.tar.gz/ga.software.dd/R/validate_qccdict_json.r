##' valiate qccDict.json for AA software
##'
##' Validates a json file to see if it matches the scheme for
##' qccDict.json as the Abundance Analyzer should have it.
##' @title validate qccDict.json
##' @return boolean
##' @author Torbjørn Lindahl
##' @importFrom readr read_file
##' @importFrom jsonvalidate json_validator
##' @importFrom jsonlite fromJSON
##' @importFrom ga.data available.batches
##' @export
##' @param json.file json file to test
validate.qccdict.json <- function( json.file ) {

    json.test <- TRUE

    ## load it
    json.data <- fromJSON( json.file, simplifyVector=FALSE )
    set.names <- sapply( json.data$sets, function(s)s$name )
    kitlots <- unlist(sapply( json.data$kitlots, function(k)k[1] ))
    kit.sets <- unlist(sapply( json.data$kitlots, function(k)k[2] ))

    ## schema
    json.test <- json.test &&
        local({
            schema <- read_file( system.file( package="ga.software.dd", "qccDict.schema", mustWork=TRUE ) )
            json_validator(schema)( json.file )
        })

    ## missing sets
    json.test <- json.test &&
        local({
            all( kit.sets %in% set.names )
        })

    ## known kitlots
    json.test <- json.test &&
        local({
            all( kitlots %in% available.batches() )
        })

    return( json.test )

}
