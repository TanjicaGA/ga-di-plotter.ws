##' Normal data of model cohort after QCC30 adjustment
##'
##' The QCC30 adjusted data of the normal cohort of the model
##' @title normal data from model
##' @return matrix of qcc30 adjusted data
##' @author Torbjørn Lindahl
##' @export
model.qcc30.data <- function() {
    model.qcc30.adjusted.data
}
