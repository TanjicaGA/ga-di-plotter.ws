##' rundate of file(s)
##'
##' Reports the rundate of provided file(s). Supports biocode, luminex
##' and magpix formats.
##' @title file rundates
##' @param x filenames to report
##' @return vector of rundates
##' @author Torbjorn Lindahl
##' @export
##' @importFrom ga.biocode biocode.rundate
##' @importFrom ga.luminex luminex.rundate
rundate <- function(x) {

    rds <- sapply( x, function(f) {
        pl <- detect.platform.from.file(f)
        if( pl == "biocode" )
            biocode.rundate(f)
        else if( pl %in% c("magpix", "lx200") )
            luminex.rundate(f, require.crc.check=FALSE)
        else
            NA
    }, simplify=FALSE)

    v <- unlist( rds )

    if( any(!is.na(v)) ) {
        i <- which( !is.na(v) )[1]
        attributes(v) <- attributes(rds[[i]])
    }

    v

}
