library(ga.utils)

context("pdf.a4.landscape() creates pdf with right dimensions")

test_that( "check the pdf file", {

    pdf.file <- tempfile( fileext=".pdf" )
    pdf.a4.landscape( pdf.file )

    expect_that(
      names( dev.cur() ),
      is_identical_to( "pdf" )
      )

    plot( 1:10 )
    dev.off()

    expect_that(
      file.exists( pdf.file ),
      is_true()
      )

    expect_that(
      file.info( pdf.file )$size > 0,
      is_true()
      )

    if( Sys.which( "pdfinfo" ) != "" ){

        pdfinfo <- grep( "Page size", system( paste( "pdfinfo", pdf.file ), intern=TRUE ), value=TRUE )

        geom0 <- sub( "^\\D+(\\d+)\\D+(\\d+)\\D.*", "\\1;\\2", pdfinfo, perl=TRUE )
        geom <- as.numeric( unlist( strsplit( geom0, ";" ) ))

        expect_that(
          geom[1],
          equals( 841 )
          )

        expect_that(
          geom[2],
          equals( 595 )
          )

    }

    unlink( pdf.file )

})
