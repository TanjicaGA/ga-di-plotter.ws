##' set guide alpha to 1
##'
##' Just ignore the alpha of the color channel in the legends.
##' @title ggplot legend alpha override
##' @return a ggplot layer
##' @author Torbjorn Lindahl
##' @export
##' @importFrom ggplot2 guides guide_legend
gg_alpha_legend_override <- function() {
    guides(colour = guide_legend(override.aes = list(alpha = 1)))
}
