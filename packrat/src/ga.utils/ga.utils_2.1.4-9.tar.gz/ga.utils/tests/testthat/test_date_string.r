library(ga.utils)

context( "date.string" )

test_that( "date is returned", {

    d <- date.string()

    expect_true(
        grepl( "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$", d )
        )

})
