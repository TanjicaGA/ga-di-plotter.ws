library(ga.software.dd)
library(testthat)

options( stringsAsFactors=FALSE )

context( "sample qc" )

tf7 <- normalizePath( "data/lx200-files/TestFile-07.csv" )

test_that( "normal sample qc issues are caught", {

    dd <- dd.export.csv( tf7, kitlot="L1906", path=NA )
    di.plate <- gamap( tf7, stop.at="file" )
    set.qcc.indeces(di.plate, verbose=FALSE )

    i1 <- which( di.plate$HYC01[!i.qcc30 & !i.qcc29] <= 200 )[1]
    i2 <- which( di.plate$UNI05[!i.qcc30 & !i.qcc29] <= 300 )[1]

    ## x <- gamap( c(tf7, normalizePath( "data/lx200-files/TestFile-01.csv" )), stop.at="file" )
    ## q <- ga.gamapqc:::gamap.qc.sample.qc( x, attr( x, "count" ), qcc.is.na=FALSE )

    expect_false( dd$QC[i1] )
    expect_false( dd$QC[i2] )

})
