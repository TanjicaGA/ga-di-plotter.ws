##' Trim whitespace
##'
##' Remove leading and trailing whitespace from input
##' @title trim whitespace
##' @param values vector to trim values in
##' @param ws.re regexp to replace, defaults to \\s (space, tab, newline )
##' @return trimmped input values
##' @author Torbjørn Lindahl
##' @export
trim <- function( values, ws.re="\\s" ){

  values <- gsub( paste0("^",ws.re,"*|", ws.re, "*$"), "", values )

  return(values)

}
