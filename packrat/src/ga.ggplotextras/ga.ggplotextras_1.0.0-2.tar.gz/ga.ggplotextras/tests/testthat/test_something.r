library(testthat)

context( "ga.ggplotextras" )

test_that( "there is a test", {
    expect_true( TRUE )
})
