library(ga.gamap)
library(ga.biocode)
library(ga.luminex)

biocode.file <- file.path( "data", "Q2-005-K1515_II-BC1511.csv" )

context( "harmonize biocode" )

test_that( "biocode data gets harmonized", {

    d <- read.biocode( biocode.file )$Median
    colnames(d) <- translate.probe.names(colnames(d))

    h <- harmonize.biocode(
        cbind.data.frame(
            File=basename(biocode.file),
            Platform="Biocode",
            d
        )
    )

    expect_identical(
        colnames(h),
        c("File", "Platform", "Location", "Sample", "AG0342",
          "AG0377", "AG0393", "AG0396", "AG0416", "AG0515", "AG0581",
          "AG0608", "AG0620", "AG0638", "AG0651", "AG0686", "AG0703",
          "AG0732", "AG0777", "AG0815", "AG0854", "AG0863", "AG0865",
          "AG0895", "AG0912", "AG0930", "AG0931", "AG0974", "AG1034",
          "AG1046", "AG1061", "AG1099", "AG1118", "AG1152", "AG1225",
          "AG1226", "AG1267", "AG1647", "AG1652", "AG1661", "AG1687",
          "AG1698", "IG0005", "IG0011", "IG0012", "IG0020", "IG0023",
          "IG0028", "IG0044", "IG0053", "IG0058", "IG0060", "IG0063",
          "IG0079", "IG0081", "IG0133", "IG0197", "IG0314", "UNI05",
          "HYC01", "BLANK1", "BLANK2", "Total.Events", "Plate",
          "Coord", "Well", "Row", "Col")
    )

})
