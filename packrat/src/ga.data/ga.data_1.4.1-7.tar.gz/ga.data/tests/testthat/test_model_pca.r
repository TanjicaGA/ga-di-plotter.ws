library(ga.data)

context( "model pca" )

test_that( "model pca seems right", {

    pca <- model.pca()

    expect_is( pca, "prcomp" )

    ## 15 components
    expect_equal(
        dim(pca$x),
        c(165,15)
    )

})

test_that( "full model is returned upon request", {

    pca2 <- model.pca( full=TRUE )

    expect_is( pca2, "prcomp" )

    ## 54 components now
    expect_equal(
        dim(pca2$x),
        c(165,54)
    )

})
