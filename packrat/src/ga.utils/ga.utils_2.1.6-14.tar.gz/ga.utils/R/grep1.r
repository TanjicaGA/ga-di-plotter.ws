##' Grep one
##'
##' \code{grep1} behaves just like \code{\link{grep}} only it ensures
##' there is one and only one match.
##'
##' \code{grepl1} behaves just like \code{\link{grepl}} but ensures that there is
##' one and only one TRUE value in the returned vector. NA's are allowed.
##' @title Grep only one value
##' @param pattern One or more patterns to search for, see \code{\link{grep}}.
##' @param ... Arguments passed to \code{\link{grep}} or \code{\link{grepl}}.
##' @return A numeric or logical, same return value as \code{\link{grep}} and
##' \code{\link{grepl}}.
##' @seealso \code{\link{grep}} and \code{\link{grepl}}.
##' @author Torbjørn Lindahl
##' @export
grep1 <- function( pattern, ...) {
    unlist(lapply( pattern, function(p) {
        d <- grep( p, ... )
        if( length(d) > 1 )
          stop(paste("Found more than one value",p))
        else if( !length(d) )
          stop(paste("Found no values matching",p))
        return(d)
    }))
}

##' @rdname grep1
##' @export
grepl1 <- function( pattern, ...) {
    Reduce(lapply( pattern, function(p) {
        d <- grepl( p, ... )
        s <- sum( d %in% TRUE )
        if( s > 1 )
          stop(paste("Found more than one value of ",p))
        else if( s == 0 )
          stop(paste("Found no values matching",p))
        return(d)
    }), f=`|` )
}
