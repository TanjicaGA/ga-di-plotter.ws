library(testthat)
library(ga.batchcorrection)

test_check("ga.batchcorrection")
