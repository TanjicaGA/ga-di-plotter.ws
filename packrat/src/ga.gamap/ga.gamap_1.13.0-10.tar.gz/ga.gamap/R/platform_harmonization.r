##' harmonize platform
##'
##' gamap.step.file calls this function to accomodate platform
##' differences and possibly auto detect platform
##' @title platform harmonization
##' @param x input argument
##' @param platform which platform to harmonize from
##' @param ... arguments to other methods, typically \code{set.to}
##' @return data frame with expected format for the gamap algorihtm
##' @author Torbjørn Lindahl
harmonize.platform <- function(x, platform=c("biocode","lx200"), ... ) {

    platform <- match.arg(platform)

    if( platform == "biocode" )
        harmonize.biocode(x, ...)
    else if( platform == "lx200" )
        harmonize.lx200(x, ...)

}

##' add technical columns
##'
##' Make sure it has required colnames
##' @title add technical data to the biocode data frame
##' @param x input data.frame, eg Median data from a biocode file
##' @param set.to imputed value to use, NA by default, but for Count
##'     it should be set to 0
##' @return input data.frame with columns added
##' @author Torbjørn Lindahl
##' @importFrom ga.biocode plate.coord
##' @importFrom ga.biocode well.to.row.col
harmonize.biocode <- function(x,set.to=NA) {

    missing.names <- setdiff(
        c("File","Location","Sample"),
        colnames(x)
    )

    if( length(missing.names) ) {
        stop( "Missing names in input: ", paste(missing.names,collapse = ", ") )
    }

    d2 <- with(
        x,
        data.frame(
            Plate = factor( File, levels=seq_along(unique(File)) ),
            Coord = sub(".* \\(([A-H]\\d+)\\).*", "\\1", Location),
            stringsAsFactors=FALSE
        )
    )
    d2$Well <- plate.coord(d2$Coord)

    d2[,c("Row","Col")] <- well.to.row.col( d2$Well )

    cbind.data.frame( x, d2 )

}

##' @importFrom ga.biocode well.to.row.col
##' @importFrom ga.luminex luminex.plate.coord
##' @importFrom ga.data lx200.missing.probes
harmonize.lx200 <- function(x,set.to=NA) {

    missing.names <- setdiff(
        c("File","Platform","Location","Sample"),
        colnames(x)
    )

    if( length(missing.names) ) {
        stop( "Missing names in input: ", paste(missing.names,collapse = ", ") )
    }

    ## add the missing probes
    x[, lx200.missing.probes() ] <- set.to

    ## align to the target names at this point
    target.names <- c("File", "Platform", "Location", "Sample", "AG0342", "AG0377", "AG0393",
    "AG0396", "AG0416", "AG0515", "AG0581", "AG0608", "AG0620",
    "AG0638", "AG0651", "AG0686", "AG0703", "AG0732", "AG0777",
    "AG0815", "AG0854", "AG0863", "AG0865", "AG0895", "AG0912",
    "AG0930", "AG0931", "AG0974", "AG1034", "AG1046", "AG1061",
    "AG1099", "AG1118", "AG1152", "AG1225", "AG1226", "AG1267",
    "AG1647", "AG1652", "AG1661", "AG1687", "AG1698", "IG0005",
    "IG0011", "IG0012", "IG0020", "IG0023", "IG0028", "IG0044",
    "IG0053", "IG0058", "IG0060", "IG0063", "IG0079", "IG0081",
    "IG0133", "IG0197", "IG0314", "UNI05", "HYC01", "BLANK1",
    "BLANK2", "Total.Events")

    if( any( !target.names %in% colnames(x) ) ) {
        stop( "These column names were not found in file: ", paste0(setdiff(target.names,colnames(x)), collapse=", " ))
    }

    target.names.first <- setdiff( target.names, "Total.Events" )
    target.names.then <- setdiff( colnames(x), target.names )
    target.names.last <- "Total.Events"

    x2 <- x[, match( target.names.first, colnames(x) ), drop=FALSE ]

    if(length(target.names.then)) {
        x2 <- cbind( x2, x[, match( target.names.then, colnames(x) ), drop=FALSE ] )
    }

    if(length(target.names.last)) {
        x2 <- cbind( x2, x[, match( target.names.last, colnames(x) ), drop=FALSE ] )
    }

    ## x <- cbind(
    ##     x,
    ##     x[, match( target.names.then, colnames(x) ) ],
    ##     x[, match( target.names.last, colnames(x) ) ]
    ## )

    d2 <- with(
        x2,
        data.frame(
            Plate = factor( File, levels=seq_along(unique(File)) ),
            Coord = luminex.plate.coord(x$Location),
            stringsAsFactors=FALSE
        )
    )
    d2$Well <- plate.coord(d2$Coord)

    d2[,c("Row","Col")] <- well.to.row.col( d2$Well )

    cbind.data.frame( x2, d2 )

}
