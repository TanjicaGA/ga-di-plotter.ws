library(ga.gamap)

context( "translate QCC names" )

test_that( "Full qcc names get translated", {

    the.qcc.names <- c("End-labeling ctrl pos", "Kit ctrl pos", "Kit ctrl neg")

    expect_that(
      translate.qcc.names( the.qcc.names ),
      equals( c("QCC30", "QCC23", "QCC33") )
      )

    other.names <- c( "foo", "bar", "baz" )

    expect_that(
      translate.qcc.names( other.names ),
      equals( other.names )
      )

    expect_that(
      translate.qcc.names( c( the.qcc.names, other.names ) ),
      equals( c("QCC30", "QCC23", "QCC33", other.names) )
      )

    the.qcc.names.B <- c("End-labeling ctrl pos B", "Kit ctrl pos B", "Kit ctrl neg B")
    expected.B <- c("QCC30 B", "QCC23 B", "QCC33 B")

    expect_that(
      translate.qcc.names( the.qcc.names.B ),
      equals( expected.B )
      )

})

test_that( "QCC names can be translated to kit names", {

    qcc.names <- c("QCC23","QCC33","QCC30")

    expect_equal(
      kit.name.from.qcc.name( qcc.names ),
      c("Kit ctrl pos","Kit ctrl neg","End-labeling ctrl pos")
      )

})
