##' Distance matrix
##'
##' Calculates the string distance matrix of the input vector
##' @title Word distances
##' @param x character vector of words
##' @param ... extra arguments to stringdistmatrix
##' @return a matrix
##' @author Torbjørn Lindahl
text.distance <- function( x, ... ) {
    stringdist::stringdistmatrix( x, ... )
}

##' Cluster words based on string distance
##'
##' Uses \code{pamk} to classify and report number of clusters for the
##' input text vectors
##' @title Cluster words based on their string distance
##' @param x vector of words
##' @param k max number of clusters to try, default 5
##' @param ... extra arguments to pamk
##' @return numeric classification vector
##' @author Torbjørn Lindahl
word.clusters <- function( x, k=5, ... ) {
    d <- text.distance(x)
    p <- pamk.best <- fpc::pamk(data=as.matrix(d), k=k, ...)
    if( p$nc == 1 )
      return( invisible( rep( 1, length(x) ) ) )
    p$pamobject$clustering
}
