##' probes on the lx200 platform
##'
##' Returns the probes that are on the LX200 platform.
##' @title probes on the lx200 platform
##' @param among.these optional, a set of probes to narrow the result with
##' @param include.technical include technical probes in list
##' @return probes on the lx200 probes
##' @author Torbjørn Lindahl
##' @export
lx200.probes <- function( among.these, include.technical=TRUE ) {

    m <- lx200.missing.probes()
    p <- setdiff( probe.set("ibs3"), lx200.missing.probes() )

    if( !missing(among.these) )
        p <- intersect( p, among.these )

    if(!include.technical)
        p <- p[ grepl("^[AI]G\\d{4}$",p) ]

    return(p)

}


##' List probes not included in the Lx200 platform
##'
##' Lists the probes that are not included on the Lx200 platform. If a
##' character vector is provided, limits the list to only probes also
##' in this list.
##'
##' This is useful for steps that add NAs to these probes in a data
##' set that doesnt have the BLANK probes any more.
##' @title probes missing on LX200
##' @param among.these report only probes that are in this set, useful
##'     to limit the report to only relevant probes
##' @param include.technical include technical probes in list
##' @return vector of probes not included in the Lx200 platform
##' @author Torbjørn Lindahl
##' @export
lx200.missing.probes <- function( among.these, include.technical=TRUE ) {
    p <- c("AG0342", "AG0854", "AG1118", "AG1267", "AG1647", "AG1652", "BLANK1", "BLANK2")
    if( !missing(among.these) ) {
        p <- intersect( p, among.these )
    }
    if(!include.technical)
        p <- p[ grepl("^[AI]G\\d{4}$",p) ]
    return(p)
}
