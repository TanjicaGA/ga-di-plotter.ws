.onLoad <- function( libname, pkgname ) {
    setup.biobank.credentials()
    setup.bacteria.credentials()
    setup.biobank.dev.test.credentials()
}

##' Setup db credentials
##'
##' Internal function - sets up biobank db credentials in options
##' @title Add biobank db credentials to options
##' @return no return
##' @author Torbjørn Lindahl
setup.biobank.credentials <- function() {

    f <- system.file(
        "biobank_db.json",
        package="ga.data",
        mustWork=TRUE
    )

    json <- read_file(f)
    info <- jsonlite::fromJSON(json)

    options( "biobank_db" = info )

}

##' Setup db credentials
##'
##' Internal function - sets up bacteria db credentials in options
##' @title Add bacteria db credentials to options
##' @return no return
##' @author Torbjørn Lindahl
setup.bacteria.credentials <- function() {

    f <- system.file(
        "bacteria_db.json",
        package="ga.data",
        mustWork=TRUE
    )

    json <- read_file(f)
    info <- jsonlite::fromJSON(json)

    options( "bacteria_db" = info )

}

##' bacteria dev test db credentials
##'
##' Inserts db credentials for a db that can be used for testing
##' @title bacteria dev test db credentials
##' @return returns nothing
##' @author Torbjorn Lindahl
setup.biobank.dev.test.credentials <- function() {

    f <- system.file(
        "biobank_dev_test_db.json",
        package="ga.data",
        mustWork=TRUE
    )

    json <- read_file(f)
    info <- jsonlite::fromJSON(json)

    options( "biobank_dev_test_db" = info )

}
