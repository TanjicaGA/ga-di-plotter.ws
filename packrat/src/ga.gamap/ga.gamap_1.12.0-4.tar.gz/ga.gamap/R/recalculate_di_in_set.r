##' Recalculate DI to reduce impact of DI=2 threshold
##'
##' There is an artifically induced gap in DI across the DI=2
##' threshold. This function inspects DI scores in a set and
##' recalculates those runs that have replicates crossing it, sticking
##' to the side with highest frequency or largest DI-2 separation.
##' @title Recalculate flipping DI scores
##' @return DI scores recalculated (numeric)
##' @author Torbjorn Lindahl
##' @param ... arguments to gamap(...)
##' @param group grouping of samples
##' @importFrom ga.utils subset_deep
##' @export
recalculate.di.in.set <- function( ... , group ) {

    din <- gamap( ... )

    if( length(din) != length(group) ) {
        stop( "The 'group' variable doesn't match the number of DIs in set" )
    }

    j <- is.na(din)
    b <- by( din[!j] > 2, group[!j], function(v) length(v) > 1 && sum(v) %between% c(1,length(v)-1) )

    if( !any(b) ) {
        return( din )
    }

    switchers <- names(b)[b]

    t2res <- within( gamap( ..., stop.at="t2res" ),
    {
        T2 <- T2 / t2.limit()
        Qres <- Qres / qres.limit()
    })

    din.re <- din

    for( n in switchers ) {
        i.pos <- group == n & !is.na(din) & din > 2
        i.neg <- group == n & !is.na(din) & din < 2
        n.pos <- sum( i.pos )
        n.neg <- sum( i.neg )

        recalculate.positive <- FALSE

        if( n.pos == n.neg ) {
            if( mean( din[ i.pos ], na.rm=TRUE )-2 < 2-mean( din[ i.neg ], na.rm=TRUE ) ) {
                recalculate.positive <- TRUE
            }
        } else if( n.pos < n.neg ) {
            recalculate.positive <- TRUE
        }

        if( recalculate.positive ) {
            input <- subset_deep( t2res, i.pos )
            di.re <- .compute.di.negative( input, allow.higher=TRUE )
            din.re[ i.pos ] <- di.re
        } else {
            input <- subset_deep( t2res, i.neg )
            di.re <- .compute.di.positive( input )
            din.re[ i.neg ] <- di.re
        }
    }

    return( din.re )

}
