##' List variables in data file
##'
##' Lists the variable names of the rdata file
##' @title list rdata variables
##' @param rdata.file RData file to load
##' @param ... further arguments passed to \code{ls}
##' @return variable names
##' @author Torbjørn Lindahl
##' @export
ls.rdata <- function( rdata.file, ... ) {

  e <- new.env()
  load( rdata.file, e )

  return( ls(e, ... ) )

}
