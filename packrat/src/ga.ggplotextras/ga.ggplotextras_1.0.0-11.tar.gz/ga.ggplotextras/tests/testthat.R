library(testthat)
library(ga.ggplotextras)

test_check("ga.ggplotextras")
