gamap.step.bg <- function( input, bg.limit=15, bg.corr=0 ){
    input[ input < bg.limit ] <- 0
    output <- input + bg.corr
    attr( output, "platform" ) <- attr( input, "platform" )
    return( output )
}
