library(ga.data)
library(testthat)

context("gamap.qc.ranges")

test_that( "it returns a list", {

    l.bc <- gamap.qc.ranges( "biocode" )
    expect_is( l.bc, "list" )

    l.lx <- gamap.qc.ranges( "lx200"   )
    expect_is( l.lx, "list" )

})

test_that( "overides can be set in options.", {

    qcr1 <- gamap.qc.ranges( "lx200" )
    qc1 <- qcr1$QCC30.total.signal

    ow <- options( GamapQcOverride = list( QCC30.total.signal = c(10, 20) ) )
    on.exit( options( GamapQcOverride = NULL ))

    expect_warning( qcr2 <- gamap.qc.ranges( "lx200" ) )
    qc2 <- qcr2$QCC30.total.signal

    expect_equal( qc2, c(10,20) )

    ## qcr3 <- gamap.qc.ranges( "lx200" )
    ## qc3 <- qcr3$QCC30.total.signal
    ## expect_equal( qc3, qc1 )

})
