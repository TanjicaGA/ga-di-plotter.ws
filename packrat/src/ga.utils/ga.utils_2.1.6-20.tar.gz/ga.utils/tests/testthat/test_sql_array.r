library(ga.utils)

context( "sql.array" )

test_that( "arrays are correct", {

    sa <- sql.array

    expect_equal( sa(1:3), "('1','2','3')" )
    expect_equal( sa(letters[1:3]), "('a','b','c')" )
    expect_equal( sa(c(1,"a",NA)), "('1','a','NA')" )

    ## lists also
    expect_equal( sa(list(1,"a",NA)), "('1','a','NA')" )
    expect_equal( sa(list(1,"a",NA,NULL)), "('1','a','NA','NULL')" )

});
