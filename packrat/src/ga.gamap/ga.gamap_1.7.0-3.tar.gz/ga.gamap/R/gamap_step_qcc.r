##' QCC30 adjustment step of the algorithm
##'
##' Identifies the QCC30 samples and divide by their median
##' @title QCC30 adjustment step of the algorithm
##' @param input typically hyb adjusted data
##' @param qcc.name name of the QCC30 samples, defaults to QCC30
##' @param qc.check.qcc30 filter QCC30 samples based on relevant QC
##'     criteria before claculating median profile
##' @param ignore.total.signal.criterion ignore the Total signal
##'     criterion before filtering QCC30 samples for calculating the
##'     median profile
##' @return matrix
##' @author Torbjørn Lindahl
##' @importFrom stats median
##' @importFrom ga.utils %between%
gamap.step.qcc <- function( input, qcc.name="QCC30", qc.check.qcc30=TRUE, ignore.total.signal.criterion=FALSE ){

    plate0 <- attr( input, "plate" )
    hyc0 <- attr( input, "HYC01" )
    uni0 <- attr( input, "UNI05" )
    ts.vector <- attr( input, "TotalSignal" )
    platform0 <- attr( input, "platform" )

    if( length(plate0) != nrow(input) )
      stop("Plate vector does not match data size")

    i.qcc30 <- grepl( paste0("^",qcc.name), rownames( input ) )

    if( !any( i.qcc30 ) ){
        stop(paste(qcc.name,"not found in file"))
    }

    qcc.data <- input[ i.qcc30, , drop=FALSE ]
    q.plate <- plate0[i.qcc30]
    q.platform <- platform0[i.qcc30]
    q.hyc <- hyc0[i.qcc30]
    q.uni <- uni0[i.qcc30]
    ts.30 <- ts.vector[i.qcc30]

    qcc.na <- apply( qcc.data, 1, function(v)sum(is.na(v)) )

    ## colmedians <- function( x, ... ){
    ##     return( apply( x, 2, median, ... ) )
    ## }

    qcc.per.plate <- array( NA, dim=c( length(unique(q.plate)), ncol(qcc.data) ) )
    up <- unique(q.plate)
    for( i in seq_along(up) ){

        i.q <- q.plate == up[i]
        plat.f <- q.platform[i.q][1]

        if( qc.check.qcc30 ) {

            qcr <- ga.gamapqc::gamap.qc.ranges( plat.f )

            i.q <- i.q &
                (q.hyc %between% qcr$QCC30.HYC01.range)
            i.q <- i.q & q.uni > qcr$QCC30.UNI05.lower
            if(!ignore.total.signal.criterion)
                i.q <- i.q & (ts.30 %between% qcr$QCC30.total.signal)
        }

        qcc.per.plate[i,] <- apply( qcc.data[i.q,,drop=FALSE], 2, median, na.rm=TRUE )

    }
    dimnames( qcc.per.plate ) <- list( up, colnames(qcc.data) )

    m <- match( paste(plate0), rownames(qcc.per.plate) )
    qcc.adjustment <- qcc.per.plate[ m, ]

    if( any(is.na(qcc.adjustment)) ){
        ## browser()
        ## warning( "Some plates miss QCC - all data will be NA for that plate" )
    }

    output <- input / qcc.adjustment

    output <- output * 1e3
    return( output )

}
