library(testthat)
library(ga.data)

test_check("ga.data")
