##' Merge two lists recursively
##'
##' Merges two lists recursively
##' @title Merge recursively
##' @param l1 List to be updated
##' @param l2 List to update from
##' @return First list updated with content from second list.
##' @author Torbjørn Lindahl
##' @export
merge_deep <- function( l1, l2 ) {

    for( n2 in names(l2) ) {

        if(!n2 %in% names(l1)) {
            l1[[n2]] <- l2[[n2]]
        }
        else {
            l1[[n2]] <- merge_deep( l1[[n2]], l2[[n2]] )
        }

    }

    return( l1 )

}
