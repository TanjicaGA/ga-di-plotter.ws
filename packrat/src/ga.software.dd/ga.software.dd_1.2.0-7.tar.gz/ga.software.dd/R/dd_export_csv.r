##' dd sw export operation
##'
##' Performs the data export of the GAmap DD SW, per specification, DI
##' score and bacteria table
##' @title export csv corresponding to DD SW operation
##' @param input.file lx200 file to process
##' @param kitlot kitlot to use
##' @param path path to write to, defaults to cwd. Set this to NA or
##'     NULL to avoid writing to disk.
##' @param overwrite default FALSE, don't overwrite existing files
##' @param exclude.qcc defaul TRUE, remove QCC samples from the
##'     results
##' @param include.qcc23.qcc33 include QCC23 and QCC33 in output (this
##'     over rules the exclude.qcc argument and is nice so that they
##'     can do their own troubleshooting)
##' @param version.to.use SW version string to put in the exported csv
##' @return data.frame written to disk
##' @author Torbjorn Lindahl
##' @importFrom ga.gamap gamap gamap.probe.levels rundate
##' @importFrom ga.gamapqc gamap.qc
##' @importFrom ga.utils truthy %!~% %~%
##' @importFrom ga.data probe.numbers
##' @importFrom stats na.omit
##' @importFrom utils write.table
##' @importFrom digest digest
##' @importFrom stringr str_pad
##' @export
dd.export.csv <- function( input.file, kitlot, path=".", overwrite=FALSE, exclude.qcc=TRUE, include.qcc23.qcc33=TRUE, version.to.use="1.0.0" ) {

    x <- gamap( input.file, stop.at="file" )
    din <- gamap( x, start.from="file", batch=kitlot, ignore.total.signal.criterion=TRUE )
    bt <- gamap.probe.levels( x, start.from="file", batch=kitlot, ignore.total.signal.criterion=TRUE, use.bacteria.names=FALSE )
    qc <- abundancy.table.qc( x, start.from="file", batch=kitlot, report.per.sample=TRUE )

    colnames(bt) <- probe.numbers(colnames(bt))

    d <- data.frame(
        Sample = x$Sample,
        DI = din,
        QC = qc,
        QCtext = .compile.qc.text(qc),
        bt,
        check.names=FALSE,
        row.names=NULL
    )

    ii <- rep( TRUE, nrow(d) )

    if( exclude.qcc ) {
        ii[ d$Sample %~% "^QCC" ] <- FALSE
    }

    if( include.qcc23.qcc33 ) {
        ii[ d$Sample %~% "^QCC(23|33)" ] <- TRUE
    }

    d <- d[ ii, ]

    if( !is.na(path) && truthy(path) ) {

        ## find a suitable filename from the input path
        if( dir.exists(path) ) {
            ## take filename from input arguments
            out.file <- basename( input.file )
            if( !grepl("\\.csv$",out.file, ignore.case=TRUE) ) {
                out.file <- sub( "\\.[^\\.]+$", ".csv", out.file )
            }
            if( !grepl("\\.csv$",out.file, ignore.case=TRUE) ) {
                out.file <- paste0( out.file, ".csv" )
            }
            out.file <- sub( "(?=\\.csv$)", "-dd-export", out.file, ignore.case=TRUE, perl=TRUE )
            path <- file.path( path, out.file )
        }

        if( file.exists( path ) && !overwrite ) {
            warning( "output file already exists, not overwriting unless overwrite=TRUE" )
        } else {

            if( file.exists( path ) ) {
                unlink( path )
            }

            con <- file( path, open="a+b" )
            on.exit( close(con) )

            header <- rbind(
                c("Filename", basename(input.file)),
                c("Rundate", paste(rundate(input.file))),
                c("Kitlot",kitlot),
                c("AppVersion", version.to.use)
            )

            write.table(
                file=con,
                x=header,
                col.names=FALSE,
                row.names=FALSE,
                sep=","
            )

            cat( "\n", file=con )

            write.table(
                file=con,
                x=d,
                col.names=TRUE,
                row.names=FALSE,
                sep=","
            )

            cat( "\n", file=con )

            ## get the CRC of the content written so far
            currently.at <- seek( con, where=0, origin="start" )
            content <- readChar( con=con, nchars=currently.at )

            crc32_sum <- toupper(
                str_pad( digest( content, algo="crc32" ), 8, pad="0" )
            )

            cat( "-- CRC --\n", file=con )
            cat( "CRC32: ", crc32_sum, "\n", file=con, sep="" )

            attr( d, "crc32" ) <- crc32_sum

        }

    }

    return( d )

}


##' @importFrom ga.utils trim
.compile.qc.text <- function( qc ) {

    qc.msgs <- as.character( attr( qc, "reason" ) )
    ## qc.nrs  <- as.character( attr( qc, "ErrorNumbers"  ) )

    sapply( 1:length( qc.msgs ), function(i) {

        elem <- ""
        ## qcnrs.i <- qc.nrs[[i]]
        qcmsgs.i <- qc.msgs[i]
        if( truthy( qcmsgs.i )) {
            ## elem <- paste( sapply( 1:length( qcnrs.i ), function(j) {
            ## sprintf( "Errors: %s", trim(qcmsgs.i[j]) )
            elem <- trim(qcmsgs.i)
            ## }), collapse="; ")
        }
        return( elem )
    })



}
