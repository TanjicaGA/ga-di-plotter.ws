##' read dd export
##'
##' Reads the file, extracting the csv matrix with the header and crc
##' sum as additional attributes.
##' @title read a file exported per the DD spec
##' @param filename file to read
##' @param require.crc.check default TRUE, check that the CRC checksum
##'     matches. If set to FALSE this check will still result in a
##'     warning if the checksum does not match.
##' @return data.frame with content
##' @author Torbjørn Lindahl
##' @importFrom readr read_file
##' @importFrom stringr str_match
##' @importFrom utils read.csv
##' @importFrom digest digest
##' @export
read.dd.export <- function( filename, require.crc.check=TRUE ) {

    content0 <- content <- read_file( filename )

    content <- gsub( "\r\n", "\n", content )

    i.begin <- regexpr('(?<=\\n\\n)"?Sample"?,', content, perl=TRUE )
    i.end <- regexpr( '(?<=\\n\\n)-- CRC --\n', content, perl=TRUE )-1

    con <- textConnection( substr(content, i.begin, i.end) )
    on.exit(close(con), add=TRUE)
    d.result <- read.csv( file=con, header=TRUE, check.names=FALSE )

    con2 <- textConnection( substr(content, 1, i.begin-1) )
    on.exit(close(con2), add=TRUE)
    d.header0 <- read.csv( file=con2, header=FALSE )

    d.header <- matrix( nrow=1, d.header0[,2] )
    colnames(d.header) <- d.header0[,1]
    d.header <- as.data.frame(d.header)

    crc32 <- str_match( content, "CRC32:\\s*(\\S+)" )[,2]

    attr( d.result, "header" ) <- d.header
    attr( d.result, "crc32" ) <- crc32

    if(!is.na(crc32)) {
        if(!(r <- .check.crc32( content0 ) )) {

            msg <- sprintf(
                "CRC32 error:\n - in file: %s\n - control: %s\n",
                attr( r, "FromContent" ), attr( r, "Calculated" )
            )

            if( require.crc.check ) {
                stop(msg)
            } else {
                warning(msg)
            }

        }
    }

    d.result

}

##' @importFrom digest digest
##' @importFrom stringi stri_locate_first_regex
##' @importFrom stringr  str_match
.check.crc32 <- function( content ) {

    m <- stri_locate_first_regex( content, "^-- CRC --$", multiline=TRUE )
    fc <- substr( content, 1, m[1]-1 )

    from.calc <- str_pad( toupper(digest( fc, algo="crc32", file=FALSE, serialize=FALSE )), 8, pad="0" )

    ## from.calc <- toupper(
    ##     str_pad( digest( content.i, algo="crc32", serialize=FALSE ), 8, pad="0" )
    ## )

    from.content <- str_match( content, "CRC32: (\\S+)" )[,2]

    r <- from.calc == from.content
    attr( r, "FromContent" ) <- from.content
    attr( r, "Calculated"  ) <- from.calc

    return( r )

}
