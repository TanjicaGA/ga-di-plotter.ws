library(ga.utils)

context( "Clamp" )

test_that( "numeric values are clamped", {

    expect_equal( clamp( c(0,100), c(10,20) ), c(10,20) )
    expect_equal( clamp( 1:20, 5:15 ), c(5,5,5,5,5,6:15,15,15,15,15,15) )

})

test_that( "text values", {

    expect_equal( clamp( LETTERS[1:6], c("A","C")), c("A","B","C","C","C","C") )

})
