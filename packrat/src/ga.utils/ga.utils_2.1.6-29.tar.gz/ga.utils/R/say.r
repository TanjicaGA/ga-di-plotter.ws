##' \code{\link{cat}} with implicit newline
##'
##' Uses \code{cat} to print arguments to screen and appends a newline.
##'
##' If more than one value, they are separated by newline. \code{sayf}
##' treats the first argument as a pattern and uses sprintf to fill in
##' placeholders as described for \code{sprintf}.
##' @title \code{cat} with newline
##' @param ... Arguments are forwarded to \code{cat}
##' @return No return
##' @author Torbjørn Lindahl
##' @export
say <- function(...){
  cat( paste( ..., collapse="\n" ), "\n" )
}

##' @rdname say
##' @export
sayf <- function(...)say(sprintf(...))
