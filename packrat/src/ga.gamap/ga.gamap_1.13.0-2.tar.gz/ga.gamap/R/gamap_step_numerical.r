##' GAmap step numerical
##'
##' Calculates the numerical DI from the input of the previous step
##' @title Numerical DI
##' @param input di result, coming from the previous step
##' @param report.in.greyzone Deprecated. Logical, should values in
##'     greyzone be reported.
##' @return vector with numerical di
##' @author Torbjørn Lindahl
##' @importFrom ga.utils "%between%"
##'
gamap.step.numerical <- function( input, report.in.greyzone ){

    t2 <- attr( input, "T2") / t2.limit()
    qres <- attr( input, "Qres") / qres.limit()

    if( is.null(names(input)) ) {
        di.names <- paste("Sample",seq_along(t2))
    }
    else {
        di.names <- names(input)
    }

    input <- data.frame(
      T2=t2,
      Qres=qres,
      Sample=di.names,
      row.names=NULL
      )

    i.pos <- input$T2 >= 1 | input$Qres >= 1
    i.neg <- !i.pos
    di <- rep( NA, nrow(input) )
    names(di) <- di.names

    parameters <- ga.data::numeric.di.parameters()

    greyzone.upper <- parameters[["greyzone.upper"]]
    greyzone.lower <- parameters[["greyzone.lower"]]

    i.pos[ is.na(i.pos) ] <- FALSE
    i.neg[ is.na(i.neg) ] <- FALSE

    if( any(i.pos) )
      di[i.pos] <- .compute.di.positive( input[i.pos,] )
    if( any(i.neg) )
      di[i.neg] <- .compute.di.negative( input[i.neg,] )

    if( !missing(report.in.greyzone) ) {
        warning("algorithm always reports in greyzone, update your code")
    }

    ## if( ! report.in.greyzone )
    ##   di[  di %between% c(greyzone.lower, greyzone.upper)  ] <- NA

    return( di )

}

##' @importFrom stats plnorm
.compute.di.positive <- function(input.pos) {

    t2 <- input.pos$T2
    qres <- input.pos$Qres

    di.scale.dysbiosis.base <- 2

    parameters <- ga.data::numeric.di.parameters()

    di.3 <- parameters$di.3
    di.4 <- parameters$di.4

    t2.f <- parameters$t2.weight
    qres.f <- parameters$qres.weight

    logm <- parameters$meanlog
    logs <- parameters$sdlog

    di.2 <- min( sqrt( t2.f ), sqrt( qres.f ) )
    break.points <- c( di.2, di.3, di.4, Inf )

    mdi.i <- sqrt( t2.f*t2**2 + qres.f*qres**2 )

    ## Calculate floating point number as delta p of interval p

    ## Fint the lower nearest integer DI
    int.lower <- sapply( mdi.i, function(m) { ga.utils::first( break.points >= m ) - 1 } )
    int.lower[ mdi.i == di.2 ] <- 1

    if( any(int.lower < 1 ) )
      stop("some int.lower < 1")

    ## The upper nearest integer DI
    int.upper <- int.lower+1

    ## P-values at the breakpoints
    p.breaks <- plnorm( q=break.points, meanlog=logm, sdlog=logs )

    ## P-values at the lower nearest int
    p.lower <- p.breaks[int.lower]
    ## P-values at the upper nearest int
    p.upper <- p.breaks[int.upper]

    if( length(mdi.i) != length(p.lower) ) {
        stop("mdi should be same length as p.lower")
    }

    ## P-values at the samples
    p.mdi.i <- plnorm( mdi.i, meanlog=logm, sdlog=logs ) - p.lower

    ## Delta P in the integer ranges
    delta.p <- p.upper - p.lower

    din.0 <- int.lower-1 + p.mdi.i / delta.p

    din <- di.scale.dysbiosis.base + din.0
    names(din) <- input.pos$Sample

    return( din )

}

##' @importFrom stats plnorm
##' @importFrom stats na.omit
.compute.di.negative <- function(input.neg, allow.higher=FALSE) {

    t2 <- input.neg$T2
    qres <- input.neg$Qres

    parameters <- ga.data::numeric.di.parameters()

    logm <- parameters$meanlog
    logs <- parameters$sdlog

    di.scale.negative.base <- 0

    mdi.i <- sqrt( 1*t2**2 + 1*qres**2 )

    break.points <- c( 0, sqrt(2)/2, sqrt(2) )

    ## Calculate floating point number as delta p of interval p
    int.lower <- sapply( mdi.i, function(m) { ga.utils::first( break.points >= m ) - 1 } )
    if( allow.higher )
        int.lower[ mdi.i > break.points[3]  ] <- 2
    int.lower[ mdi.i == break.points[1] ] <- 1

    if( any(na.omit(int.lower) < 1 %in% TRUE ) )
      stop("some int.lower < 1")

    int.upper <- int.lower+1


    p.breaks <- plnorm( q=break.points, meanlog=logm, sdlog=logs )

    p.lower <- p.breaks[int.lower]
    p.upper <- p.breaks[int.upper]

    p.mdi.i <- plnorm( mdi.i, meanlog=logm, sdlog=logs ) - p.lower
    delta.p <- p.upper - p.lower

    din.0 <- int.lower-1 + p.mdi.i / delta.p


    if( any(is.na(din.0) ))
      return(.Machine$integer.max)

    base <- di.scale.negative.base
    din <- base + din.0
    names(din) <- input.neg$Sample

    return( din )

}
