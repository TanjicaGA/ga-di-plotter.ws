##' fetches a specified dataset from a csv result file
##'
##' This function fetches a data section from a scv file. It detects
##' source platform automatically, currently supports Lx200 and
##' Biocode.
##'
##' For Lx200 files probes missing from the full IBS3.0 profile are
##' inserted as NAs
##' @title process csvfile
##' @param csv.file file to process
##' @param section section to fetch, eg Median, Count, etc..
##' @param raw return the raw data as read from the file
##' @return data from csv matrix aligned in a data frame
##' @export
##' @author Torbjørn Lindahl
process.csvfile <- function(csv.file,section,raw=FALSE) {

    platform <- detect.platform(readLines(csv.file, n=20))

    if( is.null(platform) ) {
        stop( paste("Failed detecting platform of", csv.file ))
    }
    else if( platform == "biocode" ) {
        d <- process.biocode(csv.file,section=section,raw=raw)
    }
    else if( platform == "lx200" ) {
        d <- process.lx200(csv.file,section=section,raw=raw)
    }
    else if( platform == "magpix" ) {
        d <- process.lx200(csv.file,section=section,raw=raw)
        d$Platform <- "magpix"
    }
    else {
        stop("Cannot process platform ", platform )
    }

    return( d )

}

##' @importFrom ga.biocode read.biocode
process.biocode <- function(biocode.file,section,raw=FALSE) {

    l <- read.biocode(biocode.file)

    if( raw )
        return( l[[section]] )

    d <- cbind.data.frame(
        File=basename(biocode.file),
        Platform="biocode",
        ## Rundate=l$header$Date,
        l[[section]],
        stringsAsFactors=FALSE
    )
    colnames(d) <- translate.probe.names(colnames(d))

    harmonize.platform(d, platform="biocode")

}

##' @importFrom ga.luminex read.luminex
##' @importFrom ga.data probe.re
process.lx200 <- function(lx200.file,section,raw=FALSE) {

    l <- read.luminex(lx200.file, require.crc.check=FALSE)
    x <- l[[section]]

    if( raw )
        return( x )

    ## fix case, it has been seen to be camel case
    j <- grepl( probe.re(TRUE), colnames(x), ignore.case=TRUE )
    n <- colnames(x)
    n[j] <- toupper( n[j] )
    colnames(x) <- n

    d <- cbind.data.frame(
        File=basename(lx200.file),
        Platform="lx200",
        ## Rundate=l$header$Date,
        x,
        stringsAsFactors=FALSE
    )

    ## harmonize.platform(d, platform="lx200", set.to=ifelse( section == "Count", 0, NA ) )
    harmonize.platform(d, platform="lx200", set.to=NA )

}

##' @importFrom foreach foreach
##' @importFrom foreach "%do%"
process.csvfiles <- function( csv.files, section ) {

    i <- NULL # otherwise check() complains
    d2 <- foreach( i=seq_along(csv.files), .combine=rbind.data.frame ) %do% {
        d <- process.csvfile(csv.files[i],section)
        d$Plate <- i
        d
    }

    d2$Plate <- as.factor( d2$Plate )

    d2

}
