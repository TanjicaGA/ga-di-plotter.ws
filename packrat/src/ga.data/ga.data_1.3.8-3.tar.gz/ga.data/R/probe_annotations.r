##' look up bactera names for probes
##'
##' Gets the current bacteria name or entry in the taxonomic tree for
##' given probes
##' @title look up bacteria names for probes
##' @param x probe names to look up (AG/IG code)
##' @return corresponding bacteria names for x
##' @author Torbjørn Lindahl
##' @importFrom ga.utils look.up
##' @export
bacteria.names <- function(x) {
    return( look.up( x, probe.annotations, to="BacteriaName", leave.unfound=FALSE ) )
}

##' look up probe numbers for probes
##'
##' Gets the current probe numbers for given probes
##' @title look up probe numbers for probes
##' @param x probe names to look up (AG/IG code)
##' @return corresponding probe numbers for x
##' @author Torbjørn Lindahl
##' @importFrom ga.utils look.up
##' @export
probe.numbers <- function(x) {
   return( look.up( x, probe.annotations, to="ProbeNumber", leave.unfound=FALSE ) )
}

##' Probe codes from probe numbers
##'
##' Gets the probe code from probe identifiers, typically probe numbers
##' @title probe codes from probe identifiers
##' @param x probe identifiers to look up
##' @return probe codes
##' @author Torbjørn Lindahl
##' @export
probe.codes <- function(x) {
    return( look.up( x, probe.annotations, to="Probe", leave.unfound=FALSE ) )
}
