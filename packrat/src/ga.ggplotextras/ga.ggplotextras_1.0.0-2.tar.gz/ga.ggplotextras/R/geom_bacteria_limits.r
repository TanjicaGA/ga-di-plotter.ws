##' Add bacteria threshold lines
##'
##' Adds bacteria limit lines for a given probe
##' @title geom.bacteria.limits
##' @return geom_abline object to chain with a call to ggplot
##' @author Torbjørn Lindahl
##' @param probe probe to add bacteria limit lines of.
##' @param direction along which axes to add the lines.
##' @param style what style of plot to add to. Defaults to ggplot,
##'     meaning a geom_* object will be returned for chaining.
##' @param bact.args arguments to call to bacteria.limits
##' @param ... extra arguments to the geom function
##'     after batchadjustment, not the centering step.
##' @importFrom ggplot2 geom_blank
##' @importFrom ggplot2 geom_hline
##' @importFrom ggplot2 geom_vline
##' @importFrom ga.utils tint.color %!in%
##' @importFrom ga.data bacteria.limits
##' @export
geom.bacteria.limits <- function( probe, direction=c("horizontal","vertical","both"),
                                 style=c("ggplot","basic"), bact.args=list(), ... ) {

    style <- match.arg( style )
    direction <- match.arg( direction )

    if( "before.center" %!in% names(bact.args) ) {
        bact.args$before.center <- TRUE
    }
    bl0 <- do.call( bacteria.limits, bact.args )

    if( probe %!in% bl0$Probe ) {
        warning( paste( probe, "not found among probes in the bacteria table") )
    }

    bl <- bl0[ bl0$Probe == probe, ]

    nn <- c(
        paste0(    -3:-1),
        paste0("+", 1: 3)
    )

    ll <- unlist(bl[,nn])

    col0 <- c( "red", "orange", "green" )

    colors <- c(
        tint.color( col0, -.3 ),
        rev(col0)
    )
    names(colors) <- nn

    if( style == "ggplot" ) {

        l <- list()

        if( direction %in% c("horizontal","both") ) {
            l[[length(l)+1]] <- geom_hline( yintercept = ll, color=as.list(colors), ... )
        }
        if( direction %in% c("vertical","both") ) {
            l[[length(l)+1]] <- geom_vline( xintercept = ll, color=as.list(colors), ... )
        }

        if( length(l) == 1 )
            return( l[[1]] )
        else
            return(l)

    }
    else if( style == "basic" ) {

        ## if( direction ==

    }

}
