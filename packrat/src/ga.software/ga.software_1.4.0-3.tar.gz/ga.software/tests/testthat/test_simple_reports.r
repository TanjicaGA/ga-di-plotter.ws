library(testthat)
library(ga.software)
library(ga.utils)
library(XML)

context( "simple report - initiation" )

tf <- "./data/lx200/AID190731 L1907 Lx1734 LF.csv"

test_that( "initiating works", {

    l <- ga.software:::initiate.report.xml(
                           filename = "AID190731 L1907 Lx1734 LF",
                           analysisdate = "2019-02-08 10:02:00",
                           appVersion = "4.0.0.0"
                       )

    expect_is( l, "XMLNode" )

    v <- sapply( xpathApply( l, "/report/*" ), function(e)e$name )
    expect_setequal( v, c("version","reportinfo","plate_error","samples") )

})

test_that( "sample records works", {

    di.plate <- gamap( tf, stop.at="file" )
    din <- gamap( tf, batch="L1907" )
    bt <- gamap.probe.levels( tf, batch="L1907", bacteria.table.revision="rev3" )

    sample.node <- ga.software:::generate.sample.xml(
                                     plate.data.row = di.plate[ 9, ],
                                     bacteria.table.row = bt[ 9, , drop=FALSE],
                                     di = din[9]
                                 )

    expect_true( truthy(sample.node) )

})

test_that( "complete sample report works", {

    rep <- ga.software:::create.simple.report(
                             tf, batch="L1907",
                             appVersion = "4.0.0.0"
                         )

    expect_true( truthy(rep) )

})

test_that( "process multiple works", {

    dir.create( d <- tempfile() )

    r <- gamap.simple.report(
        dir( "data/lx200", full.names=TRUE ), save.where=d,
        appVersion = "4.0.0.0"
    )

    expect_true( r )

    system2( "tree", d )

})
