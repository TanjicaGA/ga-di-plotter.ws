library(testthat)
library(ga.software.dd)
library(stringr)

context( "read dd exports" )

tf1 <- "data/lx200-files-exports/TestFile-01-dd-export.csv"

test_that( "dd exports can be read", {

    d <- read.dd.export( tf1, require.crc.check=TRUE )
    expect_is( d, "data.frame" )
    extra.names <- c("Sample","QC","QCtext")

    expect_true( all( extra.names %in% names(d) ) )
    expect_true( all( setdiff( names(d), extra.names ) %~% "^[AI]G\\d{4}$" ) )
    expect_match( attr( d, "crc32" ), regex("^[0-9A-F]{,8}$", ignore_case=TRUE ) )

})
