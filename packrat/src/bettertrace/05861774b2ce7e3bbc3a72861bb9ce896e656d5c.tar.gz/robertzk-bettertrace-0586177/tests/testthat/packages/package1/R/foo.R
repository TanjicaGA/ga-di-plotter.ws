foo <- function(x) {
  if (missing(x)) {
    cat("one")
  } else {
    squawk()
  }
}

