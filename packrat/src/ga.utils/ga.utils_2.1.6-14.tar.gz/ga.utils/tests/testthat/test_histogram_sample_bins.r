library(ga.utils)

context( "well behaved data" )

test_that( "plain data works", {

    x <- 1:9
    h <- hist( x, breaks=c(0, 3.5, 6.5, 10), plot=FALSE )

    expect_equal( histogram_sample_bins(h), rep(1:3,each=3) )
    expect_equal( histogram_sample_bins(h,x), rep(1:3,each=3) )

})
