library(ga.utils)

context( "coalesce" )

test_that( "normal usage works", {

    expect_null( coalesce( NULL, NULL ) )
    expect_null( coalesce() )

    expect_equal( coalesce( NULL, 2 ), 2 )
    expect_equal( coalesce( 2, 3 ), 2 )

    expect_null( coalesce( NULL, numeric() ) )
    expect_equal( coalesce( numeric(), 3, 2 ), 3 )

})

test_that( "NA is handled", {

    expect_equal( coalesce( NA, NULL ), NA )
    expect_equal( coalesce( NA, 2 ), NA )
    expect_equal( coalesce( accept.na=FALSE, NA, 2 ), 2 )

})
