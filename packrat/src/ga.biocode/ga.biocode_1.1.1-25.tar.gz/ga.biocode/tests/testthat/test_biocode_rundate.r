library(ga.biocode)

context( "Rundates" )

file1 <- "data/TestFile1.csv"
file3 <- "data/TestFile3.csv"

test_that( "one file works", {

    d1 <- biocode.rundate( file1 )

    expect_equal(
        d1,
        as.POSIXct("2014-10-09 11:24:00")
    )

})

test_that( "two files work", {

    d1.3 <- biocode.rundate( c(file1,file3) )

    expect_equal(
        d1.3,
        c( as.POSIXct("2014-10-09 11:24:00"), as.POSIXct("2014-06-18 11:20:00") )
    )

})
