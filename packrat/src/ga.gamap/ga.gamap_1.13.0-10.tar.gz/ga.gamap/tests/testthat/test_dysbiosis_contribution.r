library(digest)
library(ga.gamap)
library(ga.utils)

context( "dysbiosis contribution" )

lx200.file <- file.path( "data", "Lx200-TestfileC.csv" )

test_that( "dysbiosis contribution is claculated properly", {

    di.plate <- gamap( lx200.file, stop.at="file" )
    pe <- dysbiosis.contribution( lx200.file, batch="PS1801L" )

    expect_equal( dim(pe), c( nrow(di.plate), 54 ) )

    pe.ref <- load.get( file.path("data", "Lx200-TestfileC_pe.RData" ), verbose=FALSE )

    expect_equivalent( pe, pe.ref )

})

test_that( "ploting it does something that is different from that which plot.default does", {

    pe <- dysbiosis.contribution( lx200.file, batch="PS1801L" )

    ref.png <- tempfile( fileext=".png")
    png( ref.png )
    plot.default( 1:10 )
    dev.off()

    check.png <- tempfile( fileext=".png" )
    png( check.png )
    plot.default( 1:10 )
    dev.off()

    this.png <- tempfile( fileext=".png")
    png( this.png )
    plot( pe )
    dev.off()

    expect_true( digest(file=ref.png) == digest(file=check.png) )
    expect_false( digest(file=ref.png) == digest(file=this.png) )

})
