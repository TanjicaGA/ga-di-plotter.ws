##' Strip duplicated names in data.frames (or lists)
##'
##' Checks duplicated names for identical contents and removes columns
##' if found
##' @title removes duplicate columns in a data frame
##' @return data.frame with duplicated columns removed
##' @author Torbjorn Lindahl
##' @param x input argument with names to compare
##' @param stop.if.not.possible logical, throw an error if identical
##'     names are found to have different content
##' @export
uniquify.names <- function(x, stop.if.not.possible=TRUE) {

    i <- duplicated( colnames(x) )
    if(!any(i))
        return(x)

    dup.names <- unique( colnames(x)[i] )

    bad.names <- character()

    my.identical <- function( x, y, ... ) {
        if( is.factor(x) )
            x <- paste(x)
        if( is.factor(y) )
            y <- paste(y)
        return( identical( x, y, ... )  )
    }

    for( n in dup.names ) {
        ii <- which( colnames(x) %in% n )
        ## check if each name is identical to the previous occurance of that name in x
        v <- sapply( seq_along(ii)[-1], function(j) { my.identical( x[, ii[j]], x[, ii[j-1]] ) } )
        ## if so, we keep only the first occurance
        if( all(v) ) {
            x <- x[, -ii[-1], drop=FALSE ]
        } else {
            bad.names <- append( bad.names, n )
        }
    }

    if( stop.if.not.possible && length(bad.names) ) {
        stop( "The following duplicated names were found to have different contents: ", paste(bad.names) )
    }

    return( x )

}
