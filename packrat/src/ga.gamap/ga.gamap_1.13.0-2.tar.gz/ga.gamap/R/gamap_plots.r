##' T2/Qres plot
##'
##' Plots dysbiosis results as a T2/Qres plot. This function is
##' intended to be flexible and perhaps not for everyday use (although
##' will have reasonable defaults). Other specialized plots typically
##' use this function.
##' @title Plot T2/Qres
##' @param di dysbiosis results, "dysbiosis" or "negative" with T2 and
##'     Qres attributes
##' @param add logical default FALSE, add to existing plot
##' @param type see plot.default
##' @param show.labels show sample names
##' @param labels sample names to show, defaults to those found as
##'     names on input
##' @param subset subset of data to plot
##' @param unit.scale transform to unit scale
##' @param show.box add the dysbiosis threshold box
##' @param skip.qcc dont plot any QCC samples
##' @param skip.qcc30 dont plot QCC30 samples
##' @param col color to use for normal samples
##' @param autoscale decide reasonable plot limits
##' @param xlim see plot.default
##' @param ylim see plot.default
##' @param pch see plot.default
##' @param cex see plot.default
##' @param sample.prefix text label to prefix samples with
##' @param sample.postfix text label to postfix samples with
##' @param main see plot.default
##' @param ... other arguments for \code{plot}
##' @return no return
##' @author Torbjørn Lindahl
##' @importFrom ga.data t2.limit qres.limit
##' @importFrom graphics lines
##' @export
plot_dysbiotic_indicator <- function( di, add=FALSE, type,
                                     show.labels=TRUE, labels, subset,
                                     unit.scale=TRUE,
                                     show.box=TRUE,
                                     skip.qcc=FALSE,
                                     skip.qcc30=TRUE,
                                     col="black",
                                     autoscale=FALSE,
                                     xlim, ylim,
                                     pch=1, cex=1,
                                     sample.prefix,
                                     sample.postfix,
                                     main="Dysbiotic Indicator", ... ){

    args <- list(...)

    if( missing(type) )
      type <- "n"

    if( length(col) > 1 && length(col) != length(di) )
      stop( "Length of colors doesn't match number of DI values")

    t2 <- attr( di, "T2" )
    q.res <- attr( di, "Qres" )

    if( missing(subset) ){
        subset <- rep( TRUE, length(di) )
    }

    if( skip.qcc ){

        if( any( !grepl("QCC",names(di)) ) ) {
            subset[ grepl("QCC",names(di)) ] <- FALSE
        }
        else {
            warning( "No non-QCC samples found, overriding skip.qcc" )
        }
    }

    if( skip.qcc30 ){
        subset[ grepl("QCC30",names(di)) ] <- FALSE
    }

    if( missing( xlim ) )
      xlim <- range(t2[subset], na.rm=TRUE )
    if( missing( ylim ) )
      ylim <- range(q.res[subset], na.rm=TRUE )


    if( length(col) == length(di) ){
        col <- col[subset]
    }

    t2 <- t2[subset]
    q.res <- q.res[subset]
    di <- di[subset]

    t.l <- t2.limit()
    q.l <- qres.limit()

    if( autoscale ) {
        xr <- range( t2, na.rm=TRUE )
        yr <- range( q.res, na.rm=TRUE )

        if( xr[2] < 300 )
          xr[2] <- 300

        if( yr[2] < 1e6 )
          yr[2] <- 1e6

        ## yr[2] <- 1.5*yr[2]
        ## xr[2] <- 1.5*xr[2]

        ## if( xr[2] < t.l )
        ##   xr[2] <- t.l*3
        ## if( yr[2] < q.l )
        ##   yr[2] <- q.l*3

        ## xr[2] <- max( xr[2], t.l*3 )
        ## yr[2] <- max( yr[2], q.l*3 )

        ## if( xr[2] > 5*t.l )
        ##   xr[2] <- min( 3*t.l, quantile( t2, probs=.9 ) )

        ## if( yr[2] > 5*q.l )
        ##   yr[2] <- min( 3*q.l, quantile( q.res, probs=.9 ) )

        if( !is.null(args$log) && grepl( "x", args$log ) )
          xr[1] <- min( 2, xr[1] )
        else xr[1] <- 0

        if( !is.null(args$log) && grepl( "y", args$log ) )
          yr[1] <- min( 3e3, yr[1] )
        else yr[1] <- 0

        xlim <- xr
        ylim <- yr

    }

    if( unit.scale ){
        t2 <- t2 / t.l[1]
        q.res <- q.res / q.l[1]

        xlim <- xlim / t.l[1]
        ylim <- ylim / q.l[1]

        t.l <- t.l / t.l[1]
        q.l <- q.l / q.l[1]

    }



    if( !add ){
        plot( t2, q.res, xlim=xlim, ylim=ylim, type="n", col=col,
             xlab="T2", ylab="Q residuals", main=main, ... )

        l.x <- c( xlim[1], t.l[1], t.l[1] )
        l.y <- c( q.l[1], q.l[1], ylim[1] )
    }


    if( show.labels && type == "n" &&
       (!missing(labels) || !is.null(names(di))) ){

        if( missing( labels ) )
            labels <- names(di) ## di is already subset'ed
        else
            labels <- labels[subset]

        ## sample prefix
        if( !missing(sample.prefix) ) {
            labels <- paste0( sample.prefix[1], labels )
        }
        if( !missing(sample.postfix) ) {
            labels <- paste0( labels, sample.postfix[1] )
        }        
        
        text( t2, q.res, labels, col=col, cex=cex )

    }
    else {
        points( t2, q.res, cex=cex, col=col, pch=pch, type=type )
    }

    if(!add && show.box){
        lines( l.x, l.y, col="darkgray", lty="dashed", lwd=2 )
    }
}

##' Standardized di plot, hard codes several parameters
##'
##' Implements standard DI plots in use at GA
##' @title Standard di.plot
##' @param di dysbiosis input, see \link{plot_dysbiotic_indicator}
##' @param log log argument to plot, default "xy"
##' @param unit.scale transform to unit scale
##' @param base.col color for samples default black
##' @param pos.ctrl.col color for pos control, default red
##' @param neg.ctrl.col color for pos control, default green
##' @param skip.ctrl exclude all QCC samples
##' @param add add to existing plot
##' @param xlim xlim
##' @param add.di.scale add limits for DI values 2, 4, 5
##' @param di.scale.col colors of DI scale, default blue
##' @param subset subset to plot
##' @param show.box show class threshold
##' @param type see plot.default
##' @param col color, takes precedence over other
##' @param ylim ylim
##' @param ... other arguments passed to plot
##' @return no return
##' @author Torbjørn Lindahl
##' @export di.plot
di.plot <- function( di, log="xy", unit.scale=TRUE,
                    base.col="black",
                    pos.ctrl.col="red", neg.ctrl.col="green",
                    skip.ctrl=FALSE,
                    add=FALSE,
                    xlim=c(1,300), add.di.scale=!add, subset,
                    show.box=!add,
                    di.scale.col = "blue",
                    type="n", col, ylim=c(2e3,5e5), ... ) {

    if( missing(subset) )
        subset <- rep( TRUE, length(di) )

    i.qcc <- grepl( "QCC", names(di) )
    i.qcc23 <- grepl( "QCC23", names(di) )
    i.qcc33 <- grepl( "QCC33", names(di) )
    i.qccX3 <- i.qcc23 | i.qcc33

    i.ok <- i.qccX3 & i.qcc | !i.qcc

    if(missing(col)) {
        if(length(base.col) == 1 )
            col <- rep( base.col, length(di) )
        else
            col <- base.col
        col[ i.qcc23 ] <- pos.ctrl.col
        col[ i.qcc33 ] <- neg.ctrl.col
   }

    ## i.ok <- i.ok & subset
    i.ok <- subset

    plot_dysbiotic_indicator( di, log=log,
                             xlim=xlim, ylim=ylim, add=add,
                             subset=i.ok, col=col, type=type,
                             show.box=show.box,
                             unit.scale=unit.scale, ... )

    if( add.di.scale )
        add.dysbiosis.scale(unit.scale=unit.scale, col=di.scale.col)

    ## if( any(i.qccX3) && !skip.ctrl ) {
    ##     plot.dysbiotic.indicator( di, add=TRUE, subset=i.qccX3, type=type, skip.qcc=FALSE, col=col,
    ##                              xlim=xlim, ylim=ylim,
    ##                              unit.scale=unit.scale, ... )
    ## }

}

##' An empty di plot
##'
##' An empty di plot, useful for custom representations when the other
##' di plot functions are not flexible enough
##' @title empty di plot
##' @param xlim xlim
##' @param ylim ylim
##' @param main main
##' @param log default "xy"
##' @param unit.scale default TRUE
##' @param add.di.threshold add lines showing dysbiosis class threshold
##' @param add.di.scale add numbers and ellipses showing DI levels
##' @param ... other arguments to \code{plot}
##' @return no return
##' @author Torbjørn Lindahl
##' @export
di.plot.empty <- function(
                          xlim=c(1,300),
                          ylim=c(2e3,5e5),
                          main="Dysbiotic Indicator",
                          log="xy",
                          unit.scale=TRUE,
                          add.di.threshold=TRUE,
                          add.di.scale=TRUE,
                          ...
                          ) {
    if( unit.scale ) {
        xlim <- xlim / t2.limit()
        ylim <- ylim / qres.limit()
    }
    plot( 1, type="n", xlim=xlim, ylim=ylim, main=main, log=log, ... )
    if( add.di.threshold )
        add.dysbiosis.thresholds(unit.scale=unit.scale)
    if( add.di.scale )
        add.dysbiosis.scale(unit.scale=unit.scale)
}
