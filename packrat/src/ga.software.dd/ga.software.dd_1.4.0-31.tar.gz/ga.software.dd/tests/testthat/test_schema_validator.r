library(testthat)
library(ga.software.dd)

context( "validate qccDict json schema" )

test_that( "correct qccDict json gets validated", {

    expect_true( validate.qccdict.json( "data/bact-table/qccDict.json" ) )

    expect_false( validate.qccdict.json( "data/bact-table/bad-json/qccDict-bad-kitlot.json" ) )
    expect_false( validate.qccdict.json( "data/bact-table/bad-json/qccDict-missing-set.json" ) )

})
