library(ga.software)

context("read sample register")

test_that( "read ge variant", {

    sr.file <- "data/IBS07-1504_Sample_Register.xlsx"
    d <- read.sample.register( sr.file, "TestFile1", "SU0622", variant="GE" )

    expect_gte( nrow(d), 1 )

    expect_equal( d$Patient.first.name, "Ola Kari")
    expect_equal( d$Patient.last.name, "Nordmann")

})
