##' Plot A4 landscape
##'
##' Sets up a A4 pdf landscape device
##' @title Plot to landscape A4
##' @param x filename
##' @param ... other arguments except
##' @return no return
##' @author Torbjørn Lindahl
##' @importFrom grDevices pdf
##' @export
pdf.a4.landscape <- function(x,...)pdf(x, width=11.69, height=8.27, ... )

##' @rdname pdf.a4.landscape
##' @importFrom grDevices pdf
##' @export
pdf.a4 <- function(x,...)pdf(x, width=8.27, height=11.69, ... )
