library(ga.gamap)

context( "platform auto detect" )

test_that( "platform is detected correctly", {

    expect_equal( detect.platform(readLines("data/Lx200-TestfileA.csv")), "lx200" )
    expect_equal( detect.platform(readLines("data/Lx200-TestfileB.csv")), "lx200" )
    expect_equal( detect.platform(readLines("data/Biocode-TestFileA.csv")), "biocode" )
    expect_equal( detect.platform(readLines("data/LUM05-03-1601.csv")), "magpix" )

})

test_that( "platfrom is detected correctly by file interface", {

    expect_equivalent( detect.platform.from.file("data/Lx200-TestfileA.csv"), "lx200" )
    expect_equivalent( detect.platform.from.file("data/Lx200-TestfileB.csv"), "lx200" )
    expect_equivalent( detect.platform.from.file("data/Biocode-TestFileA.csv"), "biocode" )
    expect_equivalent( detect.platform.from.file("data/LUM05-03-1601.csv"), "magpix" )

    expect_equal(
        detect.platform.from.file(
            c("data/Lx200-TestfileA.csv","data/Lx200-TestfileB.csv","data/Biocode-TestFileA.csv","data/LUM05-03-1601.csv")
        ),
        c(
            "data/Lx200-TestfileA.csv"="lx200",
            "data/Lx200-TestfileB.csv"="lx200",
            "data/Biocode-TestFileA.csv"="biocode",
            "data/LUM05-03-1601.csv"="magpix"
        )
    )

})
