library(ga.utils)

context( "Merge deep" )

test_that( "different names work", {

    l1 <- list( "foo"="bar" )
    l2 <- list( "bar"="baz" )

    ll <- merge_deep( l1, l2 )

    expect_equal( ll, list( "foo"="bar", "bar"="baz" ) )

})

test_that( "coliding names work", {

    l1 <- list( "foo"="bar", "bar"="mine" )
    l2 <- list( "foo"="SHOULDNT END UP", "bar"="baz" )

    ll <- merge_deep( l1, l2 )

    expect_equal( ll, list( "foo"="bar", "bar"="mine" ) )

})

test_that( "deeper structures work", {

    l1 <- list( "foo"=list("bar"="baz") )
    l2 <- list( "foo"=list("test"="1234"), "bar"="TOPLEVEL" )

    ll <- merge_deep( l1, l2 )

    expect_equal( ll, list( "foo"=list("bar"="baz","test"="1234"), "bar"="TOPLEVEL" ) )

})

test_that( "old unnamed values are preserved", {

    l1 <- list( "foo"=list("bar"="baz"), 1:5 )
    l2 <- list( "foo"=list("test"="1234"), "bar"="TOPLEVEL" )

    ll <- merge_deep( l1, l2 )

    expect_equal( ll, list( "foo"=list("bar"="baz","test"="1234"), 1:5, "bar"="TOPLEVEL" ) )

})

test_that( "new unnamed values are skipped", {

    l1 <- list( "foo"=list("bar"="baz"), 1:5 )
    l2 <- list( "foo"=list("test"="1234"), "bar"="TOPLEVEL", 6:10 )

    ll <- merge_deep( l1, l2 )

    expect_equal( ll, list( "foo"=list("bar"="baz","test"="1234"), 1:5, "bar"="TOPLEVEL" ) )

})
