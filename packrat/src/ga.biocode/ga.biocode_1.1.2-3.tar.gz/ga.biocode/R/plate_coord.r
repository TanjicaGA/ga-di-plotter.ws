##' parse plate coordinates
##'
##' parses plate coordinates of the form A1, D3 etc. Also converts
##' back from a number to a plate coord.
##' @title parses plate coordinates
##' @param input vector of numbres or coordinates
##' @return numbers or plate coordinates
##' @author Torbjørn Lindahl
##' @export
plate.coord <- function( input ){

  output <- NULL

  n.let <- 8
  ##ncol <- 12

  for( elm in input ){

    o <- NA

    if(!is.na(elm)){

      l <- gsub( "\\d", "", elm )
      d <- as.integer( gsub( "\\D", "", elm ) )

      if( l == "" ){
        o <- paste( LETTERS[ ( (d-1) %% n.let ) + 1 ],
                   floor( (d-1) / n.let ) + 1,
                   sep = ""
                   )
      }
      else{
        o <- n.let * (d-1) + match( l, LETTERS )
      }


    }
    output <- append( output, o )

  }

  return( output )

}

##' Biocode well row and col numbers
##'
##' Returns a well number from a biocode coordinate, ie A1 = 1, A2 = 9, B1 = 2
##' @title row and col numbers from biocode coordinates (not Location strings!)
##' @param input either a coordinate, eg A1, or a well number
##' @return array with row and col numbers - or - well numbers, depending on input
##' @export
##' @author Torbjørn Lindahl
well.to.row.col <- function( input ){

    ncol <- 12

    m <- matrix( 1:96, ncol=12, byrow=FALSE )

    if( any(input > 96) || any(input < 1) ){
        stop( "Invalid input, they should all be between 1 and 96" )
    }

    ret <- NULL
    for( i in input ){
        ret <- rbind( ret, which( m == i, arr.ind=TRUE ) )
    }

    return( ret )

}

parse.biocode.location <- function (x) {
    coord <- sub(".* \\(([A-H]\\d+)\\).*", "\\1", x)
    return(coord)
}
