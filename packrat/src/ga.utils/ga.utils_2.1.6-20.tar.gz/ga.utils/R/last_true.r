##' last true value of vector
##'
##' Returns the index of the last true value of a logical. NA if none
##' are found.
##' @title Returns the index of the last true value
##' @param v vector to check
##' @return index of last true value
##' @author Torbjørn Lindahl
##' @export
last_true <- function(v) {

    if(!any(v %in% TRUE) || all(is.na(v))) {
        return( NA )
    }

    return( max(which(v), na.rm=TRUE) )

}
