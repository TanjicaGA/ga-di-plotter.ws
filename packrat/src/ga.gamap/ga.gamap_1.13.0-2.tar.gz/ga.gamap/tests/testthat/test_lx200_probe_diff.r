library(ga.gamap)
library(ga.data)

context( "lx200 probe list" )

test_that( "probes are indexed correctly", {

    expect_equal(
        sort(lx200.missing.probes()),
        c("AG0342","AG0854","AG1118","AG1267","AG1647","AG1652","BLANK1","BLANK2")
    )

    expect_equal(
        lx200.missing.probes(include.technical=FALSE),
        c("AG0342","AG0854","AG1118","AG1267","AG1647","AG1652")
    )

    expect_equal(
        sort(lx200.probes()),
        sort(setdiff( probe.set("ibs3"), lx200.missing.probes() ))
    )

    expect_equal(
        sort(lx200.probes(include.technical=FALSE)),
        sort(setdiff( probe.set("ibs3")[1:54], lx200.missing.probes() ))
    )

})
