##' Dysbiosis limits of T2 and Qres
##'
##' Lists the current dysbiosis threshold on T2 and Qres
##' @title Dysbiosis limits
##' @return list with names T2 and Qres
##' @author Torbjørn Lindahl
##' @export
dysbiosis.limits <- function() {
    dysbiosis.limits.list
}

##' @rdname dysbiosis.limits
##' @export
t2.limit <- function() {
    dysbiosis.limits.list$T2
}

##' @rdname dysbiosis.limits
##' @export
qres.limit <- function() {
    dysbiosis.limits.list$Qres
}
