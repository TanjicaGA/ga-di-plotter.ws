##' pamr's knn imputation function
##'
##' Imputes missing values using knnimpute in pamr. Expects samples in rows and variables in columns.
##' @title knnimpute data
##' @param data data to inn impute
##' @param standardize wether or not to standardize data first
##' @param reference.data reference data to use for imputation
##' @param use.wrong.scale included for historical reasons, standardizez with a slightly different scale
##' @param ... extra arguments to pamr.knnimpute
##' @return data with misisng values imputed
##' @author Torbjørn Lindahl
##' @export
knn.impute <- function(data, standardize=TRUE, reference.data=NULL, use.wrong.scale=FALSE, ...){
    stop( "knn.impute is no longer available in this apckage" )
}

