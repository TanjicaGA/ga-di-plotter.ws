library(ga.utils)

context("load.get() loads variables from file")

rdata.file <- tempfile( fileext=".RData" )
foo <- "bar"
baz <- "test"
save( file=rdata.file, foo, baz )

global.var <- "test"

test_that( "load.get() loads variables from file", {

  expect_that(
    load.get( rdata.file, "foo", verbose=FALSE ),
    equals( "bar" )
    )

  expect_that(
    load.get( rdata.file, "baz", verbose=FALSE ),
    equals( "test" )
    )

  expect_that(
    load.get( rdata.file, "global.var", verbose=FALSE ),
    throws_error( "object 'global.var' not found" )
    )

  expect_that(
    (function() {
      load.get( rdata.file, "foo", assign=TRUE, verbose=FALSE )
      exists( "foo", inherits=FALSE )
    })(),
    is_true()
    )

})
