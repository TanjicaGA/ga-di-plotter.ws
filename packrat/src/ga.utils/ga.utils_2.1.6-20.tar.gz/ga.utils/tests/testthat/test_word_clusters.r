## library(ga.utils)

## context( "Word clusters" )

## test_that( "it seems to do the right thing", {

##     v <- c("FOO12", "FOO23", "FOO45", "BAR123", "BAR56", "BAR300" )

##     cl <- word.clusters(v)

##     ## expect_equal( cl, c(1,1,1,2,2,2) )

## })
