library(ga.utils)

context( "The colors" )

test_that( "They seem right", {

    expect_equal( length(logo.colors()), 6 )

    expect_true(
      all(
        grepl( "^#[a-f0-9]{6}$",
              logo.colors(),
              ignore.case=TRUE
              )))

    expect_equal(
      tolower(logo.colors()),
      c( "#f57f22", "#f8a665", "#fbcca7", "#cbcacb", "#a4a3a4", "#7d7b7c" )
      )


});
