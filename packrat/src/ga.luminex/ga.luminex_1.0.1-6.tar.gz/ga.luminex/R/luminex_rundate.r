##' Parse rundate for bicoode files
##'
##' Reads the date string from the file
##' @title luminex rundate
##' @param x files to read
##' @param ... other arguments passed to read.luminex
##' @return dates
##' @author Torbjørn Lindahl
##' @export
luminex.rundate <- function( x, ... ) {
    dates <- sapply( x, function(f) {
        as.numeric( read.luminex(f, ... )$header$Date )
    }, USE.NAMES = FALSE)
    class( dates ) <- c("POSIXct", "POSIXt" )
    return( dates )
}
