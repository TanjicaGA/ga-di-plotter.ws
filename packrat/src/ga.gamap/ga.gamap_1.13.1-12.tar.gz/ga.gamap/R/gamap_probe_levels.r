##' Report probe shifts
##'
##' Calculates probe shifts for report
##' @title bacteria levels
##' @param ... parameters for \code{\link{gamap}}
##' @param use.bacteria.names logical default TRUE, use bacteria
##'     annotations instead of probe codes
##' @param bacteria.table.revision bacteria table revision to use,
##'     defaults to the newest, rev3. Other valid arguments: rev2 and
##'     rev1. This can also be a data.frame provided with bacteria
##'     table values.
##' @param check.at.qcc29.corrected.before.batch perform qcc29
##'     correction followed by batch correction before calculating the
##'     bacteria table
##' @return matrix with probe shifts
##' @author Torbjørn Lindahl
##' @importFrom ga.data bacteria.limits
##' @importFrom stringr str_match
##' @export
gamap.probe.levels <- function( ..., use.bacteria.names=FALSE, bacteria.table.revision="rev3", check.at.qcc29.corrected.before.batch=FALSE ) {

    ## check for known bacteria table revisions
    ns <- getNamespace("ga.data")
    rev.names <- paste0(
        "rev",
        str_match(
            ls(ns,pattern="bacteria.limits.table.revision"),
            "\\.revision(\\d+)$"
        )[,2]
    )

    if( is.data.frame(bacteria.table.revision) ) {
        d0 <- d <- bacteria.table.revision
    } else if( is.character(bacteria.table.revision) ) {
        if(!bacteria.table.revision %in% rev.names ) {
            stop("Unkonwn bacteria table revision: ", bacteria.table.revision, ". Should be one of: ", paste(rev.names,collapse=","))
        }
        d0 <- d <- ga.data::bacteria.limits( revision=bacteria.table.revision )
        ## Overrule the revision at this point, since we know what the
        ## different revisions require:
        check.at.qcc29.corrected.before.batch <-
            switch(
                bacteria.table.revision,
                rev1 = FALSE,
                rev2 = FALSE,
                rev3 = FALSE,
                rev4 = TRUE
            )
    } else {
        stop("The 'bacteria.table.revision' should be a character or a data.frame")
    }

    .check.bacteria.table.data.frame(d)

    ## rev1 to rev3 checks at center step of algorithm
    ## rev4 checks at batch correction after qcc29

    if( check.at.qcc29.corrected.before.batch ) {
        data.matrix <- gamap.batchcorrect.qcc29( ... )
    } else {
        data.matrix <- gamap( ..., stop.at = "center" )
    }

    rownames(d) <- d$Probe
    d <- d[, grepl("^[-\\+][1-3]$", names(d)) ]

    i <- colnames(data.matrix) %in% rownames(d)

    data.matrix.m <- data.matrix[ , match( rownames(d), colnames(data.matrix) ) ]

    probe.levels <- t(apply( data.matrix.m, 1, function(row) {
        probe.levels.i <- rep( 0, ncol(data.matrix.m) )
        probe.levels.i[ is.na(row) ] <- NA
        ##
        row.n <- row <= d[,paste0(-3:-1)]
        row.p <- row >= d[,paste0("+",1:3)]
        ##
        p.n <- apply( row.n, 1, function(r) ifelse( TRUE %in% r && any(!is.na(r)), min(which(r),na.rm=TRUE), NA ) )
        p.p <- apply( row.p, 1, function(r) ifelse( TRUE %in% r && any(!is.na(r)), max(which(r),na.rm=TRUE), NA ) )
        ##
        if( any( is.finite(p.n) & is.finite(p.p) ) )
            stop(
                "Error: some samples seems to have probes that are both up and down regulated, found for samples ",
                paste( rownames(data.matrix.m)[ is.finite(p.n) & is.finite(p.p) ], collapse=", " )
           )
        ##
        probe.levels.i[ is.finite(p.n) ] <- p.n[ is.finite(p.n) ]-4
        probe.levels.i[ is.finite(p.p) ] <- p.p[ is.finite(p.p) ]
        probe.levels.i
    }))

    colnames( probe.levels ) <- colnames( data.matrix.m )
    if( use.bacteria.names )
        colnames( probe.levels ) <- d0$Bacteria
    else
        colnames( probe.levels ) <- d0$Probe

    return( probe.levels )

}

.check.bacteria.table.data.frame <- function( x ) {

    n <- c("-3", "-2", "-1", "+1", "+2", "+3")
    required.names <- c("Probe", n)

    if(!all( required.names %in% colnames(x) )) {
        stop( "Invalid bacteria table reference data: The data.frame needs to have at least these names: ", paste(required.names, collapse=", ") )
    }

    if(!all(grepl( probe.re(), x$Probe ))) {
        stop( "Invalid bacteria table reference data: The 'Probe' column needs to contain all valid probe codes, ie something matching ", probe.re() )
    }

    if(!all(sapply( x[,n], is.numeric ))) {
        stop( "Invalid bacteria table reference data: The variables ", paste(n,collapse=", "), " should to be all numeric" )
    }

    ## All limits should have increasing values
    xx <- x[,n]
    xx[ is.na(xx) ] <- NaN ## change NA to NaN so its easier to check later
    probe.checks <- apply( xx[,n], 1, function(r) {
        ## the step increases in each row should be NA or positive
        return( all( sign( r[-1] - r[-length(r)] ) %in% c(NaN,1) ))
    })
    if(!all(probe.checks)) {
        stop(
            "Invalid bacteria table reference data: Probes should have increasing values in bt limits, these probes didnt: ",
            paste( x$Probe[!probe.checks], collapse=", " )
        )
    }

}
