library(ga.luminex)

context( "crc32 check correct on unix and win32 newlines" )

test_that( "crc32 gets evaluated correctly with different newline formats", {

    lum.file <- "data/LUM05-03-1601.csv"
    expect_warning( read.luminex( lum.file ), regexp = NA )

    lum.file.u <- "data/LUM05-03-1601-UNIX-NEWLINE.csv"
    expect_warning( read.luminex( lum.file.u ), regexp = NA )

})
