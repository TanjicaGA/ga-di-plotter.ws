library(ga.utils)

context( "remove NA rows" )

test_that( "NA rows are removed", {

    d <- rbind( 1:4, 5:8, rep(NA,4) )

    expect_equal(
        remove.na.rows(d),
        d[1:2,,drop=FALSE]
    )

    d <- rbind( 1:4, rep(NA,4) )

    expect_equal(
        remove.na.rows(d),
        d[1,,drop=FALSE]
    )

})
