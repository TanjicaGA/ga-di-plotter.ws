##' @rdname correct
##' @export
inverse.correct <- function( obj, newdata, ... ) UseMethod("inverse.correct")

##' Correct -to- a given batch from PS0000, not from as is usually the case.
##'
##' Corrects data from PS0000 to a given batch, essentially reversing
##' the operation that would otherwise be done on a matrix.
##' @title inverse batch correct
##' @rdname correct
##' @export
inverse.correct.batchcorrection <- function( obj, newdata, ... ) {

    if(!inherits( obj, "batchcorrection" )){
        stop("Object isn't a batchcorrection object")
    }

    if( obj$type == "null" )
      return(newdata)

    cf <- coef(obj)

    if( !is.null(dim(cf)) && ncol(cf) != ncol(newdata) ) {
        if( ncol(newdata) == 54 ) {
            cf <- coef( platform_align( obj, "biocode" ) )
        } else if( ncol(newdata) == 48 ) {
            cf <- coef( platform_align( obj, "lx200" ) )
        } else {
            stop(paste( "Cannot automatically handle correction, new data has unusual ncol:", ncol(newdata) ) )
        }
    }

    uncorr <- NULL

    if( obj$type %in% c("log.scale","exponential") ) {

        shr <- rep( cf[1,], each=nrow(newdata) )
        sft <- rep( cf[2,], each=nrow(newdata) )

        uncorr <- (newdata/sft)**(1/shr)

    }
    else if( obj$type == "ratio" ) {
        uncorr <- sweep( newdata, 2, cf, FUN="/" )
    }
    else if( obj$type == "difference" ) {
        uncorr <- sweep( newdata, 2, cf, FUN="+" )
    }
    else {
        stop(paste("Unknown batch correction object type: ", obj$type))
    }

    invisible(uncorr)

}
