##' Count NA
##'
##' Count NA along coulmns or rows
##' @title Count NA
##' @param m array
##' @param dir direction/margin
##' @return integer, number of NA along given margin
##' @author Torbjørn Lindahl
##' @export
count.na <- function( m, dir=2 ){
  apply( m, dir, function(c){ length(which(is.na(c))) } )
}
