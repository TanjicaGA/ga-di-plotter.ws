##' load from RData file
##'
##' Loads rdata file and fetches specific variables in it
##' @title load.get
##' @param rdata.file rdata file to load from
##' @param var.name variable name to look for in the file. If missing
##' and only one name is present, that name is used.
##' @param assign logical default FALSE, should it assign the variable
##' to the calling frame?
##' @param verbose logical default TRUE, say more things
##' @param envir environment to assign to if assigning
##' @return invisibly the content of the variable that gets loaded
##' @author Torbjørn Lindahl
##' @export
load.get <- function( rdata.file, var.name, assign=FALSE, verbose=TRUE, envir=parent.frame() ) {

  e <- new.env()
  load( rdata.file, e )

  if( missing(var.name) && length(ls(e)) == 1 ) {
      var.name <- ls(e)[1]
  }

  v <- get( var.name, e, inherits = FALSE )

  if( assign ){
      assign( var.name, v, envir )
  }

  if( verbose )
      cat( "loaded", var.name, "from", basename(rdata.file), "\n" )

  invisible(v)

}
