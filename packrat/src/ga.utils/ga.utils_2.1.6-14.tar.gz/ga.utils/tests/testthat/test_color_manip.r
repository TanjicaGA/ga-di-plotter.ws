library(ga.utils)

context( "tint.color" )

test_that( "colors are tinted", {

    expect_equal(
        tint.color( "white", tint=0 ),
        "#FFFFFF"
    )

    expect_equal(
        tint.color( "black", tint=0 ),
        "#000000"
    )

    expect_equal(
        tint.color( c("white","black"), tint=0 ),
        c("#FFFFFF","#000000")
    )

    expect_equal(
        tint.color( c("#00FF00"), tint=-1/4 ),
        "#00BF00"
    )


})
