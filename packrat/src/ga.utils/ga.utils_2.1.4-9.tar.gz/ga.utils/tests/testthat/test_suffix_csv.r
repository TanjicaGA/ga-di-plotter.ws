library(ga.utils)

context( "suffix csv" )

test_that( "string gets suffix", {

    expect_equal( suffix.csv("foo"), "foo.csv" )
    expect_equal( suffix.csv("foo", suffix="txt"), "foo.txt" )

})
