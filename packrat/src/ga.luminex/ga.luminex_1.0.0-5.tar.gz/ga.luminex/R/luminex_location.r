##' parse luminex location strings
##'
##' Parses luminex location strings and returnes interpreted values Well, Row and Col
##' @title parses luminex location strings and returns data frame
##' @param x input argument. accepts a character of location strings, arrays/data.frames with a 'Location' column name or any vector with names which are assumed to be location strings
##' @param accept.unknwon accept that some strings may not be recognized (will become NA's)
##' @return dataframe with Well from 1 to 96, row from 1 to 8 column from 1 to 12
##' @author Torbjørn Lindahl
parse.luminex.location <- function(x, accept.unknwon=FALSE) {

    if( is.character(x) )
        l <- x
    else if( !is.null(dim(x)) && "Location" %in% colnames(x) )
        l <- x[,"Location"]
    else if( !is.null(names(x)) )
        l <- names(x)
    else
        stop( "Cannot determine the Location strings from the input" )

    m <- str_match( l, "^(\\d+)\\((\\d+),([A-H])(\\d+)\\)$" )

    if( anyNA(m) && !accept.unknwon )
        stop( "Unknown Location patterns encountered in input" )

    if( any(m[,3] != "1") ) {
        stop( "Unkonwn location pattern, should be '1' after opening parenthesis, as in '7(1,B1)'" )
    }

    data.frame(
        Location=l,
        Well=as.numeric(m[,2]),
        Row=match(m[,4], LETTERS),
        Col=as.numeric(m[,5])
    )

}
