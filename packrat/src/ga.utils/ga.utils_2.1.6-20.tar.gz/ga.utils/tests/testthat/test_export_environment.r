library(ga.utils)

context("export.and.postfix")

test_that( "it exports plainly", {

    e <- new.env()
    e2 <- new.env()

    assign( "foo", "bar", e )

    expect_false( exists("foo") )

    export.and.postfix( e )
    expect_true( exists("foo") )

    expect_false( exists("foo", envir=e2, inherits=FALSE) )
    export.and.postfix( e, where=e2 )
    expect_true( exists("foo", envir=e2, inherits=FALSE) )

    expect_equal( get("foo",e,inherits=FALSE), get("foo",e2,inherits=FALSE))

})

test_that( "it exports with a postfix", {

    e <- new.env()
    assign( "foo", "bar", e )
    e3 <- new.env()
    expect_false( exists("foo", envir=e3, inherits=FALSE) )
    expect_false( exists("foo.2", envir=e3, inherits=FALSE) )
    export.and.postfix( e, postfix=".2", where=e3 )
    expect_false( exists("foo", envir=e3, inherits=FALSE) )
    expect_true( exists("foo.2", envir=e3, inherits=FALSE) )

})
