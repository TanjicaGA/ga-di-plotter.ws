##' Read a luminex file
##'
##' Read a luminex file
##' @title read luminex
##' @param file.name luminex file
##' @param require.crc.check default TRUE, check that the CRC checksum matches. If set to FALSE this check will still result in a warning if the checksum does not match.
##' @return data.frame
##' @author Torbjørn Lindahl
##' @export
##' @importFrom ga.utils grep1
##' @importFrom utils read.csv
##' @importFrom stringr str_match
##' @importFrom stringi stri_locate_first_regex
##' @importFrom readr read_file
read.luminex <- function( file.name, require.crc.check=TRUE ) {

    fc <- d <- read_file( file.name )
    m <- stri_locate_first_regex( d, "^-- CRC --$", multiline=TRUE )

    if(!is.na(m[1]) ) {

        fc <- substr( d, 1, m[1]-1 )
        crc.calc <- sub( "^0+", "", toupper(digest::digest( fc, algo="crc32", file=FALSE, serialize=FALSE )) )
        crc.file <-
            toupper(str_match( substr( d, m[1], nchar(d) ), "CRC32: 0*(\\S+)")[,2])

        if( crc.calc != crc.file ) {
            msg <- paste0(
                "CRC32 checksum failed, file says: '",
                crc.file,
                "' and verification gave: '",
                crc.calc, "'"
            )
            if( require.crc.check ) {
                stop(msg)
            } else {
                warning(msg)
            }
        }
    } else {
        msg <- "CRC32 checksum not found in file"
        if(!require.crc.check)
            warning(msg)
        else
            stop(msg)
    }

    con <- textConnection( fc )
    l <- try( readLines( con=con, warn=FALSE ) )
    close(con)

    section.positions <- grep( '"?DataType:"?', l )
    section.names.infile <-
        sub( '"?DataType:"?,', "", grep( '"?DataType:"?', l, value=T ) )
    section.names.infile <-
        gsub( '"', "", section.names.infile )

    section.names <- section.names.infile

    datasets <- list()

    ## header
    header <- list()
    lastline <- NULL
    for( line in readLines( file.name, n=section.positions[1]-1 ) ) {

        ## In case the previous line contained newlines, prepent
        ## it to this line
        if( !is.null(lastline) ) {
            line <- paste0( lastline, "\n", line )
            lastline <- NULL
        }

        if( nchar(line) && line != '""' ) {

            con <- textConnection( line )
            d <- try( read.csv( con, header=FALSE, stringsAsFactors=FALSE ), silent=TRUE )
            close(con)

            if( inherits( d, "try-error" ) ) {

                if( grepl( "incomplete final line", geterrmessage() )) {
                    lastline <- line
                    next
                } else {
                    stop( d )
                }

            }

            if(!is.null(dim(d)) ) {

                if( !is.null(dim(d)) && d[1,1] == "Date" ) {
                    ds <- paste( d[1,2], d[1,3] )
                    header$Date <- strptime( ds, "%m/%e/%Y %I:%M %p" ) ## "10/9/2014 11:24 AM"
                }
                else {
                    v <- unlist(d[1,])
                    names(v) <- NULL
                    header[[ v[1] ]] <- v[-1]
                }
            }

        }

    }

    datasets$header <- header

    for( name in section.names ){

        m <- match( name, section.names.infile )
        start.pos <- section.positions[m]+1

        if( m == length(section.names.infile) ){
            end.pos <- length(l)
            nrows <- length( l ) - start.pos - 1
        } else {
            end.pos <- section.positions[m+1] - 2
            nrows <- section.positions[m+1] - start.pos - 3
        }

        if( nrows > 0 ){

            section <- paste0(
                paste(l[start.pos:end.pos], collapse = "\n"),
                "\n"
            )

            con <- textConnection(section)
            d <- try(
                read.csv(
                    con,
                    stringsAsFactors=FALSE,
                    ),
                silent=FALSE
            )
            close(con)

            if( !inherits( d, "try-error" ) ) {
                ## -1 is NA
                if(nrow(d))
                    d[ d==-1 ] <- NA
                datasets[[name]] <- d
            } else{
                datasets[[name]] <- list()
            }
        }

    }

    datasets$CRC32 <- crc.file

    return( datasets )

}

##' Reads several luminex files and attaches count matrices as an attribute
##'
##' Reads the specifed section from each of several files
##' @title read several luminex files
##' @param file.names luminex files to read
##' @param section section to read, defaults to 'Median'
##' @param ... arguments passed to read.luminex
##' @return dataframe with raw data and meta data
##' @author Torbjørn Lindahl
read.luminex.files <- function( file.names, section="Median", ... ) {

    ll <- lapply(file.names,function(f)append( read.luminex(f), list(File=f) ) )

    .uc.probe.name.fix <- function(x) {
        j <- grepl( "^([AI]G\\d{4}|UNI\\d+|HYC\\d+|BLANK\\d+)$",
                   colnames(x), ignore.case=TRUE )
        n <- colnames(x)
        n[j] <- toupper( n[j] )
        colnames(x) <- n
        x
    }

    ## main data
    d <- Reduce(
        function(a,b)rbind(
                         a,
                         cbind.data.frame(
                             File=basename(b$File),
                             Rundate=b$header$Date,
                             .uc.probe.name.fix(b[[section]])
                         )
                     ),
        ll,
        init=NULL
    )

    ## count data
    dc <- Reduce(
        function(a,b)rbind(
                         a,
                         cbind.data.frame(
                             File=basename(b$File),
                             Rundate=b$header$Date,
                             .uc.probe.name.fix(b[["Count"]])
                         )
                     ),
        ll,
        init=NULL
    )

    f <- factor( d$File, levels=unique(as.character(d$File) ))
    levels(f) <- paste(1:nlevels(f))

    d$Plate <- f
    dc$Plate <- f

    attr( d, "count") <- dc

    return( d )

}
