library(testthat)
library(ga.software)

test_check("ga.software")
