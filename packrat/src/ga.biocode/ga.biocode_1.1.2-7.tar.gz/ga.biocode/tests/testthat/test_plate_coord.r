library(ga.biocode)

context( "From coordinates" )

test_that( "coordinates convert", {

    expect_equal( plate.coord("A1")  , 1  )
    expect_equal( plate.coord("H12") , 96 )
    expect_equal( plate.coord("A2")  , 9  )
    expect_equal( plate.coord("B1")  , 2  )
    expect_equal( plate.coord("G12") , 95 )
    expect_equal( plate.coord("H11") , 88 )

})

test_that( "numbers convert back", {

    expect_equal( plate.coord(1)  , "A1"  )
    expect_equal( plate.coord(96) , "H12" )
    expect_equal( plate.coord(9)  , "A2"  )
    expect_equal( plate.coord(2)  , "B1"  )
    expect_equal( plate.coord(95) , "G12" )
    expect_equal( plate.coord(88) , "H11" )

})
