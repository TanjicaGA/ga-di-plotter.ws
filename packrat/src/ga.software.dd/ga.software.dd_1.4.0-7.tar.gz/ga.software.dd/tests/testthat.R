library(testthat)
library(ga.software.dd)

test_check("ga.software.dd")
