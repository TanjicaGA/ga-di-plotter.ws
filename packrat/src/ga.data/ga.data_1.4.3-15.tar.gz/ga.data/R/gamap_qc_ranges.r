##' QC Parameters
##'
##' Numbers used in QC eval
##' @title QC ranges
##' @param skip.upper.hyc logical default FALSE, skip upper limit for HYC01
##' @param platform platform to use, defaults to 'biocode', 'lx200' also valid
##' @return list, QC data
##' @author Torbjørn Lindahl
##' @importFrom ga.utils truthy
##' @importFrom jsonlite toJSON
##' @export
gamap.qc.ranges <- function( platform=c("lx200","biocode"), skip.upper.hyc=TRUE, warn.overrides=TRUE ) {

    platform <- match.arg(platform)

    s <- list(
        "QCC.counts"        = list(
            QCC23 = 1,
            QCC33 = 1,
            QCC30 = 1
        ),
        "QCC30.HYC01.range" = c( 10000, ifelse( skip.upper.hyc, Inf, 30000 ) ),
        "Background.upper"  = 500,
        "HYC01.range"       = c( 11500, ifelse( skip.upper.hyc, Inf, 30000 ) ),
        "UNI05.lower"       = 4500,
        "QCC30.UNI05.lower" = 4500,
        "BeadCount.lower"   = 3,
        "Pos.Ctrl.lower"    = 3.574,
        "Pos.Ctrl.upper"    = 5,
        "Neg.Ctrl.lower"    = 0,
        "Neg.Ctrl.upper"    = 2,
        "skip.probes"       = character(),
        "QCC30.total.signal"= c(0,Inf),
        "QCC29.total.signal"= c(0,Inf),
        "QCC29.total.signal.bio"= c(0,Inf)
    )

    if( platform == "lx200" ) {

        s$Background.upper <- Inf
        s$BeadCount.lower <- 70

        s$UNI05.lower <- 10e3
        s$HYC01.range <- c( 11.5e3, 23e3 )

        s$QCC30.UNI05.lower <- 5e3
        s$QCC30.HYC01.range <-  c( 11.5e3, 23e3 )

        s$skip.probes <- lx200.missing.probes()

        s$QCC29.total.signal <- c( 0, Inf )
        s$QCC29.total.signal.bio <- c( 0, 20e3 )
        s$QCC30.total.signal <- c( 650e3, 1100e3 )

    }

    ## overrides defined in option  "GamapQcOverride"
    o <- getOption("GamapQcOverride")

    if( truthy(o) && inherits( o, "list" ) ) {

        nn <- intersect( names(s), names(o) )
        s[ nn ] <- o[ nn ]

        if( warn.overrides ) {
            msg <- sprintf(
                "Temporarily using different QC-criteria: %s",
                toJSON( o[nn], pretty=TRUE, auto_unbox=TRUE )
            )
            warning( msg )
        }

    }

    return( s )

}
