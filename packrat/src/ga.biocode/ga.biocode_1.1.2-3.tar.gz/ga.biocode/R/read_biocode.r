##' Read a single biocode file
##'
##' Read a single biocode file. Specify section names to fetch
##' otherwise fetches all sections found in file
##'
##' Returns a named list of the sections found in the file, usually
##' this means:
##' list(
##'   header = <info in header>,
##'   Count = <count matrix>,
##'   Median = <median matrix>
##' )
##' @title Read biocode file
##' @param file.name file to read
##' @param section.names sections to fetch from the file
##' @return list with sections
##' @author Torbjørn Lindahl
##' @export
##' @importFrom utils read.csv
read.biocode <- function( file.name, section.names ) {

    l <- readLines(file.name,warn=FALSE)

    section.positions <- grep( '"?DataType:"?', l )
    section.names.infile <-
        sub( '"?DataType:"?,', "", grep( "DataType:", l, value=T ) )
    section.names.infile <-
        gsub( '"', "", section.names.infile )

    if( missing(section.names) ){
        section.names <- section.names.infile
    }
    else if( any( ! section.names %in% section.names.infile ) ){
        stop(call.=FALSE, "These sections are not found in file: ",
             paste(setdiff( section.names, section.names.infile ), collapse=", ") )
    }

    datasets <- list()

    for( name in section.names ){

        m <- match( name, section.names.infile )
        start.pos <- section.positions[m]

        if( m == length(section.names.infile) ){
            nrows <- length( l ) - start.pos - 1
        }
        else{
            nrows <- section.positions[m+1] - start.pos - 3
        }

        if( nrows > 0 ){

            d <- try( read.csv( file.name, skip=start.pos,
                               stringsAsFactors=FALSE,
                               nrows=nrows ), silent=TRUE )

            ## -1 is NA
            d[ d==-1 ] <- NA

            if( !inherits( d, "try-error" ) )
                datasets[[name]] <- d
            else{
                datasets[[name]] <- list()
            }
        }

    }

    ## Add the header
    header <- list()
    i.d <- grep( '^"DataType:",', l )
    if( length(i.d) > 0 ) {

        l.d <- i.d[1]

        lastline <- NULL
        
        for( line in setdiff(l[1:(l.d-1)],"") ) {

            ## In case the previous line contained newlines, prepent
            ## it to this line
            if( !is.null(lastline) ) {
                line <- paste0( lastline, "\n", line )
                lastline <- NULL
            }
            
            con <- textConnection(line)
            d <- try( read.csv( con, header=FALSE, stringsAsFactors=FALSE ), silent=TRUE )
            close(con)

            if( inherits( d, "try-error" ) ) {
                
                if( grepl( "incomplete final line", geterrmessage() )) {
                    lastline <- line
                    next
                } else {
                    stop( d )
                }

            }
            
            if( ncol(d) == 4 ) {
                header[[ d[1,1] ]] <- d[1,2]
                header[[ d[1,3] ]] <- d[1,4]
            }
            else if( d[1,1] == "Date" ) {
                ds <- paste( d[1,2], d[1,3] )
                header$Date <- strptime( ds, "%m/%e/%Y %I:%M %p" ) ## "10/9/2014 11:24 AM"
                if( is.na( strptime( "11 AM", "%I %p" ) ) )
                    warning( "Unable to parse timestamps with AM/PM due to locale settings on system" )

            }
            else if( ncol(d) == 2 ) {
                header[[ d[1,1] ]] = d[1,2]
            }
            else if( ncol(d) == 1 && d[1,1] == "Results" ) {
            }
            else {
                stop( paste("Unknown header line encountered: ", line ) )
            }

        }

        datasets$header <- header

    }

    return ( datasets )

}
