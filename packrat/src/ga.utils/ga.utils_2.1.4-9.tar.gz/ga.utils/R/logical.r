##' Logical evaluation with a breeze
##'
##' Makes reasonable assumptions on what can be treated as TRUE
##' @title interpreted true
##' @param x argument to be interpreted
##' @return logical TRUE or FALSE depending
##' @author Torbjørn Lindahl
##' @export
truthy <- function( x ) {

    if( missing(x) ) {
        return( FALSE )
    }
    if( length(x) == 0 ) {
        return( FALSE )
    }
    if( is.null(x) ) {
        return( FALSE )
    }
    if( is.logical(x) ) {
        return( x )
    }
    if( length(x) == 0 ){
        return( FALSE )
    }
    if( is.numeric(x) ) {
        return( x != 0 )
    }
    if( is.character(x) ) {

        n <- suppressWarnings( as.numeric(x) )
        if(!is.na(n) && ! inherits(n, "try-error") ) {
            return( truthy(n) )
        }

        if( x == "" || toupper(x) == "FALSE" || toupper(x) == "NO" ) {
            return(FALSE)
        }

        return( TRUE )

    }
}

##' @rdname truthy
##' @export
falsy <- function( x ) {
    return( !truthy(x) )
}
