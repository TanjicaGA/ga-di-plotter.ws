##' Align data based on column names
##'
##' Align a 2D object to a target object based on column names.
##' @title align data on column names
##' @param source.data data to be aligned
##' @param target.data data to align to
##' @param on a name to match on, could be a name in a data.frame
##' @return source data aligned to target data
##' @author Torbjørn Lindahl
##' @rdname align.columns
##' @export
align.columns <- function( source.data, target.data, on=NULL ){

    s.names <- decide.names( source.data, on )
    t.names <- decide.names( target.data, on )

    m <- match( t.names, s.names )

    if( is.null(dim(source.data)) ){
        aligned <- source.data[m]
    }
    else {
        aligned <- source.data[,m,drop=FALSE]
    }

    return( aligned )

}

decide.names <- function( x, on=NULL ) {

    n <- NULL

    if( !is.null(on) && on %in% names(x) ) {
        if( sum(names(x) %in% on) > 1 )
            stop( "Name to match on occurs more than once" )
        n <- x[[on]]
    }
    else if( !is.null(dim(x))) {

        if( !is.null(on) && on %in% colnames(x) ) {
            if( sum(colnames(x) %in% on) > 1 )
                stop( "Name to match on occurs more than once" )
            n <- x[,on]
        }
        else
            n <- colnames(x)

    }
    else {
        n <- as.character(x)
    }

    if(is.null(n))
        stop( "Failed finding names to match on for" )

    return( n )

}
