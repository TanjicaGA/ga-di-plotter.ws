library(testthat)
library(ga.gamap)

test_check("ga.gamap")
