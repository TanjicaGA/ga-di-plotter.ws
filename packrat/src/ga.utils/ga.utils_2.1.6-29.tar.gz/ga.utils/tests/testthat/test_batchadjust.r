library(ga.utils)

context( "batchadjust" )

test_that( "data gets adjusted", {

    x <- rbind(
        matrix( rnorm(20*30, mean=1), nrow=20, ncol=30 ),
        matrix( rnorm(20*30, mean=2), nrow=20, ncol=30 )
    )

    y <- gl( 2, 20 )

    v1 <- var( as.numeric(x) )

    xb <- batchadjust( x, y )

    expect_equal( dim(x), dim(xb) )

    v2 <- var( as.numeric(xb) )

    ## batch adjustment should reduce variance from the artifical effect
    expect_lt( v2, v1 )

})
