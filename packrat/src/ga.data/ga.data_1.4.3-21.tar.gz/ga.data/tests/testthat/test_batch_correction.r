library(ga.data)
library(ga.utils)
library(ga.batchcorrection)

context( "batch.correction" )

test_that( "batch retrieval works", {

    expect_is( batch.correction("PS1512"), "batchcorrection" )

    ## PS1512 is an object
    bcf <- batch.correction("PS1512")
    expect_is( bcf, "batchcorrection" )
    expect_is( coef(bcf), "matrix" )

    ## PS1508 is also a batchcorrection
    expect_is( batch.correction("PS1508"), "batchcorrection" )

})

context( "check objects" )

test_that( "they are all bcf objects", {

    e <- getNamespace("ga.data")
    ps.names <- grep( "^PS\\d{4}$", ls(e), value=TRUE )

    for(n in ps.names) {
        expect_is( get(n), "batchcorrection" )
        expect_true( get(n)$type %in% c(
          "exponential", "difference", "log.scale", "null"
          ), n)
    }

})

context( "some bcf specifics" )

test_that( "PS1602 meet some expected behaviours", {

    ## probe 40 is essentially neutralized
    nr <- 100
    x <- matrix(
        nrow=nr,
        ncol=54,
        rnorm(100*54)
        )

    bcf <- batch.correction("PS1602")
    expect_equal( bcf$type, "exponential" )

    ## it should be around 40 regardless
    for( m in c(10,20,50,100,200,500,1e3,2e3,5e3) ) {
        x[,40] <- rnorm( n=nr, m=m )
        b <- correct( bcf, x )
        expect_true( all( b[,40] %between% c(25,45) ) )
    }

})

context( "psf.exists" )

test_that( "it knows if a psf exists", {

    expect_true( psf.exists("PS1801L") )
    expect_true( psf.exists("PS1801L.9") )
    expect_true( psf.exists("PS1701L") )
    expect_false( psf.exists("PS1701L.9") )
    expect_false( psf.exists("probe.set.ibs3") )

})

context( "temporary psf resolution" )

test_that( "temp names can be made available", {

    PS1999L <- batch.correction("PS1801L")
    PS1999L$psf.name <- "PS1999L"

    expect_error(
        batch.correction("PS1999L")
    )

    options( temporary_psf_objects = list( PS1999L = PS1999L ) )

    expect_warning( bcf <- batch.correction("PS1999L") )
    expect_true( inherits( bcf, "batchcorrection" ) )


})
