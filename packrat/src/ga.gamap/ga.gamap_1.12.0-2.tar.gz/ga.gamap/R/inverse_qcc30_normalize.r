##' inverse qcc30 normalize
##'
##' Based on QCC30 values in the matrix, performs a reversed QCC30
##' normalization.
##' @title reverse a previously performed QCC30 normalization
##' @return matrix corresponding to hyb normalized profiles
##' @author Torbjorn Lindahl
##' @param di.qcc QCC30 normalized profiles
##' @param di.plate Raw data for the QCC30 normalized matrix
##' @importFrom ga.data probe.data
##' @export
inverse.qcc30.normalize <- function( di.qcc, di.plate ) {

    if(!identical( rownames(di.qcc), di.plate$Sample )) {
        stop("input arguments di.qcc must have rownames corresponding to input argument di.plate$Sample")
    }

    i.qcc30 <- grepl( "QCC30", di.plate$Sample )
    x.plate <- probe.data( di.plate, include.technical=FALSE )

    di.hyb <- x.hyb <- gamap( di.plate, start.from="file", stop.at="hyb" )
    x.hyb[] <- NA

    up <- unique( di.plate$Plate )

    for( p in up ) {
        i.p <- di.plate$Plate == p
        i <- i.p & i.qcc30
        x.qcc30.med <- apply( di.hyb[i,,drop=FALSE], 2, median, na.rm=TRUE )
        x.hyb[ i.p, ] <- sweep( di.qcc[i.p,,drop=FALSE]/1000, 2, x.qcc30.med, FUN="*" )
    }

    return( x.hyb )

}
