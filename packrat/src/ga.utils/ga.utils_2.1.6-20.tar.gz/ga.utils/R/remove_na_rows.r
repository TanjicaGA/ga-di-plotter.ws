##' remove rows that are all NA
##'
##' Remove rows from a 2D+ structure that are all NA
##' @title remove NA rows
##' @return data with >=0 rows removed
##' @author Torbjørn Lindahl
##' @param x input data
##' @export
remove.na.rows <- function( x ) {

    if( is.null(dim(x)) ) {
        stop( "input data needs to have at least 2 dimensions" )
    }

    i <- count.na( x, 1 ) == ncol(x) # rows that have NA count
                                        # matching col count

    if( any(i) ) {
        x <- subset_deep( x, !i )
    }

    return( x )

}

##' Remove columns that are all NA
##'
##' Takes out columns that are all NA
##' @title remove columns that are all NA
##' @param x object to process, must have dim >= 2
##' @return x without columns that are all NA
##' @author Torbjørn Lindahl
##' @export
remove.na.columns <- function(x) {

    if( is.null(dim(x)) ) {
        stop( "input data needs to have at least 2 dimensions" )
    }

    i <- count.na( x, 2 ) == nrow(x)

    if( any(i) ) {
        x <- x[,!i]
    }

    return( x )
}
