##' Report probe shifts
##'
##' Calculates probe shifts for report
##' @title bacteria levels
##' @param ... parameters for \code{\link{gamap}}
##' @param use.bacteria.names logical default TRUE, use bacteria
##'     annotations instead of probe codes
##' @param bacteria.table.revision bacteria table revision to use,
##'     defaults to the newest, rev3. Other valid arguments: rev2 and
##'     rev1.
##' @return matrix with probe shifts
##' @author Torbjørn Lindahl
##' @importFrom ga.data bacteria.limits
##' @export
gamap.probe.levels <- function( ..., use.bacteria.names=TRUE, bacteria.table.revision="rev3" ) {

    di.center <- gamap( ..., stop.at = "center" )

    d0 <- d <- ga.data::bacteria.limits( revision=bacteria.table.revision )
    rownames(d) <- ga.gamap::translate.probe.names( d$ProbeNo )
    d <- d[, grepl("^[-\\+][1-3]$", names(d)) ]

    i <- colnames(di.center) %in% rownames(d)

    di.center.m <- di.center[ , match( rownames(d), colnames(di.center) ) ]

    probe.levels <- t(apply( di.center.m, 1, function(row) {
        probe.levels.i <- rep( 0, ncol(di.center.m) )
        ##
        row.n <- row <= d[,1:3]
        row.p <- row >= d[,4:6]
        ##
        p.n <- apply( row.n, 1, function(r) ifelse( TRUE %in% r && any(!is.na(r)), min(which(r),na.rm=TRUE), NA ) )
        p.p <- apply( row.p, 1, function(r) ifelse( TRUE %in% r && any(!is.na(r)), max(which(r),na.rm=TRUE), NA ) )
        ##
        if( any( is.finite(p.n) & is.finite(p.p) ) )
          stop("Error: some samples seems to have probes that are both up and down regulated")
        ##
        probe.levels.i[ is.finite(p.n) ] <- p.n[is.finite(p.n)]-4
        probe.levels.i[ is.finite(p.p) ] <- p.p[is.finite(p.p)]
        probe.levels.i
    }))

    colnames( probe.levels ) <- colnames( di.center.m )
    if( use.bacteria.names )
        colnames( probe.levels ) <- d0$Bacteria
    else
        colnames( probe.levels ) <- d0$Probe

    return( probe.levels )

}
