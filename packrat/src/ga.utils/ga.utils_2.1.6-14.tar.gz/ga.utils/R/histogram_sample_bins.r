##' Which bin are samples in
##'
##' Report which bin a sample belongs in
##' @title Find which bin the input vector of hist() ended up in
##' @return vector of integers
##' @author Torbjørn Lindahl
##' @param h histogram object
##' @param x input vector to hist() call
##' @seealso \code{\link[graphics]{hist}}
##' @export
histogram_sample_bins <- function(h,x) {

    if(missing(x))
      x <- eval.parent(parse(text=h$xname))

    bins <- apply( !sapply( h$breaks, function(b)x >= b ), 1, first ) - 1

    return( bins )

}
