##' report lower and upper limit for one or more probes
##'
##' Checks one or more probes in the specified bacteria table revision
##' for the range applicable in the bacteria table resutls, eg the
##' darker blue area in the report form.
##' @title range for bacteria in bacteria table
##' @param probes one or more probes to look up
##' @param revision bacteria table revision to look up
##' @param return.type if 'character', the default, they will be of
##'     type character and positive bacteria scores will be prefixed
##'     with '+', ie '+1', '+2' etc. If 'integer' or 'numeric' they
##'     will be numbers.
##' @return array with one or more vectors, one for each probe.
##' @author Torbjorn Lindahl
##' @importFrom foreach foreach %do%
##' @importFrom stats na.omit
##' @export
bacteria.table.ranges <- function( probes, revision="rev4", return.type=c("character","numeric","integer") ) {

    rt <- match.arg( return.type )

    n <- c( paste(-3:-1), paste0("+",1:3) )

    bl <- bacteria.limits( revision=revision )

    if(missing(probes))
        probes <- bl$Probe

    probe <- NULL
    d <- foreach( probe=probes, .combine=cbind) %do% {
        ##
        m <- match( probe, bl$Probe )
        ##
        if( !is.na(m) ) {
            v <- names( na.omit( unlist( bl[m,n] ) ) )
            if( length(v) == 1 ) {
                v <- c("0",v)
                v <- v[ order(as.numeric(v)) ]
            } else {

                ## if the range starts at +1, it really starts at 0
                if( v[1] == "+1" )
                    v[1] <- 0

                ## if the range ends at -1, it really ends at 0
                if( v[length(v)] == "-1" )
                    v[length(v)] <- "0"

                ## v[ v %in% c("-1","+1") ] <- "0"

            }
            if( rt != "character" ) {
                v <- as.numeric(v )
            }
            ranges <- c( v[1], v[length(v)] )
        } else {
            ranges <- c(NA,NA)
        }
        ranges
    }
    if(is.null(dim(d)))
        d <- matrix( d, ncol=1 )

    dimnames(d) <- list( c("lower","upper"), probes )

    d

}
