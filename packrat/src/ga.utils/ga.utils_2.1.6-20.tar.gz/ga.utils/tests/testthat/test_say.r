library(ga.utils)

context( "Normal usage" )

test_that( "Normal data shows as expected", {

    expect_output( say("foo"), "^foo $" )
    ## Unfortunately the trailing newline is chomped, so need to test
    ## more than one value
    expect_output( say(c("foo","bar")), "^foo\nbar $" )

})

context( "Odd characters" )

test_that( "Null, missing and NA is handled", {

    expect_output( say(NULL), "^ $" )
    expect_output( say(NA), "^NA $" )

    expect_output( say(), "^ $" )

})

context( "sprintf shortcut" )

test_that( "patterns get interpolated", {

    expect_output( sayf( "hi %s", "foo" ), "^hi foo $" )
    expect_output( sayf( "hi %d", 1 ), "^hi 1 $" )
    expect_output( sayf( "hi there" ), "^hi there $" )

})
