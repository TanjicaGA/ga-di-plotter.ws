##' biocode test data
##'
##' Prepares a complete json file with test data from given input file
##' @title biocode test data
##' @return list with testdata
##' @author Torbjørn Lindahl
##' @param bc.file biocode file to process
##' @param batch batch to use for batch correction, see \code{gamap}
##' @param out.file optionally provide a sjon file to write to
##' @importFrom ga.biocode read.biocode
##' @importFrom ga.gamap gamap
##' @importFrom ga.gamap gamap.probe.levels
##' @importFrom ga.gamap process.csvfile
##' @importFrom ga.data dysbiosis.limits
##' @importFrom ga.utils "%between%"
##' @importFrom ga.utils date.string
##' @importFrom ga.data bacteria.limits
##' @importFrom jsonlite toJSON
##' @export
prepare.biocode.testdata <- function( bc.file, batch, out.file ) {

    med <- process.csvfile( bc.file, "Median", raw=TRUE )
    count <- process.csvfile( bc.file, "Count", raw=TRUE )

    hd <- process.csvfile( bc.file, "header", raw=TRUE )
    names(hd) <- sub( "Min.Events", "Min_Events", names(hd) )
    hd$Date <- format( hd$Date, "%FT%T" )

    ## Need these two lines here to get the location strings right
    median.data                           <- di0 <- ga.gamap::gamap( bc.file, stop.at="file", batch=batch )
    count.data                            <- attr( median.data, "count" )
    ##

    cn <- sub("^X", "",
              grep( "^(X\\d+|[AI]G\\d+|HYC01|UNI05)$", colnames(med), value=TRUE, ignore.case=TRUE )
              )

    ## loc <- sub( "^\\d+ \\((\\S+)\\)$", "\\1", med$Location )
    loc <- median.data$Coord

    output <- list(
        header = hd,
        probe = cn,
        location = loc,
        sample = median.data$Sample,
        batch_used = batch,
        VERSION = date.string()
        )

    output$median <- prepare.matrix( median.data[,grep("^([AI]G|UNI|HYC|BLANK)\\d+$",names(median.data))] )
    output$count <- prepare.matrix( count.data[,grep("^([AI]G|UNI|HYC|BLANK)\\d+$",names(count.data))] )
    output$hyb <- prepare.matrix( di0 <- ga.gamap::gamap( di0, start.from = "file",
                                                         stop.at = "hyb", batch=batch ) )

    output$qcc <- prepare.matrix( di0 <- ga.gamap::gamap( di0, start.from = "hyb",
                                                         stop.at = "qcc", batch=batch ) )

    output$batch <- prepare.matrix( di0 <- ga.gamap::gamap( di0, start.from = "qcc",
                                                           stop.at = "batch", batch=batch ) )

    output$bg <- prepare.matrix( di0 <- ga.gamap::gamap( di0, start.from = "batch",
                                                        stop.at = "bg", batch=batch ) )

    output$center <- prepare.matrix( di0 <- ga.gamap::gamap( di0, start.from = "bg",
                                                            stop.at = "center", batch=batch ) )

    output$scores <- prepare.matrix( di0 <- ga.gamap::gamap( di0, start.from = "center",
                                                            stop.at = "scores", batch=batch ) )

    t2res                                 <- di0 <- ga.gamap::gamap( di0, start.from = "scores",
                                                                    stop.at = "t2res", batch=batch )

    output$t2                             <- prepare.vector( t2res$T2 )
    output$qres                           <- prepare.vector( t2res$Qres )

    di                                    <- ga.gamap::gamap( di0, start.from = "t2res",
                                                             batch=batch, stop.at = "dysbiosis" )

    di.final                              <- prepare.vector( di )
    di.final[ di.final %in% "dysbiosis" ] <- "positive"

    output$diagnosis                      <- di.final

    ## 1: scaled T2 and Qres
    di.l                                  <- ga.data::dysbiosis.limits()
    di.t2.u                               <- t2res$T2 / di.l$T2
    di.qres.u                             <- t2res$Qres / di.l$Qres
    output$t2_scaled                      <- prepare.vector( di.t2.u )
    output$qres_scaled                    <- prepare.vector( di.qres.u )

    ## 2: radius
    parameters                            <- ga.data::numeric.di.parameters()
    t2.f <- parameters$t2.weight;
    qres.f <- parameters$qres.weight

    di.radius                             <- rep( NA, length(di) )
    mdi.p                                 <- sqrt( t2.f*di.t2.u**2 + qres.f*di.qres.u**2 )
    di.radius[ di.final %in% "positive" ] <- mdi.p[ di.final %in% "positive" ]
    mdi.n                                 <- sqrt( di.t2.u**2 + di.qres.u**2 )
    di.radius[ di.final %in% "negative" ] <- mdi.n[ di.final %in% "negative" ]

    output$radius                         <- prepare.vector( di.radius )

    ## 3: num di
    di.num0                               <- prepare.vector( ga.gamap::gamap( di, start.from = "dysbiosis",
                                                                             batch=batch ) )
    gr.zone <- c(
        parameters$greyzone.lower,
        parameters$greyzone.upper
        )

    i.in.greyzone                         <- change.na.to.false( di.num0 %between% gr.zone )

    output$DI_float                       <- di.num0

    ##
    output$greyzone                       <- i.in.greyzone
    output$DI_final                    <- integer.safe.for.c.sharp( ceiling(di.num0) )
    ##
    output$probe_level_names           <- bacteria.limits()$ProbeNo
    output$probe_levels                   <- prepare.matrix(
        ga.gamap::gamap.probe.levels( bc.file, batch=batch ) )

    ## QC
    output$QC                           <- qc.data( median.data, count.data, di.num0,
                                                   batch=batch )

    if( !missing(out.file) ) {

    }

    return( output )

}

##' prepare matrix
##'
##' Prepares a matrix or similar structure for json export,
##' essentially strips all uneccesary information and dimnames.
##' @title prepare matrix
##' @param mat matrix to prepare
##' @return matrix
##' @author Torbjørn Lindahl
##' @export
prepare.matrix <- function( mat ) {
    mat <- as.matrix( mat )
    dimnames( mat ) <- NULL
    attrs <- setdiff( names(attributes(mat)), "dim" )
    for( a in attrs )
      attr( mat, a ) <- NULL
    if( is.numeric( mat[,1] ) )
        mat[ is.na(mat) ] <- NaN
    return( mat )
}

##' prepare vector
##'
##' Prepares a vector for json export, see prepare.matrix
##' @title prepare.vector
##' @param vec vector to prepare
##' @return vector
##' @author Torbjørn Lindahl
##' @export
prepare.vector <- function( vec ) {
    names( vec ) <- NULL
    attrs <- names(attributes(vec))
    for( a in attrs )
      attr( vec, a ) <- NULL
    if( is.character( vec ) )
      vec[ is.na(vec) ] <- "NA"
    if( is.numeric( vec ) || is.integer( vec ) )
      vec[ is.na(vec) ] <- NaN
    return( vec )
}


change.na.to.false <- function(x) {
  x[ is.na(x) ] <- FALSE
  return( x )
}


integer.safe.for.c.sharp <- function(x) {
    x[is.na(x)] <- -1
    x <- as.integer(x)
    return( x )
}


##' @importFrom ga.utils "%between%"
##' @importFrom stats na.omit
##' @importFrom ga.gamapqc gamap.qc
qc.data <- function( plate.data, count.data, di.num, batch ) {

    qc.overall <- gamap.qc( plate.data, start.from = "file", batch=batch )
    qc.overall[ grepl( "^QCC",plate.data$Sample ) ] <- NA
    ## qc.overall[ is.na( qc.overall ) ] <- FALSE

    ## plate qc:

    qc.p <- ga.gamapqc:::gamap.qc.plate.qc( plate.data, count.data, di.num, skip.upper.hyc = TRUE )[[1]]
    err.nrs <- attr( qc.p, "ErrorNumbers" )
    err.msg <- attr( qc.p, "ErrorMessages" )
    if( length( err.nrs ) ) {
        err.nrs <- as.list( sprintf( "Err%02d", sort(err.nrs) ))
    } else {
        err.nrs <- list() ## this causes toJSON to produce []
    }
    qc.plate <- err.nrs

    ## sample qc:

    qc.s <- ga.gamapqc:::gamap.qc.sample.qc( plate.data, count.data, skip.upper.hyc = TRUE, qcc.is.na = TRUE )[[1]]
    err.nrs <- attr( qc.s, "err.nrs" )
    err.nrs[ grepl( "^QCC", plate.data$Sample ) ] <- NA
    err.msg <- attr( qc.s, "err.msg" )
    if( length( err.nrs ) ) {
        err.nrs <- lapply( err.nrs, function(e) as.list( sprintf( "Err%02d", sort(na.omit(e)) ) ) )
    }

    qc.sample <- err.nrs

    qc.list <- list(
      overall = prepare.vector(qc.overall),
      detailed = list(
        plate = qc.plate,
        sample = qc.sample
        )
      )

    return( qc.list )

}
