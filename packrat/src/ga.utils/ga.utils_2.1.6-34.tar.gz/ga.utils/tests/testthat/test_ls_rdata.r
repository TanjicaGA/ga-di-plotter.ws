library(ga.utils)

context("ls.rdata() lists var names from rdata files")

rdata.file <- tempfile( fileext=".RData" )
foo <- "bar"
baz <- "test"
save( file=rdata.file, foo )

test_that( "one var case works", {

  expect_that(
    ls.rdata( rdata.file ),
    is_identical_to( "foo" )
    )

})

save( file=rdata.file, foo, baz )

test_that( "two var case works", {

  expect_that(
    sort(ls.rdata( rdata.file )),
    is_identical_to( sort(c("foo","baz")) )
    )

})

unlink(rdata.file)
