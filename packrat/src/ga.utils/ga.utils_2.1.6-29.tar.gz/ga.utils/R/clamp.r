##' Clamp values to a given range
##'
##' Clamp values to a given range, that is, change any values in the
##' input vector to be the lowest value of the range if they are
##' lower, and change any values higher to now be the upper value of
##' the range.
##' @title Clamp
##' @return vector with clamped values
##' @author Torbjørn Lindahl
##' @param x Values to clamp
##' @param rng Range to clamp to
##' @export
clamp <- function( x, rng ) {

    rn <- range(rng,na.rm=TRUE)

    x[ x < rn[1] ] <- rn[1]
    x[ x > rn[2] ] <- rn[2]

    return( x )

}
