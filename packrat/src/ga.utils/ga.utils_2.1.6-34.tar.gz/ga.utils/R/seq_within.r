##' sequence for each distinct value
##'
##' Creates independent sequences for each unique value within x
##' @title sequences within
##' @return numeric
##' @author Torbjørn Lindahl
##' @param ... vectors and/or vlaues to create sequences numbers within
##' @param center default TRUE, centers around 0
##' @export
seq_within <- function(..., center=FALSE) {

    x <- c(...)
    v <- rep( NA_integer_, length(x) )

    for( e in unique(x) ) {
        if( is.null(e) )
            v[ j <- sapply( x, is.null ) ] <- 1:sum( sapply( x, is.null ) )
        else if( is.na(e) )
            v[ j <- is.na(x) ] <- 1:sum(is.na(x))
        else
            v[ j <- x %in% e ] <- seq_along( x[ x %in% e ] )

        if( center )
            v[ j ] <- scale( v[j], scale=FALSE )

    }

    return( v )

}
