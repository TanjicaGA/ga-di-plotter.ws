##' Probe levels used on report
##'
##' Probe levels used on report
##' @title Probe levels
##' @param bact.re bacteria to search for
##' @param before.center logical default FALSE, report values
##'     corresponding to the centering step of the algorithm
##' @param use.old use the old 15-profile limits. Deprecated, use the
##'     revision argument instead (use.old=TRUE would correspond to
##'     revision="rev1")
##' @param revision rev1, rev2 or rev3. Marks which revision of
##'     bacteria limits to return.
##' @return list with probe levels
##' @author Torbjørn Lindahl
##' @aliases probe.limits
##' @export
bacteria.limits <- function( bact.re, before.center=FALSE, use.old, revision="rev3" ) {

    if( !missing(use.old) ) {
        warning( "the 'use.old' argument is deprecated, use revision='rev1' instead" )
        if( use.old && missing(revision) ) {
            revision <- "rev1"
        }
    }

    revision <- match.arg( revision, choices = c("rev3","rev2","rev1") )

    ## imported from json file
    if( revision == "rev1" ) {
        bl <- bacteria.limits.table.revision1
    } else if( revision == "rev2" ) {
        bl <- bacteria.limits.table.revision2
    } else if( revision == "rev3" ) {
        bl <- bacteria.limits.table.revision3
    }

    if( before.center ) {
        cv <- model.pca()$center
        i <- match( bl$Probe, names(cv) )
        j <- grepl( "^(\\-|\\+)[1-3]$", colnames(bl) )
        bl[,j] <- sweep( bl[,j], 1, cv[i], FUN="+" )
    }

    if( !missing( bact.re ) ) {
        i <- grep( bact.re, bl$Bacteria, ignore.case=TRUE )
        bl <- bl[i,]
    }

    return( bl )

}

##' Index on profile of the 39 probes on report
##'
##' Index on profile of the 39 probes on report
##' @title Index of 39 report probes
##' @return index of 39 report probes
##' @author Torbjørn Lindahl
##' @param probes Probes to match, defaults to the full IBS3 set
##' @param use.old Report probes listed on the report that showed only
##'     15 probes. Otherwise report the current 39 probes.
##' @export
probe.index.on.report <- function( probes, use.old=FALSE ) {

    if( use.old )
        d <- bacteria.limits.table.revision1
    else
        d <- bacteria.limits.table.revision3

    if( missing( probes ) )
        probes <- probe.set("ibs3", type="code")

    ## match with the profile
    m <- match( d$Probe, probes )

    if( anyNA(m) )
      stop("Internal error: Some of the report probes are not found in profile")

    return( m )

}
