##' Look up translated values
##'
##' Looks for occurences of x in any of the columns, returns the
##' corresponding value in the other column. Assumes two columns.
##' @title Translate values from a table
##' @param x look up which values
##' @param db table to look them up in
##' @param from column number or name, force look for values here
##' @param to column number or name, return matches in this column
##' @param leave.unfound don't change values that are not found
##'     (otherwise NA)
##' @param allow.many logical default FALSE, allow many matches per
##'     input value
##' @return vector of looked up varclues
##' @author Torbjørn Lindahl
##' @export
look.up <- function(x, db, from, to, leave.unfound=TRUE,
                    allow.many=FALSE
                    ) {

    db <- as.data.frame( db )

    if( any( sapply( db, is.factor ) ) ) {
        warning("There are factors in the look up table, this is likely not necessarya and will likely not result in what you want")
    }

    if( anyDuplicated(db) ) {
        warning("Duplicate rows found in db - removing")
        db <- db[!duplicated(db),]
    }

    if(!is.null(dim(x)))
      stop( "x needs to be a vector" )

    if(is.null(dim(db)))
      stop( "x needs to be a 2D object" )

    if( missing(from) )
      from <- which.max( apply(
        db, 2, function(v)sum( x %in% v, na.rm=TRUE ) ) )

    if( anyDuplicated(from) )
      stop( "Duplicates found in 'from column'" )

    if( missing(to) ) {

        if( ncol(db) != 2 ) {
            stop("Can only have 2 columns in lookup table if 'to column' is not specified")
        }

        to <- setdiff( 1:ncol(db), from )

    }

    if( allow.many ) {
        m <- which( db[,from] %in% x )
    }
    else {
        m <- match( x, db[,from] )
    }

    v <- db[m,to]


    if(anyNA(m) && leave.unfound )
      v[is.na(m)] <- x[is.na(m)]

    return( v )

}
