library(ga.utils)

context( "clever checks for truthy" )

test_that( "falsy values are false", {

    expect_false( truthy() )
    expect_false( truthy(NULL) )
    expect_false( truthy( character() ) )
    expect_false( truthy( "" ) )
    expect_false( truthy( numeric() ) )
    expect_false( truthy( 0 ) )
    expect_false( truthy( "0" ) )
    expect_false( truthy( "00" ) )
    expect_false( truthy( "0.0" ) )
    expect_false( truthy( FALSE ) )
    expect_false( truthy( list() ) )

})

test_that( "na is NA", {

    expect_true( is.na( truthy(NA) ) )
    expect_true( is.na(  falsy(NA) ) )

    expect_true( is.na( truthy(NA_character_) ) )
    expect_true( is.na(  falsy(NA_character_) ) )

    expect_true( is.na( truthy(NA_integer_) ) )
    expect_true( is.na(  falsy(NA_integer_) ) )

    expect_true( is.na( truthy(NA_real_) ) )
    expect_true( is.na(  falsy(NA_real_) ) )

})

test_that( "truish values are true", {

    expect_true( truthy( "abc" ) )
    expect_true( truthy( 1 ) )
    expect_true( truthy( 10 ) )
    expect_true( truthy( "1" ) )
    expect_true( truthy( " 1" ) )
    expect_true( truthy( "01" ) )
    expect_true( truthy( "1e-20" ) )
    expect_true( truthy( "2" ) )
    expect_true( truthy( "true" ) )
    expect_true( truthy( "TRUE" ) )
    expect_true( truthy( "TrUe" ) )
    expect_true( truthy( TRUE ) )

    expect_true( truthy( "false" ) )
    expect_true( truthy( "FALSE" ) )
    expect_true( truthy( "FalSe" ) )

    expect_true( truthy( "no" ) )
    expect_true( truthy( "NO" ) )
    expect_true( truthy( "nO" ) )

})
