##' bacteria table for abundance analyzer
##'
##' Calculates the bacteria table using the algorithm for the
##' abundance analyzer
##' @title abundance analyzer bacteria table
##' @return returns bacteria table results
##' @author Torbjorn Lindahl
##' @importFrom ga.gamap gamap.probe.levels
##' @param ... arguments to \link{gamap.probe.levels}
##' @param kitlot kitlot to use
##' @export
aa.bacteria.table <- function( ..., kitlot ) {

    args <- list( ... )
    args$check.at.qcc29.corrected.before.batch <- TRUE
    args$qcc29.correction.variant <- "aa"
    args$batch <- kitlot

    if( !is.null(args$bacteria.table.revision) ) {

        if( is.character(args$bacteria.table.revision) && args$bacteria.table.revision %~% "^rev[1-3]" ) {
            warning("Cannot use bacteria table revisions 1 to 3 for the AA calculation.")
            args$bacteria.table.revision <- NULL
        }

    }

    do.call( gamap.probe.levels, args )

}
