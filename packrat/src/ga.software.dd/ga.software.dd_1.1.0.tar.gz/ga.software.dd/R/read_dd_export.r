##' read dd export
##'
##' Reads the file, extracting the csv matrix with the header and crc
##' sum as additional attributes.
##' @title read a file exported per the DD spec
##' @param filename file to read
##' @param require.crc.check default TRUE, check that the CRC checksum
##'     matches. If set to FALSE this check will still result in a
##'     warning if the checksum does not match.
##' @return data.frame with content
##' @author Torbjørn Lindahl
##' @importFrom readr read_file
##' @importFrom stringr str_match
##' @importFrom utils read.csv
##' @importFrom digest digest
read.dd.export <- function( filename, require.crc.check=TRUE ) {

    content <- read_file( filename )

    i.begin <- regexpr('(?<=\\n\\n)"Sample",', content, perl=TRUE )
    i.end <- regexpr( '(?<=\\n\\n)-- CRC --\n', content, perl=TRUE )-1

    con <- textConnection( substr(content, i.begin, i.end) )
    on.exit(close(con))
    d.result <- read.csv( file=con, header=TRUE )

    con2 <- textConnection( substr(content, 1, i.begin-1) )
    on.exit(close(con2))
    d.header <- read.csv( file=con2, header=TRUE )

    d.header <- t(d.header)

    crc32 <- str_match( content, "CRC32: (\\S+)" )[,2]

    attr( d.result, "header" ) <- d.header
    attr( d.result, "crc32" ) <- crc32

    d.result

}
