## SPECIFIC BCF ALGORITHMS

##' Batch correct with log and scale
##'
##' Batch correct data after log transform, rescaling, and anti log.
##' @title batch correct with recentering after log transform
##' @param old old qcc30 data
##' @param new new qcc30 data
##' @param dont.check dont check qcc data
##' @return list with model parameters
##' @author Torbjørn Lindahl
##' @importFrom stats sd
batch.correction.log.scale <- function( old, new, dont.check=FALSE ) {

    if( !dont.check ) {
        old <- check.qcc30.data(old)
        new <- check.qcc30.data(new)
    }

    stopifnot( identical( dimnames(old), dimnames(new) ) )

    old <- log(old)
    new <- log(new)

    m.old <- colMeans( old, na.rm=TRUE )
    m.new <- colMeans( new, na.rm=TRUE )
    s.old <- apply( old, 2, sd, na.rm=TRUE )
    s.new <- apply( new, 2, sd, na.rm=TRUE )

    shr <- s.old / s.new
    sft <- exp( m.old - m.new/s.new*s.old )

    return( list(
      coefficients = rbind( shr, sft ),
      type="log.scale"
      ))

}

##' Anova batch correction
##'
##' Old type batch correction, a simple difference
##' @title Anova batch correction
##' @param old old qcc30 data
##' @param new new qcc30 data
##' @param dont.check dont check the input qcc30 normalized data for having 54 columns
##' @return list with model parameters
##' @author Torbjørn Lindahl
batch.correction.difference <- function( old, new, dont.check=FALSE ) {

    if(!dont.check) {
        old <- check.qcc30.data(old)
        new <- check.qcc30.data(new)
    }

    stopifnot( identical( dimnames(old), dimnames(new) ) )

    v <- colMeans( new - old, na.rm=TRUE )
    return(
      list(
        coefficients=v,
        type="difference"
        ))
}

##' Minimize ratio
##'
##' Minimizes ratio
##' @title minimize ratio
##' @param old old qcc30 data
##' @param new new qcc30 data
##' @return list with model parameters
##' @author Torbjørn Lindahl
##' @importFrom stats coef
batch.correction.ratio <- function( old, new ) {

    old <- check.qcc30.data(old)
    new <- check.qcc30.data(new)

    stopifnot( identical( dimnames(old), dimnames(new) ) )

    v <- colMeans( log(old) - log(new), na.rm=TRUE )

    i <- 1 ## check() othewise reports a warning
    cf2 <- foreach( i=seq_along(v), .combine = c ) %do% {
        r <- v[i]
        m <- nlsLM(
            o~n*r,
            start=list(r=r),
            trace=FALSE,
            data=data.frame(
                o = old[,i], n=new[,i]
            )
        )
        coef(m)[1]
    }
    names(cf2) <- names(v)

    return(
      list(
        coefficients=cf2,
        type="ratio"
        ))
}

##' Log scale with minimization
##'
##' Minimizes the default coefficients from log scale correction
##' @title Log scaled and minimized batch correction
##' @param old old qcc30 data
##' @param new new qcc30 data
##' @param dont.check dont check qcc data
##' @return list with model parameters
##' @author Torbjørn Lindahl
##' @importFrom foreach "%do%"
##' @importFrom foreach foreach
##' @importFrom minpack.lm nlsLM
batch.correction.exponential <- function( old, new, dont.check=FALSE ) {

    if( !dont.check ) {
        old <- check.qcc30.data(old)
        new <- check.qcc30.data(new)
    }

    stopifnot( identical( dimnames(old), dimnames(new) ) )

    l <- batch.correction.log.scale( old, new, dont.check=dont.check )
    cf <- l$coefficients

    i <- 1 ## check() othewise reports a warning
    cf2 <- foreach( i=1:ncol(cf), .combine=cbind ) %do% {
        sft0 <- cf["sft",i]
        shr0 <- cf["shr",i]
        m <- nlsLM(
            o~sft*n**shr,
            start=list(sft=sft0, shr=shr0 ),
            trace=FALSE,
            control=list( maxiter=200 ),
            data=data.frame(
                o = old[,i], n=new[,i]
                )
        )
        coef(m)[c("shr","sft")]
    }
    dimnames(cf2) <- dimnames(cf)

    l$coefficients <- cf2
    l$type <- "exponential"

    return( l )

}
