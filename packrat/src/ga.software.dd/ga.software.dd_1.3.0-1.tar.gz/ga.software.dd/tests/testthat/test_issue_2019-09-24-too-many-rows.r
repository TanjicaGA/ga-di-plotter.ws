library(ga.software.dd)
library(testthat)
library(ga.gamap)

options( stringsAsFactors=FALSE )

context( "issue 2019-09-24 too many rows" )

tf <- normalizePath( "data/issues/2019-09-24/TestFile-012-L1801.csv" )

test_that( "it doesnt create too many rows", {

    x <- dd.export.csv( tf, kitlot="L1801", path=NA )
    l <- gamap( tf, stop.at="file" )
    set.qcc.indeces(l,verbose=FALSE)

    expect_equal( nrow(x), sum(!i.qcc | i.qcc23 | i.qcc33) )

})
