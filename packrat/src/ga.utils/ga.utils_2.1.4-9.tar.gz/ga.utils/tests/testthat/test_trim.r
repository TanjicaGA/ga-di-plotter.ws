library(ga.utils)

context( "trim" )

test_that( "normal input works", {

    ## simple spaces
    expect_equal( trim("foo"), "foo" )
    expect_equal( trim(" foo"), "foo" )
    expect_equal( trim("foo "), "foo" )
    expect_equal( trim(" foo "), "foo" )

    ## more values
    expect_equal( trim(c(" foo "," bar ")), c("foo","bar") )

    ## different ws
    expect_equal( trim("\tfoo"), "foo" )
    expect_equal( trim("foo\n"), "foo" )
    expect_equal( trim(" \t\nfoo\t \n"), "foo" )

    ## different re
    expect_equal( trim("oofoo", ws.re="oo"), "f" )

})

test_that( "odd input works", {

    ## NA and NULL
    expect_true( is.na(trim(NA)) )
    expect_equal( trim(NULL), character() )

    ## A number
    expect_equal( trim(4), "4" )

})
