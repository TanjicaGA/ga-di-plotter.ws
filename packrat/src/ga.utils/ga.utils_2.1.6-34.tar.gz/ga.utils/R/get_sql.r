##' Quick way to perform a SQL query
##'
##' This function sends a query to a connected database through its
##' handle. It knows differet drivers and takes care to use the proper
##' methods for each of them.
##' @title Send query to db and return result
##' @param dbh Database connection handle
##' @param query SQL query
##' @param ... Additional arguments to DBI::fetch
##' @return dataframe with result of query
##' @author Torbjørn Lindahl
##' @importFrom DBI dbSendQuery
##' @importFrom DBI fetch
##' @importFrom DBI dbClearResult
##' @importFrom RODBC sqlQuery
##' @export
get.sql <- function( dbh, query, ... ){

    if( inherits( dbh, "PostgreSQLConnection" ) ){

        sth <- dbSendQuery( dbh, query )
        sql.data <- try( fetch( sth, n=-1, ... ), silent=TRUE )

        if( inherits( sql.data, "try-error" ) ) {
            if( grepl( "not.*SELECT", attr( sql.data, "condition" )$message )) {
                sql.data <- NULL
            }
        }
        dbClearResult( sth )

    }
    else if( inherits( dbh, "SQLiteConnection" ) ){

        sth <- dbSendQuery( dbh, query )
        sql.data <- try( fetch( sth, n=-1, ... ), silent=TRUE )
        ## if( inherits( sql.data, "try-error" ) )
        ##   sql.data <- NULL
        dbClearResult( sth )

    }
    else if( inherits( dbh, "RODBC" ) ){

        sql.data <- sqlQuery( dbh, query )

    }
    else {

        stop("Unkonwn database handle")

    }

    return( sql.data )

}
