library(ga.utils)

test.func <- function( x, y ) {
    y %?<-% "a missing default"
    return( list(x,y) )
}

context( "No missing values" )

test_that( "Original values are left alone", {

    expect_equal( test.func(1,2), list(1,2) )
    expect_equal( test.func(y=4,x=3), list(3,4) )

})

context( "One missing value" )

test_that( "Missing values have a default", {

    expect_equal( test.func(1), list(1,"a missing default") )
    expect_equal( test.func(x=3), list(3,"a missing default") )

})

context( "Error when error due" )

test_that( "Missing without defaults give error", {

    expect_error( test.func() )
    expect_error( test.func(y=2) )

})
