##' Read entire file
##'
##' Reads all content from a given file or connection and returns it
##' @title Read entire file
##' @param file.name File to read
##' @return File contents in one character
##' @author Torbjørn Lindahl
##' @export
read.file <- function( file.name ){
    .Deprecated("Use readr::read_file instead")
    return( paste( readLines( file.name, warn=F ), collapse="\n" ) )
}
