library(ga.gamap)
library(ga.data)

lx200.file <- file.path( "data", "Lx200-TestfileC.csv" )

context( "gamap step 1 - read lx200 file" )

test_that( "files are read", {

    step1 <- gamap( lx200.file, stop.at = "file", batch="PS1702" )

    expect_is( step1, "data.frame" )
    expect_equal( dim(step1), c(72,68) )

    expect_equal(
      gamap( lx200.file, stop.at = "file", start.with = "file", batch="PS1702" ),
      step1
      )

    expect_true( "count" %in% names(attributes(step1)))

})

context( "gamap step 2 - probe data" )

test_that( "raw data is ok", {

    step2 <- gamap( lx200.file, stop.at = "raw", batch="PS1702" )
    expect_is( step2, "matrix" )
    expect_equal( dim(step2), c(72,54) )

    expect_equal(
      gamap( lx200.file, stop.at = "raw", start.with = "file", batch="PS1702" ),
      step2
      )

})

context( "gamap step 3 - hyb adjusted" )

test_that( "hyc adjustment works", {

    step3 <- gamap( lx200.file, stop.at = "hyb", batch="PS1702" )
    expect_is( step3, "matrix" )
    expect_equal( dim(step3), c(72,54) )

    expect_equal(
      gamap( lx200.file, stop.at = "hyb", start.with = "file", batch="PS1702" ),
      step3
      )

})

context( "gamap step 4 - qcc30 adjusted" )

test_that( "qcc30 adjustment works", {

    step4 <- gamap( lx200.file, stop.at = "qcc", batch="PS1702" )
    expect_is( step4, "matrix" )
    expect_equal( dim(step4), c(72,54) )

    ## j <- grep("QCC30", rownames(step4) )
    ## print( attr( step4, "TotalSignal" )[j] )

    m <- match( lx200.missing.probes(colnames(step4)),colnames(step4))

    ## there shouldn't be any NA's at this point for the other probes
    ## that are included
    expect_true( !any(is.na(step4[,-m])))

})

context( "gamap step 5 - batchcorrected" )

test_that( "batchcorrection works", {

    step5 <- gamap( lx200.file, stop.at = "batchadjusted", batch="PS1702" )
    expect_is( step5, "matrix" )
    expect_equal( dim(step5), c(72,54) )

    ## at this point there shouldn't be any NA's at all
    expect_true( !anyNA( step5 ) )

})

context( "gamap step 6 - bg" )

test_that( "bg adjustement works", {

    step6 <- gamap( lx200.file, stop.at = "bg", batch="PS1702" )
    expect_is( step6, "matrix" )
    expect_equal( dim(step6), c(72,54) )

})

context( "gamap step 7 - center" )

test_that( "centering works", {

    step7 <- gamap( lx200.file, stop.at = "center", batch="PS1702" )
    expect_is( step7, "matrix" )
    expect_equal( dim(step7), c(72,54) )

})

context( "gamap step 8 - scores" )

test_that( "scores calc works", {

    step8 <- gamap( lx200.file, stop.at = "scores", batch="PS1702" )
    expect_is( step8, "matrix" )
    expect_equal( dim(step8), c(72,15) )

})

context( "gamap step 9 - T2/Qres" )

test_that( "t2qres calc works", {

    step9 <- gamap( lx200.file, stop.at = "t2res", batch="PS1702" )
    expect_is( step9, "data.frame" )
    expect_named( step9, c("T2","Qres","Sample"), ignore.order = TRUE )
    expect_is( step9$T2, "numeric" )
    expect_is( step9$Qres, "numeric" )

})

context( "gamap step 10 - di class" )

test_that( "di result is right", {

    step10 <- gamap( lx200.file, stop.at = "dysbiosis", batch="PS1702" )
    expect_is( step10, "character" )

    expect_equal(
      as.numeric(table(step10)),
      c(51,21) ## 51 dysbiotic, 21 normobiotic
      )

})

context( "gamap step 11 - numeric di" )

test_that( "numeric di is right", {

    target.din <- structure(c(4.99894224079093, 4.16494333111349,
                              4.1665894406176, 0.69879154410666,
                              1.41663888494298, 1.81772981595281,
                              4.81404914393752, 4.19763212059803,
                              4.99555448626418, 4.21269944979505,
                              3.27345483587335, 2.23170895500768,
                              2.54443310759724, 1.74087639864063,
                              4.68145717897656, 3.34096620026178,
                              4.99773535895294, 4.17710363056874,
                              3.94265138371621, 0.864536045098432,
                              1.41852606997254, 1.79519783011652,
                              4.74248220365579, 4.01514293555309,
                              4.99857699737354, 4.17272515408448,
                              4.02669234737112, 0.797198382505491,
                              1.44877848158411, 1.76027369685285,
                              4.78095617874101, 4.20899641987011,
                              4.99588138401816, 4.20918172443523,
                              3.166299642609, 2.22479143530845,
                              2.57458052715818, 1.72277670595168,
                              4.57291917389411, 3.36303435351211,
                              4.997792356077, 4.16925978230173,
                              4.05055638319502, 0.932872673070399,
                              1.47462538495726, 1.77418385196103,
                              4.73722111908717, 4.01892392582965,
                              4.9981448372678, 4.16361641599336,
                              4.04545121879032, 0.804605657448809,
                              1.53425348370163, 1.81892392552886,
                              4.74264449541547, 4.14639076977557,
                              4.99495546912602, 4.20335180707236,
                              3.01123323888428, 2.18590456211004,
                              2.57418017692496, 1.7735179665778,
                              4.56905957528151, 3.27686285856967,
                              4.99686641794901, 4.16094520460141,
                              3.80304049725346, 0.739905100760161,
                              1.4437344650134, 1.6582305913617,
                              4.65994707152592, 3.95536632633306),
                            .Names = c("QCC30_A_5", "QCC29_A_5",
                                       "QCC23_A_5", "QCC33_A_5",
                                       "S1a_5", "S2a_5", "S3a_5",
                                       "S4a_5", "QCC30_A_6",
                                       "QCC29_A_6", "QCC23_A_6",
                                       "QCC33_A_6", "S1a_6", "S2a_6",
                                       "S3a_6", "S4a_6", "QCC30_A_4",
                                       "QCC29_A_4", "QCC23_A_4",
                                       "QCC33_A_4", "S1a_4", "S2a_4",
                                       "S3a_4", "S4a_4", "QCC30_B_5",
                                       "QCC29_B_5", "QCC23_B_5",
                                       "QCC33_B_5", "S1b_5", "S2b_5",
                                       "S3b_5", "S4b_5", "QCC30_B_6",
                                       "QCC29_B_6", "QCC23_B_6",
                                       "QCC33_B_6", "S1b_6", "S2b_6",
                                       "S3b_6", "S4b_6", "QCC30_B_4",
                                       "QCC29_B_4", "QCC23_B_4",
                                       "QCC33_B_4", "S1b_4", "S2b_4",
                                       "S3b_4", "S4b_4", "QCC30_C_5",
                                       "QCC29_C_5", "QCC23_C_5",
                                       "QCC33_C_5", "S1c_5", "S2c_5",
                                       "S3c_5", "S4c_5", "QCC30_C_6",
                                       "QCC29_C_6", "QCC23_C_6",
                                       "QCC33_C_6", "S1c_6", "S2c_6",
                                       "S3c_6", "S4c_6", "QCC30_C_4",
                                       "QCC29_C_4", "QCC23_C_4",
                                       "QCC33_C_4", "S1c_4", "S2c_4",
                                       "S3c_4", "S4c_4"))

    din <- gamap( lx200.file, stop.at = "numeric", batch = "PS1702" )

    expect_equivalent(
      din,
      target.din
      )

})
