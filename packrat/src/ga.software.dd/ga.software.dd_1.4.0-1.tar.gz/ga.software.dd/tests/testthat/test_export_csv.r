library(ga.software.dd)
library(ga.data)
library(ga.utils)
library(ga.gamap)
library(readr)
library(stringr)

options( stringsAsFactors=FALSE )

context( "export csv" )

tf1 <- normalizePath( "data/lx200-files/TestFile-01.csv" )

wd <- getwd()

test_that( "it can export csv per spec", {

    dir.create( td <- tempfile() )
    setwd(td)

    dd1 <- dd.export.csv( tf1, kitlot="L1902", path=NA )
    ## no files there, since nothing got written
    expect_length( dir(td), 0 )

    dd2 <- dd.export.csv( tf1, kitlot="L1902" )
    ## now there is a file there
    expect_length( dir(td), 1 )

    written.file <- dir(td)

    content <- read_file( written.file )
    i.begin <- regexpr('(?<=\\n\\n)"Sample",', content, perl=TRUE )
    i.end <- regexpr( '(?<=\\n\\n)-- CRC --\n', content, perl=TRUE )-1

    con <- textConnection( substr(content, i.begin, i.end) )
    on.exit(close(con))

    ff2 <- read.csv( written.file, nrows=4, header=FALSE )

    ## check that the auto generated filename is based on the input file
    expect_match( ff2[,2][ ff2[,1] == "Filename" ], sub( "\\.csv$", "", basename(tf1), ignore.case=TRUE ) )
    ## check that the rundate is right
    expect_equal( ff2[,2][ ff2[,1] == "Rundate" ], paste(rundate(tf1)) )
    ## and the kitlot
    expect_equal( ff2[,2][ ff2[,1] == "Kitlot" ], "L1902" )
    ## and that it has an AppVersion
    expect_match( ff2[,2][ ff2[,1] == "AppVersion" ], "." )

    ff2.b <- read.csv( file=con )

    colnames(ff2.b) <- sub("^X","",colnames(ff2.b))

    expect_true( all( c("Sample","DI","QC","QCtext") %in% names(ff2.b) ) )
    expect_true( all( probe.numbers(bacteria.limits()$Probe) %in% names(ff2.b) ) )

    pr <- bacteria.limits()$Probe

    di.plate <- gamap( tf1, batch="L1902", stop.at="file" )
    din <- gamap( di.plate, batch="L1902", start.from="file" )

    set.qcc.indeces( di.plate, verbose=FALSE, postfix=".2" )
    jj <- !i.qcc30.2 & !i.qcc29.2

    pn <- paste(probe.numbers(pr))

    expect_equivalent(
        as.matrix( ff2.b[, pn ] ),
        gamap.probe.levels( tf1, batch="L1902" )[ jj, ]
    )

    expect_equal(
        ff2.b[, colnames(ff2.b) %!in% pn ],
        data.frame(
            Sample = di.plate$Sample[jj],
            DI = din[jj],
            QC = rep( TRUE, sum(jj)),
            QCtext = rep( NA, sum(jj)),
            row.names=NULL
        )
    )

    ## data sets should be unaffected about how they might or might
    ## not be written to disk

    ## take away the crc32 attribute and compare them
    attr( dd2, "crc32" ) <- NULL
    expect_equal( dd1, dd2 )

    ## with a custom filename
    dd3 <- dd.export.csv( tf1, kitlot="L1902", path="./foo.csv" )

    attr( dd3, "crc32" ) <- NULL
    expect_equal( dd1, dd3 )

    ff3 <- read.csv( file="foo.csv", nrows=4, header=FALSE )
    ff3.b <- read.table( file="foo.csv", skip=5, nrows=8, sep=",", stringsAsFactors=FALSE, header=TRUE )

    attr( ff3.b, "crc32" ) <- NULL

    colnames(ff3.b) <- sub("^X","",colnames(ff3.b))

    expect_equal( ff2, ff3 )
    expect_equal( ff2.b, ff3.b )

    setwd( wd )
    if( unlink( td, recursive=TRUE ) != 0 ) {
        warning( "Failed cleaning up tmp dir ", td )
    }

    ## check the crc32
    f <- tempfile()
    cat( substr( content, 0, i.end ), file=f )

    crc32.ctrl.calc.from.file <- toupper( str_pad( digest( f, file=TRUE, algo="crc32" ), width=8, pad="0" ) )
    crc32.ctrl.calc.from.mem <- toupper( str_pad( digest( substr( content, 0, i.end ), algo="crc32", serialize=FALSE ), width=8, pad="0" ) )

    crc32.in.file <- str_match( content, "CRC32: (\\S+)" )[,2]

    unlink(f)

    expect_equal( crc32.ctrl.calc.from.file, crc32.in.file )
    expect_equal( crc32.ctrl.calc.from.mem, crc32.in.file )

})
