##' Genus annotations for GAmap
##'
##' Genus annotations for GAmap, that is, every probe down to genus
##' level or species leve if already on the report form
##' @title genus annotations
##' @return 54 element character vector of genus annotations for gamap
##' @author Torbjørn Lindahl
##' @export
##' @param strip.indicator remove trailing taxon indicator
##' @param uniquify add a counter to repeated terms to make them unique
genus.annotations <- function( strip.indicator=TRUE, uniquify=FALSE ) {
    ann <- c(
        "Anaerotruncus [g]",
        "Bacteroides fragilis [s]",
        "unclassified Clostridiales [f]",
        "Bacteroides [g]",
        "Bacteroides [g]",
        "Clostridium [g]",
        "Dorea [g]",
        "Eubacterium [g]",
        "Eubacterium [g]",
        "Ruminiclostridium [g]",
        "Faecalibacterium prausnitzii [s]",
        "Parabacteroides [g]",
        "Ruminococcus gnavus [s]",
        "Streptococcus [g]",
        "Acinetobacter [g]",
        "Akkermansia muciniphila [s]",
        "Bacillus [g]",
        "Bacteroides [g]",
        "Bifidobacterium [g]",
        "Catenibacterium [g]",
        "Ruminiclostridium [g]",
        "Dialister invisus [s]",
        "Megasphaera [g], Dialister [g]",
        "Holdemanella [g]",
        "Lachnospiraceae [f], Clostridiaceae [f], Eubacteriaceae [f]",
        "Lactobacillus [g]",
        "Pediococcus [g], Lactobacillus [g]",
        "Parabacteroides [g]",
        "Prevotella [g]",
        "Ruminococcus albus [s] / bromii [s]",
        "Alistipes [g]",
        "Alistipes [g]",
        "Pseudomonas [g]",
        "Atopobium [g]",
        "Desulfitispora [g]",
        "Coprobacillus [g]",
        "Phascolarctobacterium [g]",
        "Mycoplasma [g]",
        "Proteobacteria [ph]",
        "Salmonella [g],  Citrobacter [g], Enterobacter [g], Cronobacter [g]",
        "Bacilli [cl]",
        "Streptococcus sanguinis [s] & thermophilus [s]",
        "Clostridia [cl], Negativicutes [cl], Bacilli [cl]",
        "Actinobacteria [cl]",
        "Clostridia [cl], Veillonella [g], Helicobacter [g]",
        "Lactobacillus [g]",
        "Clostridia [cl], Negativicutes [cl]",
        "Bacteroides [g], Prevotella [g]",
        "Firmicutes [ph], Tenericutes [ph], Bacteroidetes [ph]",
        "Streptococcus [g]",
        "Streptococcus [g], Eubacterium [g]",
        "Shigella [g], Escherichia [g]",
        "Streptococcus [g]",
        "Actinomycetales [o]"
    )
    if( strip.indicator ) {
        ann <- gsub( " *\\[(?:ph|g|s|f|cl|o)\\]", "", ann, perl=TRUE )
        ann <- gsub( "\\s{2,}", " ", ann )
    }
    if( uniquify ) {
        for( n in  unique( ann[ duplicated(ann) ] ) ) {
            i <- which( ann == n )[-1]
            ann[i] <- paste( ann[i], 1+(1:length(i)) )
        }
    }
    return( ann )

}
