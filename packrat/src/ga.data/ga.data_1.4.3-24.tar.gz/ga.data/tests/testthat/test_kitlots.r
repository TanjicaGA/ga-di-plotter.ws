library(ga.data)

context( "kitlot re" )

test_that( "the kitlot regexp works", {

    expect_true( grepl( kitlot_re(), "K1404" ) )
    expect_true( grepl( kitlot_re(), "L1701" ) )
    expect_false( grepl( kitlot_re(), "K14041" ) )
    expect_false( grepl( kitlot_re(), "M14041" ) )

})

test_that( "validate kitlots works", {

    expect_true( validate_kitlots("K1404") )
    expect_true( all(validate_kitlots("K1404","K1408")) )

    expect_false( validate_kitlots("J1404", error=FALSE) )
    expect_equal( validate_kitlots(c("J1404","K1408"),error=FALSE), c(FALSE,TRUE) )

    expect_error( validate_kitlots(c("J1404","K1408")), "J1404" )
    expect_error( validate_kitlots("J1404"), "J1404" )

})
