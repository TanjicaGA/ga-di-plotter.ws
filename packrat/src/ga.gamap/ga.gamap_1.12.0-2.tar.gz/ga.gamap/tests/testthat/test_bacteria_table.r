library(ga.gamap)
library(ga.utils)

biocode.file <- file.path( "data", "Q2-005-K1515_II-BC1511.csv" )

context( "bacteria levels" )

test_that( "bacteria levels are right", {

    bt <- gamap.probe.levels( biocode.file, batch="PS1512", use.bacteria.names = FALSE, bacteria.table.revision="rev3" )

    expect_true( !is.null( dim(bt) ) )
    expect_equal( ncol(bt), 39 )
    expect_true( all( grepl("^[AI]G\\d{4}", colnames(bt) ) ) )

    bt0 <- load.get(
        "data/bacteria_levels_data_q2005_k1515.RData",
        verbose=FALSE )

    expect_equal(
        bt, bt0
        )

})
