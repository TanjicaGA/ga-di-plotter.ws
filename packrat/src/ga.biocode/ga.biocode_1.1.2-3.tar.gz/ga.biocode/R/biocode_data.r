##' Extracts probe data from a data.frame
##'
##' Extracts the probe data from a data.frame read from a biocode file
##' with read.biocode
##' @title Extract brobe data
##' @param raw.biocode.data biocode data
##' @param name.fix logical, should basic name-fixing be applied
##' @param hyc logical, should data be hyc adjusted
##' @param qcc logocal, should data be qcc30 normalized
##' @param qcc.name character, name of the qcc30 sample
##' @param hyc.name character, name of the hyc01 probe
##' @param translate logical, translate probe names
##' @param control.probes character name of control probes to remove,
##'     defaults to UNI05, BLANK1 and BLANK2
##' @param remove.control.probes logical, should control.probes be
##'     removed
##' @return matrix with probe data
##' @author Torbjørn Lindahl
##' @export
##' @importFrom stats median
biocode.data <- function( raw.biocode.data,
                         name.fix=TRUE, hyc=TRUE, qcc=TRUE,
                         qcc.name="QCC30",
                         hyc.name="HYC01",
                         translate=FALSE,
                         control.probes=c("UNI05","BLANK1","BLANK2"),
                         remove.control.probes=TRUE) {

    remove.control.probes <- TRUE

    cn <- names( raw.biocode.data )

    if( remove.control.probes ) {
        i.probes <- (grepl( "^X\\d+|^[AI]G\\d+$", cn ) | cn == hyc.name) &
          ! cn %in% control.probes
        x <- as.matrix( raw.biocode.data[,i.probes] )
    }

    colnames(x) <- sub( "^X", "", colnames(x) )
    rownames(x) <- as.character(raw.biocode.data$Sample)

    if( name.fix ){
        rownames(x) <- sample.name.fix( rownames(x) )
    }

    if( hyc ){
        if(!hyc.name %in% colnames(x))
            stop( "biocode data doesn't contain a HYC01 probe - cannot hyc correct" )
        hyc.vector <- x[,hyc.name]
        x <- sweep( x, 1, hyc.vector, FUN="/" ) * 1e3
    }

    ## this is done per plate
    if( qcc ){

        i.qcc30 <- grepl( qcc.name, rownames( x ) )

        if( !( any(i.qcc30) ) ){
            stop("qcc control not found on any plates")
        }

        qcc.data <- x[ i.qcc30, , drop=FALSE ]

        q.plate <- raw.biocode.data$Plate[i.qcc30]

        qcc.na <- apply( qcc.data, 1, function(v)sum(is.na(v)) )

        colmedians <- function( x, ... ){
            return( apply( x, 2, median, ... ) )
        }

        qcc.per.plate <- array( NA, dim=c( length(unique(q.plate)), ncol(qcc.data) ) )
        up <- unique(q.plate)
        for( i in seq_along(up) ){
            i.q <- q.plate == up[i]
            qcc.per.plate[i,] <- colmedians( qcc.data[i.q,,drop=FALSE], na.rm=TRUE )
        }
        dimnames( qcc.per.plate ) <- list( up, colnames(qcc.data) )

        if( any(is.na(qcc.per.plate) ) ){
            stop( "Missing values found in QCC data on one or moreplates" )
        }

        m <- match( paste(raw.biocode.data$Plate), rownames(qcc.per.plate) )
        qcc.adjustment <- qcc.per.plate[ m, ]

        x <- x / qcc.adjustment

        x <- x * 1e3

    }

    if( remove.control.probes )
      x <- x[, !colnames(x) %in% hyc.name ]

    return(x)

}


sample.name.fix <- function(x) {

  ## x <- sub( "_.*", "", x )
  x <- gsub( "_", " ", x )
  x <- sub( " [A-C]$", "", x )
  x <- sub( "^neg$", "neg", x, ignore.case=TRUE )
  x <- sub( "^(N?\\d+)[a-c]$", "\\1", x, ignore.case=TRUE )
  x <- sub( "^(MFA04)[- ](\\d)", "\\1 \\2", x )
  x <- sub( "^(MFA04)(\\d{2,3})", "\\1 \\2", x )
  x <- gsub( "^\\s+|\\s+$", "", x )
  x <- sub( "^(MFA04) (\\d{2})$", "\\1 0\\2", x )
  x <- sub( " PCR", "", x )
  ## x <- sub( "(\\d) .*", "\\1", x )
  x <- sub( "^neg .*", "neg", x, ignore.case=TRUE )

  return(x)

}
