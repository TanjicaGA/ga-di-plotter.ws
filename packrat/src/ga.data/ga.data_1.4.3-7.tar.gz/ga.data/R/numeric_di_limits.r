##' Parameters needed for the numeric di algorithm
##'
##' The key parameters needed for the numeric DI algorithm
##' @title Parameters for numeric DI
##' @return a list with named parameters
##' @author Torbjørn Lindahl
##' @export
numeric.di.parameters <- function() {
    numeric.di.parameter.list
}
