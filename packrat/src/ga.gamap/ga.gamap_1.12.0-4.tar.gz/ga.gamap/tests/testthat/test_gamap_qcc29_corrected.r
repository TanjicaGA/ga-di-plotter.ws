library(ga.gamap)

context( "gamap function with QCC29 correction" )

test_that( "it corrects correctly", {

    f <- "data/Lx200-TestfileD-Q2-012.csv"

    ## do it by 'hand' first:
    di.plate <- gamap( f, stop.at="file" )
    di.qcc <- gamap( di.plate, start.from="file", stop.at="qcc" )

    x.hyb <- inverse.qcc30.normalize( di.qcc, di.plate )
    x.hyb.corr <- qcc29.correct( x.hyb )

    x.qcc <- gamap( x.hyb.corr, start.from="hyb", stop.at="qcc" )

    ## then with the do-it-all function:
    x.qcc2 <- gamap.qcc29.corrected( f, batch="PS1801L" )

    expect_equivalent( x.qcc2, x.qcc )
    expect_identical( dimnames( x.qcc2 ), dimnames( di.qcc ) )

})
