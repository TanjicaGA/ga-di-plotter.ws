##' Which probes go into which set
##'
##' Lists probes by AG/IG name for variuos sets.
##' @title probe sets
##' @return character, AG/IG name for specified set
##' @author Torbjørn Lindahl
##' @param set character, which set to return, currently supports ibs3, ibs1, mfa3
##' @param type what to report, 'code' or 'number', meaning bead
##' number (typically seen in biocode files) or code (internal AG/IG code)
##' @param include.technical include technical probes, ie BLANK, HYC etc., default TRUE
##' @param exclude.blank exclude BLANK* probes, default FALSE
##' @export
probe.set <- function( set="ibs3", type=c("code","bead.number"), include.technical=TRUE, exclude.blank=FALSE ){

    type <- match.arg(type)

    tr <- c(
      code="Probe",
      bead.number="Bead"
      )

    r <- ifelse( include.technical, ".", probe.re(include.technical) )

    if( set == "ibs3" ) {
        i <- grepl( r, probe.set.ibs3[,"Probe"] )
        v <- probe.set.ibs3[i,tr[type]]
    }
    else if( set == "ibs1" ) {
        i <- grepl( r, probe.set.ibs1[,"Probe"] )
        v <- probe.set.ibs1[i,tr[type]]
    }
    else if( set == "mfa3" ) {

        r <- ifelse( include.technical, ".", "^[AI]G\\d{3,4}$")
        i <- grepl( r, probe.set.mfa3[,"Probe"] )

        v <- probe.set.mfa3[i,tr[type]]
    }
    else {
        stop( "Set should be one of ibs3, ibs1 or mfa3" )
    }

    if( exclude.blank && type == "bead.number" )
        stop( "Not implemented" )

    if( exclude.blank )
        v <- v[ !grepl( "^BLANK", v ) ]

    return( v )

}
