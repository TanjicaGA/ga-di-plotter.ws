##' Add dysbiosis threshold to an existing plot
##'
##' Adds a class separation line
##' @title Add dysbiosis threshold
##' @param lty line type, see par
##' @param lwd line width, see par
##' @param unit.scale logical default FALSE, use unit scale
##' @param col color of lines drawn
##' @param ... arguments passed to lines()
##' @return no return
##' @author Torbjørn Lindahl
##' @export
##' @importFrom graphics par
add.dysbiosis.thresholds <- function(
  lty="dashed", lwd=2,
  unit.scale = FALSE,
  col="darkgray", ...
  ) {

    t.l <- t2.limit()
    q.l <- qres.limit()

    x.log <- par("xlog")
    y.log <- par("ylog")

    axis.lim <- par("usr")

    if( x.log )
      axis.lim[1:2] <- 10**axis.lim[1:2]
    if( y.log )
      axis.lim[3:4] <- 10**axis.lim[3:4]

    xlim <- axis.lim[1:2]
    ylim <- axis.lim[3:4]

    if( unit.scale ){

        xlim <- xlim / t.l[1]
        ylim <- ylim / q.l[1]

        t.l <- t.l / t.l[1]
        q.l <- q.l / q.l[1]

    }

    l.x <- c( xlim[1], t.l[1], t.l[1] )
    l.y <- c( q.l[1], q.l[1], ylim[1] )

    lines( l.x, l.y, col=col, lty=lty, lwd=lwd, ... )

}

##' Add di scale to plot
##'
##' Adds curves showing the thresholds for DI values 1-5
##' @title di scale
##' @param unit.scale logical default FALSE, use unit scale
##' @param show.numbers logical default TRUE, show numbers
##' @param add.class.threshold logical default TRUE, add dysbiosis
##' threshold
##' @param add logical default TRUE, add to existing plot
##' @param col color of lines and text
##' @param lwd line width, default 1
##' @param cex default 2
##' @param ... passed to plotellipse
##' @return no return
##' @author Torbjørn Lindahl
##' @importFrom shape plotellipse
##' @importFrom ga.data t2.limit qres.limit numeric.di.parameters
##' @importFrom grDevices dev.cur
##' @importFrom graphics plot text points lines
add.dysbiosis.scale <- function( unit.scale = FALSE,
                                show.numbers=TRUE,
                                add.class.threshold=TRUE,
                                add, col="blue", lwd=1, cex=2, ... ) {

    ## makes 'add' a bit smarter
    if( dev.cur() == 1 && missing(add)  )
      add <- FALSE

    if( missing(add) )
      add <- TRUE

    t2.f <- t2.limit()
    qres.f <- qres.limit()

    if( unit.scale ) {
        t2.f <- 1
        qres.f <- 1
    }

    p <- numeric.di.parameters()

    w.t2 <- p$t2.weight
    w.qres <- p$qres.weight

    logm <- p$logm.meanlog
    logs <- p$logs.sdlog

    mdi.3 <- p$di.3
    mdi.4 <- p$di.4

    a3 <- sqrt( mdi.3**2 / w.t2 ) * t2.f
    b3 <- sqrt( mdi.3**2 / w.qres ) * qres.f
    a4 <- sqrt( mdi.4**2 / w.t2 ) * t2.f
    b4 <- sqrt( mdi.4**2 / w.qres ) * qres.f
    a5 <- sqrt( 1/2 ) * t2.f
    b5 <- sqrt( 1/2 ) * qres.f

    di.fractions <- seq( .1, .9, .1 )

    ## di.2.to.3.area <-

    if( !add ) {

        xl <- expression( T^2 )
        yl <- expression( Q-residuals )

        if ( unit.scale ) {
            xl <- expression( T^2~unit~scale )
            yl <- expression( Q-residuals~unit~scale )
        }

        plot( 0, type="n", xlim=c(0,4*t2.f), ylim=c(0,7*qres.f), main="Dysbiosis scale",
             xlab=xl, ylab=yl  )

    }

    if( add.class.threshold )
      add.dysbiosis.thresholds( unit.scale = unit.scale, col=col, lwd=lwd )

    plotellipse(
      rx=a3, ry=b3,
      mid=c(1e-12,1e-12),
      from=0, to=pi/2,
      lcol=col, lwd=lwd,
      ...
      )
    plotellipse(
      rx=a4, ry=b4,
      mid=c(1e-12,1e-12),
      from=0, to=pi/2,
      lcol=col, lwd=lwd,
      ...
      )
    plotellipse(
      rx=a5, ry=b5,
      mid=c(1e-12,1e-12),
      from=0, to=pi/2,
      lcol=col, lwd=lwd,
      ...
      )

    f <- c( 1, 1.35, 2.3, 2.8, 3.7 )
    r <- function(di) {
        theta <- pi/4 * 1.1
        return( c( .2 + acos(theta)*di*f[di]/4, asin(theta)*di*f[di]/4 ) )
    }

    text( t2.f*r(1)[1], qres.f*r(1)[2], "1", cex=cex, col=col, adj=0 )
    text( t2.f*r(2)[1], qres.f*r(2)[2], "2", cex=cex, col=col, adj=0 )
    text( t2.f*r(3)[1], qres.f*r(3)[2], "3", cex=cex, col=col, adj=0 )
    text( t2.f*r(4)[1], qres.f*r(4)[2], "4", cex=cex, col=col, adj=0 )
    text( t2.f*r(5)[1], qres.f*r(5)[2], "5", cex=cex, col=col, adj=0 )

}
