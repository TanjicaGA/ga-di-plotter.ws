##' Current concentration limit
##'
##' Current concentration limit from picogreen, returns 15
##' @title Current concentration limit
##' @return the limit
##' @author Torbjørn Lindahl
##' @export
concentration.limit <- function() {
    return( 15 )
}
