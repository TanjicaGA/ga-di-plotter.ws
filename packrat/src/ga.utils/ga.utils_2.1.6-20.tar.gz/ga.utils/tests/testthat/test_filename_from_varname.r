library(ga.utils)

context( "Normal operation" )

test_that( "Filenames are right", {

    ## single
    expect_equal(
      filename.from.varname( "foo.bar", "csv" ), "foo_bar.csv"
      )

    ## multiple
    expect_equal(
      filename.from.varname( c("foo","bar"), "csv" ), c("foo.csv","bar.csv")
      )

    ## tidy up
    expect_equal(
      filename.from.varname( "foo.bar..", ".csv" ), "foo_bar.csv"
      )

})
