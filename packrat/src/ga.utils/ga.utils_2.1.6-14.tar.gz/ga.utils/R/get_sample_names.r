##' Get sample names from input
##'
##' Tries hard to get sample names from input argument. If <2
##' dimensions, returns names. If not, checks case insensitively for a
##' sample column, if not found, returns rownames
##' @title Get sample names
##' @param x argument to get sample names from
##' @return character with sample names
##' @author Torbjørn Lindahl
##' @importFrom utils capture.output
##' @importFrom utils str
##' @export
get.sample.names <- function(x) {

    if( is.null(dim(x)) ) {
        if( is.character(x) )
            n <- x
        else if(!is.null(names(x)))
            n <- names(x)
        else
            stop( paste("Cannot find sample names of input, it't not a character, and it doesn't havea names():", capture.output( str(x), type="output")))
    } else if( "sample" %in% tolower(colnames(x)) ) {
        n <- x[, grep1("sample",tolower(colnames(x))) ]
    } else {
        n <- rownames(x)
    }

    return(n)

}
