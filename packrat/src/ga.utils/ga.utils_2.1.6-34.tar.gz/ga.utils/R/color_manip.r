##' Tone down, or up, a color
##'
##' Adjusts the colorspace by a fraction.
##' @title tint a color
##' @param x one or more colors to tint
##' @param tint fraction to tint it, a number between -1 and
##'     1. Positive numbers increase the color value (makes it
##'     brighter), negative values reduce it (makes it darker).
##' @return the modified color value(s)
##' @importFrom grDevices col2rgb
##' @importFrom grDevices rgb
##' @author Torbjørn Lindahl
##' @export
tint.color <- function(x, tint=1/4) {

    if( any(abs(tint) > 1) )
        stop( "tint should be in the range [0,1]" )

    x0 <- col2rgb(x)
    if( tint > 0 ) {
        x2 <- x0 + (255 - x0)*tint
    }
    else if( tint < 0 ) {
        x2 <- x0 * (1-abs(tint))
    }
    else {
        x2 <- col2rgb(x)
    }

    return( apply( x2, 2, function(v)do.call( rgb, as.list(v/255)) ) )

}
