## ##' .. content for \description{} (no empty lines) ..
## ##'
## ##' .. content for \details{} ..
## ##' @title generate set indeces
## ##' @return
## ##' @author Torbjørn Lindahl
## make.set <- function( ... ) {

##     v <- c(...)
##     n <- names(v)

## }
