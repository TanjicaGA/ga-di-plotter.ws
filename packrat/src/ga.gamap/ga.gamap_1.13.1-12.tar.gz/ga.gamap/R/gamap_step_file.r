## step functions for the gamap

##' step 1: read files
##'
##' Reads biocode csv files
##' @title step 1
##' @param input character, file names
##' @return a data.frame with data read from the csv file
##' @author Torbjørn Lindahl
##' @importFrom ga.biocode read.biocode.plates
##' @importFrom ga.utils "%!in%"
gamap.step.file <- function( input ){


    output <- process.csvfiles( input, "Median" )
    count.data <- process.csvfiles( input, "Count" )

    cn2 <- colnames(output)
    cn3 <- setdiff( cn2, c("File", "Platform", "Location", "Sample", "Total.Events",
                           "Plate", "Coord" ,"Well", "Row", "Col" ) )

    ## if( !identical( cn3, probe.set("ibs3") ) ) {
    if( any( probe.set("ibs3") %!in% cn2 ) ) {
        names.too.many <- setdiff(cn2, probe.set("ibs3"))
        names.missing <- setdiff(probe.set("ibs3"), cn2)
        extra <- ""
        if( length(names.too.many) > 0 )
          extra <- sprintf( "Names too many: %s\n", paste(names.too.many,collapse = ", ") )
        if( length(names.missing) > 0 )
          extra <- paste0( extra, sprintf( "Names missing: %s", paste(names.missing,collapse = ", ") ) )

        stop( sprintf( "Names read on data in file do not match the reference names for ibs3.0\n%s", extra ) )
    }

    attr( output, "count" ) <- count.data

    class( output ) <- append( "gamap.file", class( output ) )

    return( output )
}

##' print method for the file data of the algorithm
##'
##' Shows only the most commonly inspected contents of the data frame
##' @title print file data from gamap algorihtm
##' @param x data to print
##' @param ... extra arguments to print.data.frame
##' @return a subset of the data as a data.frame, or just the object
##' @author Torbjørn Lindahl
##' @importFrom ga.data probe.re
##' @export
print.gamap.file <- function(x, ... ) {

    columns.to.exclude <- c(
        grep( probe.re(), colnames(x), value=TRUE ),
        grep( "^\\d{3}$", colnames(x), value=TRUE ), # for 3-digit probe numbers
        c("Total.Events","Coord","Well","Row","Col")
    )

    i <- colnames(x) %in% columns.to.exclude

    if( all(x$Platform %in% "lx200") ) {
        i <- i | grepl("^BLANK[12]$",colnames(x) )
    }

    print.data.frame( y <- x[,!i] )

}


##' @export
`[.gamap.file` <- function( x, i, j, ... ) {

    y <- `[.data.frame`(x, i, j, ... )

    ## If we subsetted the columns, we drop this class
    if( !missing(j) )
        class(y) <- setdiff( class(y), "gamap.file" )

    return( y )

}

##' biocode meta data
##'
##' Returns columns from biocode data other than the probe measurements (eg filename, rundate, samplenames etc)
##' @title fetch biocode meta data
##' @param x biocode data to fetch meta data from
##' @param ... additional parameters passed to methods
##' @return data.frame with meta data
##' @author Torbjørn Lindahl
##' @export
meta <- function( x, ... ) {
    UseMethod("meta")
}

##' @author Torbjørn Lindahl
##' @importFrom ga.data probe.re
meta.gamap.file <- function(x ) {
    x[, !grepl( probe.re( include.technical=TRUE ), colnames(x) ) ]
}

##' @export
rbind.gamap.file <- function( ..., deparse.level=1 ) {

    x0 <- rbind.data.frame( ..., deparse.level=deparse.level )
    x <- reenumerate.plate( x0 )

    ## rbind the count attr
    new.count <- Reduce(
        f=function(a,b){

            if( is.null(b) ) {
                return( a )
            }

            bc <- attr( b, "count" )

            if(is.null(bc)) {
                bc <- b
                bc[, colnames(probe.data(b))] <- NA
            } else if(is.null(dim(bc))) {
                warning("problem rbinding di.plate data.frame, 'count' was found but it wasnt a 2D object, using NA instead")
                bc <- b
                bc[, colnames(probe.data(b))] <- NA
            }

            if( nrow(bc) != nrow(b) ) {
                warning("problem rbinding di.plate data.frame, 'count' was found but it has the wrong number of rows, using NA instead")
                bc <- b
                bc[, colnames(probe.data(b))] <- NA
            }

            rbind.data.frame( a, bc )

        }, init=NULL, x=list(...)
    )
    ## new.count <- reenumerate.plate( new.count )
    new.count$Plate <- x$Plate

    attr( x, "count" ) <- new.count

    return( x )

}

##' Renumerate Plate variable
##'
##' This recounts the $Plate variable in a plate data set, assuring
##' it's a unique value within each File
##' @title reenumerate $Plate of a plate.data variable
##' @param x plate data to process
##' @return data.frame with reindexed Plate variable
##' @author Torbjorn Lindahl
##' @export
reenumerate.plate <- function( x ) {

    if(!inherits( x, "gamap.file" )) {

    }

    uf <- unique( x$File )
    pl <- x$Plate

    current.plate <- 0
    new.plate <- rep( NA, nrow(x) )

    for( f in uf ) {

        i <- x$File %in% f
        x.i <- x[i,]
        up.i <- unique( x[i,]$Plate )
        p <- as.numeric( factor( paste(x.i$Plate), levels=up.i ) )
        new.plate[i] <- p + current.plate

        current.plate <- max( new.plate[i] )

    }

    x$Plate <- factor( new.plate )

    return( x )

}

##' Plots a gamap.file object (typically named di.plate)
##'
##' Sets up a ggplot with a geom_tile to lay out the samples on a
##' plate.
##' @title plot a gamap.file object
##' @param x gamap.file
##' @param mapping optional, a mapping to be used for the geom_tile
##'     layer
##' @param file say which file to plot, if more than one is present
##' @param ... Other arguments to geom_text
##' @return the ggplot object
##' @author Torbjorn Lindahl
##' @importFrom ggplot2 ggplot aes geom_tile guides scale_y_reverse
##'     scale_x_continuous geom_text ggtitle
##' @export
plot.gamap.file <- function( x, mapping, file, ... ) {

    if( length(unique(x$File)) > 1 & (missing(file)|| file %!in% x$File)  ) {
        warning("More than one file found in x, say which to plot or subset it")
        return()
    }

    if(!missing(file)) {
        x <- subset_deep( x, x$File == file )
    }

    if( nrow(x) == 0 ) {
        warning( "No rows left in x, not ploting" )
        return()
    }

    x$IsQcc <- grepl( "^QCC", x$Sample )

    ## to keep devtools from warning
    Col <- Row <- Sample <- IsQcc <- NULL

    if( missing(mapping)) {
        gt <- list( geom_tile( aes( fill = IsQcc ), col="black" ), guides(fill=FALSE) )
    } else {
        gt <- geom_tile( mapping )
    }

    g <- ggplot( x, aes(x=Col,y=Row) ) +
        scale_y_reverse( limits=c(8.5,.5), breaks=1:8, labels=LETTERS[1:8] ) +
        scale_x_continuous( limits=c(0.5, 12.5), breaks=1:12 ) +
        gt +
        geom_text( aes(label=Sample), ... ) +
        ggtitle( x$File[1] )

    g

}
