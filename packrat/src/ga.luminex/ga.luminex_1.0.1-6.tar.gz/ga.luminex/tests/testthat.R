library(testthat)
library(ga.luminex)

test_check("ga.luminex")
