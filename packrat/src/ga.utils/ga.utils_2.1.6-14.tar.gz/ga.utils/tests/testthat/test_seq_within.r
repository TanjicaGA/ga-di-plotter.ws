library(ga.utils)

context( "seq_within" )

test_that( "seq_within works as designed", {

    expect_equal(
        seq_within( "A","B","A","B","A","C" ),
        c( 1,1,2,2,3,1 )
    )

    expect_equal(
        seq_within( "A","A","A","A","A","A" ),
        c( 1,2,3,4,5,6 )
    )

})

test_that( "NA and NULL are handled", {

    expect_equal(
        seq_within( list(1,2,NULL,1,NULL,1) ),
        c( 1,1,1,2,2,3 )
    )

    expect_equal(
        seq_within( c(1,2,NA,NA,3,2) ),
        c( 1,1,1,2,1,2 )
    )

})
