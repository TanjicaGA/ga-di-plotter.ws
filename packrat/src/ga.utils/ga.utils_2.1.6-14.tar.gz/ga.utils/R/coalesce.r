##' Return the first non-NULL'ish argument
##'
##' Returns the first value that is not NULL and not something with
##' lenght 0
##' @title return first real value
##' @param ... values to process
##' @param accept.na should NA be considered ok to return
##' @return first value that is something
##' @author Torbjørn Lindahl
##' @export
coalesce <- function( ..., accept.na=TRUE ) {

    values <- list(...)

    i <- !is.null( values ) &
        lengths(values) > 0

    if(!accept.na)
        i <- i & !is.na(values)

    if( any(i) ) {
        return( values[[ which(i)[1] ]] )
    }
    else {
        return( NULL )
    }

}

##' Like coalesce, only processes rows of one input variable
##'
##' Returns first non-NA value per row of an array
##' @title First non-NA value of rows
##' @param x input argument
##' @return first non NA value per row
##' @author Torbjørn Lindahl
##' @export
coalesce.col <- function(x ) {

    v <- apply( x, 1, function(r) {
        l <- as.list(r)
        l$accept.na <- FALSE
        do.call( coalesce, l )
    })

    v[ sapply(v,is.null) ] <- NA

    unlist(v)

}
