library(ga.software.dd)
library(ga.gamap)
library(testthat)
library(ga.utils)
library(ga.data)

options( stringsAsFactors=FALSE )

context( "full qc" )

tf1 <- normalizePath( "data/lx200-files/TestFile-01.csv" )
tf2 <- normalizePath( "data/lx200-files/TestFile-02.csv" )

## test_that( "qc on a whole plate works", {

##     qc1 <- doctors.data.qc( tf1, batch="PS1404" ) ## Fail
##     qc2 <- doctors.data.qc( tf1, batch="L1906" ) ## OK

##     expect_false( qc1 )
##     expect_true( qc2 )

## })

## test_that( "intermediate results are ok", {

##     plate.data <- gamap( tf1, stop.at="file" )
##     count.data <- attr( plate.data, "count" )
##     di.num <- gamap( plate.data, start.from="file", batch="L1906" )
##     ab.qc <- abundancy.table.qc( plate.data, start.from="file", batch="L1906", report.per.sample=FALSE )

##     d.23 <- dd.qc.plate.cp.03.QCCX3(
##         plate.data, count.data, di.num, ab.qc, "QCC23"
##     )
##     expect_true( any(grepl( "\u00b1", names(d.23), perl=TRUE ) ))

##     d.33 <- dd.qc.plate.cp.03.QCCX3(
##         plate.data, count.data, di.num, ab.qc, "QCC33"
##     )
##     expect_true( any(grepl( "\u00b1", names(d.33), perl=TRUE ) ))

## })

test_that( "Too low QCC30 HYC01 is detected", {

    di.plate <- gamap( tf1, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$HYC01[i.qcc30][1] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$HYC01[i.qcc30][2] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$HYC01[i.qcc30][3] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$HYC01[i.qcc30][4] <- 100
    ## Now it should be FALSE
    expect_false( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

})

test_that( "Low UNI05 on QCC23 is handled", {

    di.plate <- gamap( tf1, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    di.plate$UNI05[i.qcc23][1] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$UNI05[i.qcc23][2] <- 100
    expect_false( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

})

test_that( "Low HYC01 on QCC23 is handled", {

    di.plate <- gamap( tf1, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    di.plate$HYC01[i.qcc23][1] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$HYC01[i.qcc23][2] <- 100
    expect_false( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

})

test_that( "Low UNI05 on QCC33 is handled", {

    di.plate <- gamap( tf1, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    di.plate$UNI05[i.qcc33][1] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$UNI05[i.qcc33][2] <- 100
    expect_false( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

})

test_that( "Low HYC01 on QCC33 is handled", {

    di.plate <- gamap( tf1, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    di.plate$HYC01[i.qcc33][1] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )
    di.plate$HYC01[i.qcc33][2] <- 100
    expect_false( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

})

test_that( "Low HYC01 on QCC23 doesn't affect QC", {

    di.plate <- gamap( tf1, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    pr.lx200 <- lx200.probes( include.technical=FALSE )

    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

    ## inject a QCC33 vector into QCC23
    v <- di.plate[ which(i.qcc33)[1], pr.lx200 ]
    di.plate[ which(i.qcc23)[1], pr.lx200 ] <- v

    expect_false( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

    ## A bad hyc causes the failed sample no longer to influence QC
    di.plate$HYC01[ i.qcc23 ][1] <- 100
    expect_true( abundancy.table.qc( di.plate, start.from="file", batch="L1906" ) )

})
