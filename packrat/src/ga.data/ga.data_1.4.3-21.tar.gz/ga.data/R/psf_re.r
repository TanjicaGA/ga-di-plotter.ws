##' Valid PSF regex
##'
##' A regex to validate a PSF string
##' @title regexp to match psf
##' @return string
##' @author Torbjorn Lindahl
##' @export
##' @param anchored default TRUE. Anchor the regex, ie add ^ and $ to
##'     it.
psf_re <- function( anchored=TRUE ) {

    rx <- "PS[12]\\d{3}[LR]?"
    if( anchored )
        rx <- paste0( "^", rx, "$" )

    return( rx )

}
