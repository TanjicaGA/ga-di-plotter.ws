##' creates theme to rotate x axis 90 degrees
##'
##' creates theme to rotate x axis 90 degrees
##' @title rotate x axis tick labels 90 degrees
##' @return element to be chained to a ggplot call
##' @author Torbjørn Lindahl
##' @importFrom ggplot2 theme
##' @param angle degrees to rotate, default 90
##' @param hjust hjust value, default 1
##' @param ... other arguments to element_text
##' @importFrom ggplot2 theme element_text
##' @export
gg_rotate_x_axis <- function( angle=90, hjust=1, ... ) {
    theme(axis.text.x = element_text( angle=angle, hjust=hjust ))
}
