library(ga.utils)

context( 'Regexp Operator' )

test_that( 'Plain filtering', {

    v <- LETTERS[1:5]

    expect_equal( v %~% "[A-C]", c(TRUE,TRUE,TRUE,FALSE,FALSE) )
    expect_equal( v %!~% "[A-C]", !c(TRUE,TRUE,TRUE,FALSE,FALSE) )
    
})

test_that( 'Assignment works', {

    v <- LETTERS[1:5]
    v %~% "[A-C]" <- 1:3

    expect_equal( v, c("1","2","3","D","E") )

    v2 <- LETTERS[1:5]
    v2 %!~% "[A-C]" <- 4:5

    expect_equal( v2, c("A","B","C","4","5") )
    
})
