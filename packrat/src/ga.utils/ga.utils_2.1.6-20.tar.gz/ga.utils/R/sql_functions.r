##' Create SQL array
##'
##' Creates a string representation of the vector as an SQL array
##' @title Create a SQL array as string from an R vector
##' @param x input vector to be put in array
##' @param array.syntax use array brackets, { and } and no '' quotes
##' @param skip.opening.closing skip the surrounding parens
##' @return string representation of an SQL array
##' @author Torbjørn Lindahl
##' @export
sql.array <- function(x,array.syntax=FALSE, skip.opening.closing=FALSE) {

    start <- "("
    end <- ")"
    delim <- "','"

    if( array.syntax ) {
        start <- "{"
        end <- "}"
        delim <- ","
    }

    s <- ""

    if( !skip.opening.closing )
        s <- paste0(s, start)

    s <- paste0( s, "'", paste(x,collapse=delim ), "'" )

    if( !skip.opening.closing )
        s <- paste0(s, end)

    return( s )

}
