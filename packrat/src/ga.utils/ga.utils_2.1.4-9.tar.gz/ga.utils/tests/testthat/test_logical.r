library(ga.utils)

context( "clever checks for truthy" )

test_that( "falsy values are false", {

    expect_false( truthy() )
    expect_false( truthy(NULL) )
    expect_false( truthy( character() ) )
    expect_false( truthy( "" ) )
    expect_false( truthy( numeric() ) )
    expect_false( truthy( 0 ) )
    expect_false( truthy( "0" ) )
    expect_false( truthy( "00" ) )
    expect_false( truthy( "0.0" ) )
    expect_false( truthy( "false" ) )
    expect_false( truthy( "FALSE" ) )
    expect_false( truthy( "FalSe" ) )
    expect_false( truthy( FALSE ) )
    expect_false( truthy( "no" ) )
    expect_false( truthy( "NO" ) )
    expect_false( truthy( "nO" ) )
    expect_false( truthy( list() ) )

})

test_that( "truish values are true", {

    expect_true( truthy( "abc" ) )
    expect_true( truthy( 1 ) )
    expect_true( truthy( 10 ) )
    expect_true( truthy( "1" ) )
    expect_true( truthy( " 1" ) )
    expect_true( truthy( "01" ) )
    expect_true( truthy( "1e-20" ) )
    expect_true( truthy( "2" ) )
    expect_true( truthy( "true" ) )
    expect_true( truthy( "TRUE" ) )
    expect_true( truthy( "TrUe" ) )
    expect_true( truthy( TRUE ) )

})
