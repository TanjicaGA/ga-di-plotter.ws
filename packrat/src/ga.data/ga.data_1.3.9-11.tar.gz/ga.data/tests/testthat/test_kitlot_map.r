library(ga.data)

context( "Lookup kitlot names" )

test_that( "a few simple kitlots works", {

    expect_equal(
      psf.from.kitlot("K1501"), "PS1502"
      )

    expect_equal(
      psf.from.kitlot("K1515"), "PS1512"
      )

})

test_that( "not found kitlots are handled", {

    expect_error(
      psf.from.kitlot("K9999"),
      "not available"
      )

    expect_null(
      psf.from.kitlot("K9999",allow.fail=TRUE)
      )

})

context( "List batches" )

test_that( "batch names are listed correctly", {

    expect_is(
      available.batches(),
      "character"
      )

    expect_true(
      all(grepl( "^(PS\\d{4}L?|[KL]\\d{4})$", available.batches() ))
      )

    expect_true(
      any(grepl( "^PS\\d{4}$", available.batches() ))
      )

    expect_true(
      any(grepl( "^K\\d{4}$", available.batches() ))
      )

})
