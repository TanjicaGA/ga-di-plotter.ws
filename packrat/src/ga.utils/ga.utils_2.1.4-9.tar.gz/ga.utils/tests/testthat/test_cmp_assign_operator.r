library(ga.utils)

context( "Assignment after comparison" )

test_that( "Basic usage works", {

    v <- 1:10

    v == 5 <- 20

    expect_equal( v, c(1:4,20,6:10) )

})
