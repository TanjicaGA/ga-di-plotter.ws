library(ga.gamap)

lx200.file <- file.path( "data", "Lx200-TestfileC.csv" )
lx200.file2 <- file.path( "data", "Lx200-TestfileB.csv" )

context( "reenumerate plate" )

test_that( "Plate gets reenumerated", {

    x <- gamap( lx200.file, stop.at = "file", batch="PS1702" )
    expect_true( all( x$Plate == 1 ) )

    x2 <- gamap( lx200.file2, stop.at = "file", batch="PS1702" )
    expect_true( all( x2$Plate == 1 ) )

    x3 <- rbind.data.frame( x, x2 )
    expect_true( all( x3$Plate == 1 ) )

    ## as function
    x4 <- reenumerate.plate( x3 )
    expect_equivalent(
        as.numeric(x4$Plate),
        c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
    )

    ## as method
    x5 <- rbind( x, x2 )
    expect_equivalent(
        as.numeric(x5$Plate),
        c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
    )

})
