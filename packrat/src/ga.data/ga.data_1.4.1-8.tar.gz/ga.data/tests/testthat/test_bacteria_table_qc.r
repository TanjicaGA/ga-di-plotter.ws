library(testthat)
library(ga.data)

context( "bacteria table qc parameters" )

test_that( "they are listed", {

    l <- bacteria.table.qc.parameters()

    expect_is( l, "list" )
    expect_named( l, c("QCC23","QCC33"), ignore.order=TRUE )

})
