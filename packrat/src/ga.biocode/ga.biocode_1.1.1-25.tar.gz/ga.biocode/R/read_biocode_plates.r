##' Read several biocode files and combine data
##'
##' Read several biocode files
##' @title Read many biocode files
##' @param csv.files files to read
##' @param what.data Median or Count, data section to get from the files
##' @param true.sample.names Optionally change sample names to this list
##' @param allow.different.names Allow different names in the data
##' frames, if TRUE will subset the data to the least common subset of
##' names
##' @return a data.frame with Median or Count data
##' @author Torbjørn Lindahl
##' @export
read.biocode.plates <- function( csv.files, what.data="Median", true.sample.names,
                                allow.different.names=FALSE ) {

  biocode.data <- NULL

  plate <- NULL
  file.name <- NULL

  i <- 1
  for( csv.file in csv.files ){

    p <- read.biocode( csv.file )

    if( ! what.data %in% names(p) )
      stop( "'", what.data, "' not found in ", basename(csv.file) )

    m.i <- p[[what.data]]

    if( !is.null(biocode.data) ) {
        if( ! identical( names( m.i ), names( biocode.data ) ) ) {

            if( allow.different.names ) {
                ## find a the least common subset
                common.names <- intersect( names(biocode.data), names(m.i) )
                ##
                match.existing <- match( common.names, names(biocode.data) )
                biocode.data <- biocode.data[,match.existing]
                ##
                match.new <- match( common.names, names(m.i) )
                m.i <- m.i[,match.new]
            }
            else {
                stop( "Names in file '",basename(csv.file),"' doesn't match the others" )
            }

        }
    }

    biocode.data <- rbind( biocode.data, m.i )

    plate <- append( plate, rep(i,nrow(m.i) ) )
    file.name <- append( file.name, rep( csv.file, nrow(m.i) ) )
    i <- i+1

  }

  biocode.data <- cbind.data.frame( File=basename(file.name), biocode.data )

  biocode.data$Plate <- as.factor( plate )
  biocode.data$Coord <- sub( ".* \\(([A-H]\\d+)\\).*", "\\1", biocode.data$Location  )
  biocode.data$Well <- plate.coord( biocode.data$Coord )
  biocode.data[,c("Row","Col")] <- well.to.row.col( biocode.data$Well )

  if(!missing(true.sample.names)){

      if( length(true.sample.names) != nrow(biocode.data) ){
          stop("The sample names vector doesn't match data size")
      }

      biocode.data$Sample <- true.sample.names

  }

  return( biocode.data )

}
