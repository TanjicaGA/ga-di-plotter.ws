library(ga.software.dd)
library(ga.data)
library(ga.utils)
library(ga.gamap)
library(readr)
library(stringr)
library(testthat)

options( stringsAsFactors=FALSE )

context( "export csv" )

wd <- getwd()

test_that( "it can export csv per spec", {

    tf1 <- normalizePath( "data/lx200-files/TestFile-01.csv" )
    dir.create( td <- tempfile() )

    dd1 <- dd.export.csv( tf1, kitlot="L1902", path=NA )
    ## no files there, since nothing got written
    expect_length( dir(td), 0 )

    setwd(td)

    on.exit(
        {
            setwd(wd)
            if( unlink( td, recursive=TRUE ) != 0 ) {
                warning( "Failed cleaning up tmp dir ", td )
            }
        },
        add=TRUE
    )

    dd2 <- dd.export.csv( tf1, kitlot="L1902" )
    ## now there is a file there
    expect_length( dir(td), 1 )

    written.file <- dir(td)

    content <- read_file( written.file )
    i.begin <- regexpr('(?<=\\n\\n)"?Sample"?,', content, perl=TRUE )
    ## remember, everything is part of the content, including all
    ## newlines, leading up the beginning of the very line that starts
    ## with literal '-- CRC --'
    i.end <- regexpr( '(?<=\\n\\n)-- CRC --\n', content, perl=TRUE )-1

    con <- textConnection( substr(content, i.begin, i.end) )
    on.exit(close(con), add=TRUE )

    ff2 <- read.csv( written.file, nrows=4, header=FALSE )

    ## check that the auto generated filename is based on the input file
    expect_match( ff2[,2][ ff2[,1] == "Filename" ], sub( "\\.csv$", "", basename(tf1), ignore.case=TRUE ) )
    ## check that the rundate is right
    expect_equal( ff2[,2][ ff2[,1] == "Rundate" ], paste(rundate(tf1)) )
    ## and the kitlot
    expect_equal( ff2[,2][ ff2[,1] == "Kitlot" ], "L1902" )
    ## and that it has an AppVersion
    expect_match( ff2[,2][ ff2[,1] == "AppVersion" ], "." )

    ff2.b <- read.csv( file=con )

    colnames(ff2.b) <- sub("^X","",colnames(ff2.b))

    expect_true( all( c("Sample","DI","QC","QCText") %in% names(ff2.b) ) )
    expect_true( all( probe.numbers(bacteria.limits()$Probe) %in% names(ff2.b) ) )

    pr <- bacteria.limits()$Probe

    di.plate <- gamap( tf1, batch="L1902", stop.at="file" )
    din <- gamap( di.plate, batch="L1902", start.from="file" )

    set.qcc.indeces( di.plate, verbose=FALSE, postfix=".2" )
    jj <- !i.qcc30.2 & !i.qcc29.2

    pn <- paste(probe.numbers(pr))

    ## check the bacteria table values with precalculated scores
    expect_equivalent(
        as.matrix( ff2.b[, pn ] ),
        gamap.probe.levels( tf1, batch="L1902" )[ jj, ]
    )

    ## check the rest of the data.frame, ie DI, QC etc.
    expect_equal(
        ff2.b[, colnames(ff2.b) %!in% pn ],
        data.frame(
            Sample = di.plate$Sample[jj],
            DI = round(din[jj],3),
            QC = rep( TRUE, sum(jj)),
            QCText = rep( NA, sum(jj)),
            row.names=NULL
        )
    )

    ## data sets should be unaffected about how they might or might
    ## not be written to disk in terms of newlines or other platform differences

    ## take away the crc32 attribute and compare them (the only difference between dd1 and dd2 is that one of them was written to disk)
    attr( dd2, "crc32" ) <- NULL
    expect_equal( dd1, dd2 )

    ## with a custom filename
    dd3 <- dd.export.csv( tf1, kitlot="L1902", path="./foo.csv" )

    attr( dd3, "crc32" ) <- NULL
    ## also writing to a custom filename should not change things
    expect_equal( dd1, dd3 )

    ## header = ff3
    ## body   = ff3.b
    ## both from the dd3 variale that was written to disk

    ff3 <- read.csv( file="foo.csv", nrows=4, header=FALSE )
    ff3.b <- read.table( file="foo.csv", skip=5, nrows=8, sep=",", stringsAsFactors=FALSE, header=TRUE )

    colnames(ff3.b) <- sub("^X","",colnames(ff3.b))

    ## ff2 are the corresponding data parts before it got written to disk and read back into ff3 and ff3.b
    expect_equal( ff2, ff3 )
    expect_equal( ff2.b, ff3.b )

    ## check the crc32

    ## Write the data part of the export to a tempfile. Eg. skip the
    ## CRC32 signature. The content written is the data that should
    ## match the crc32.
    f <- tempfile()
    fh <- file( f, 'wb' ) ## the 'b' is important to cause newlines to be consistently written to disk
    cat( substr( content, 0, i.end ), file=fh )
    close( fh )

    crc32.ctrl.calc.from.file <- toupper( str_pad( digest( f, file=TRUE, algo="crc32" ), width=8, pad="0" ) )
    crc32.ctrl.calc.from.mem <- toupper( str_pad( digest( substr( content, 0, i.end ), algo="crc32", serialize=FALSE ), width=8, pad="0" ) )

    crc32.in.file <- str_match( content, "CRC32:\\s*(\\S+)" )[,2]

    unlink(f)

    expect_equal( crc32.ctrl.calc.from.file, crc32.in.file )
    expect_equal( crc32.ctrl.calc.from.mem, crc32.in.file )

})

test_that( "it implements lower TS QC criterion", {

    tf1 <- normalizePath( "data/lx200-files/TestFile-01.csv" )
    tf2 <- normalizePath( "data/lx200-files/TestFile-01-LOW-TS.csv" )

    di.plate <- gamap( tf2, stop.at="file" )
    set.qcc.indeces( di.plate, verbose=FALSE )

    ts <- rowSums(probe.data(di.plate)[i.qcc30,],na.rm=TRUE)

    expect_true( all( ts < 650e3 & ts > 550e3 ))

    dd1 <- dd.export.csv( tf1, kitlot="L1902", path=NA )
    dd2 <- dd.export.csv( tf2, kitlot="L1902", path=NA )

    ## now there are two files there
    expect_equivalent( dd1$DI, dd2$DI, tolerance=1e-2 )

    dd3 <- dd.export.csv( tf2, kitlot="L1902", path=NA, use.lower.qc.criterion=FALSE )

    expect_true( all(is.na(dd3$DI)) )

})
