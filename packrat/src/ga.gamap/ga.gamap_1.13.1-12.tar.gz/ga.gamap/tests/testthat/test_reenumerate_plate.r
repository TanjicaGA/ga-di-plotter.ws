library(ga.gamap)
library(ga.data)

lx200.file <- file.path( "data", "Lx200-TestfileC.csv" )
lx200.file2 <- file.path( "data", "Lx200-TestfileB.csv" )

context( "reenumerate plate" )

test_that( "Plate gets reenumerated", {

    x <- gamap( lx200.file, stop.at = "file", batch="PS1702" )
    expect_true( all( x$Plate == 1 ) )

    x2 <- gamap( lx200.file2, stop.at = "file", batch="PS1702" )
    expect_true( all( x2$Plate == 1 ) )

    x3 <- rbind.data.frame( x, x2 )
    expect_true( all( x3$Plate == 1 ) )

    ## as function
    x4 <- reenumerate.plate( x3 )
    expect_equivalent(
        as.numeric(x4$Plate),
        c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
    )

    ## the rbind method
    x5 <- rbind( x, x2 )
    expect_equivalent(
        as.numeric(x5$Plate),
        c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
    )

    expect_equal( dim( x5 ), dim( attr( x5, "count" ) ) )

    ## missing count handled
    local({

        attr( x2, "count" ) <- NULL
        x5 <- rbind( x, x2 )

        expect_equivalent(
            as.numeric(x5$Plate),
            c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
        )

        attr( x2, "count" ) <- 1:10

        ## there should be a warning that count is used as NA
        expect_warning( x5 <- rbind( x, x2 ), "NA" )
        expect_equivalent(
            as.numeric(x5$Plate),
            c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
        )
        bc <- attr( x5, "count" )
        ## all counts representing the second plate should now be NA
        expect_true( all(is.na( probe.data(bc[ -(1:nrow(x)), ] ))))

    })

    local({

        bc <- attr( x2, "count" )
        bc <- bc[ 1:10, ]

        attr( x2, "count" ) <- bc

        expect_warning( x5 <- rbind( x, x2 ), "NA" )
        expect_equivalent(
            as.numeric(x5$Plate),
            c( rep( 1, nrow(x) ), rep( 2, nrow(x2) ) )
        )
        bc2 <- attr( x5, "count" )
        ## all counts representing the second plate should now also be NA
        expect_true( all(is.na( probe.data(bc2[ -(1:nrow(x)), ] ))))

    })

})
