##' Logical evaluation with a breeze
##'
##' Makes the following assumptions on what can be considered TRUE:
##' * A missing argument is FALSE
##' * A zero-length argument is FALSE
##' * Anythinig length > 1 is TRUE
##' * NULL is FALSE
##' * NA is NA
##' * Any logical is evaluated as is
##' * A number different from 0 is TRUE
##' * A character that converts to number 0 is FALSE
##' * A character that converts to a number different from 0 is TRUE
##' * "" is FALSE
##' * Any other character is TRUE
##' @title interpreted true
##' @param x argument to be interpreted
##' @return logical TRUE or FALSE depending
##' @author Torbjørn Lindahl
##' @export
truthy <- function( x ) {

    if( missing(x) ) {
        return( FALSE )
    }
    if( length(x) == 0 ) {
        return( FALSE )
    }
    if( length(x) > 1 ) {
        return( TRUE )
    }
    if( is.na(x) ) {
        return( NA )
    }
    if( is.null(x) ) {
        return( FALSE )
    }
    if( is.logical(x) ) {
        return( x )
    }
    if( is.numeric(x) ) {
        return( x != 0 )
    }
    if( is.character(x) ) {
        n <- suppressWarnings( as.numeric(x) )
        if(!is.na(n)) {
            return( truthy(n) )
        }
        if( x == "" ) {
            return(FALSE)
        }
        return( TRUE )
    }
    if( length(x) > 0 ) {
        return( TRUE )
    }

    return( NA )

}

##' @rdname truthy
##' @export
falsy <- function( x ) {
    return( !truthy(x) )
}
