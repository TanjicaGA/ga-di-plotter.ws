library(ga.gamap)

context( "Inverse QCC30 normalization" )

test_that( "It reverses QCC30 normalization properly", {

    lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )
    di.plate <- gamap( lx200.file, stop.at="file" )
    di.hyb <- gamap( lx200.file, stop.at="hyb" )
    di.qcc <- gamap( lx200.file, stop.at="qcc" )

    x.inv.qcc <- inverse.qcc30.normalize( di.qcc, di.plate )

    expect_equivalent( di.hyb, x.inv.qcc )

})
