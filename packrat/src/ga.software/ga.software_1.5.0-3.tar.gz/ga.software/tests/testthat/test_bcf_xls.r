library(ga.software)
library(gdata)
library(ga.utils)
library(readxl)
library(testthat)

context( "batch xlsx" )

test_that( "type 'log scale' gets right", {

    bcf.1512 <- load.get( "data/bcf_ps1512.RData", verbose = FALSE )
    xls1 <- tempfile( fileext = ".xlsx" )

    d <- batch_xls(bcf.1512, where=xls1, verbose=FALSE)

    expect_is( d, "data.frame" )
    expect_equal( ncol(d), 3 )
    expect_named( d, c("Correction","Shift","Scale"), ignore.order = TRUE )
    expect_equivalent( d$Correction, rep(0,54) )
    expect_equivalent( d$Shift, coef(bcf.1512)["sft",] )
    expect_equivalent( d$Scale, coef(bcf.1512)["shr",] )

    expect_true( file.exists(xls1) )
    expect_equal( excel_sheets(xls1), "BCF" )
    d2 <- as.data.frame( read_xlsx(xls1) )
    for( i in 1:ncol(d2) ) {
        d2[,i] <- as.numeric( d2[,i] )
    }

    expect_equivalent( d2, d )

})

test_that( "type 'difference' gets right", {

    bcf.1508 <- load.get( "data/bcf_ps1508.RData", verbose = FALSE )
    xls2 <- tempfile( fileext = ".xlsx" )

    d <- batch_xls(bcf.1508, where=xls2, verbose=FALSE)

    expect_is( d, "data.frame" )
    expect_equal( ncol(d), 3 )
    expect_named( d, c("Correction","Shift","Scale"), ignore.order = TRUE )
    expect_equivalent( d$Correction, coef(bcf.1508) )
    expect_equivalent( d$Shift, rep( 1, nrow(d) ) )
    expect_equivalent( d$Scale, rep( 1, nrow(d) ) )

    expect_true( file.exists(xls2) )
    expect_equal( excel_sheets(xls2), "BCF" )
    d2 <- read.xls(xls2)

    expect_equivalent( d2, d )

})

test_that( "type 'difference' gets right", {

    bcf.0000 <- load.get( "data/bcf_ps0000.RData", verbose = FALSE )
    xls3 <- tempfile( fileext = ".xlsx" )

    d <- batch_xls(bcf.0000, where=xls3, verbose=FALSE)

    expect_is( d, "data.frame" )
    expect_equal( ncol(d), 3 )
    expect_named( d, c("Correction","Shift","Scale"), ignore.order = TRUE )
    expect_equivalent( d$Correction, rep(0,nrow(d)) )
    expect_equivalent( d$Shift, rep( 1, nrow(d) ) )
    expect_equivalent( d$Scale, rep( 1, nrow(d) ) )

    expect_true( file.exists(xls3) )
    expect_equal( excel_sheets(xls3), "BCF" )
    d2 <- read.xls(xls3)

    expect_equivalent( d2, d )

})

test_that( "filenames are auto corrected", {

    bcf.1512 <- load.get( "data/bcf_ps1512.RData", verbose = FALSE )
    dir1 <- tempdir()

    d <- batch_xls(bcf.1512, where=dir1, verbose=FALSE, force=TRUE)
    xls1 <- file.path( dir1, "PS1512.xls" )
    expect_true( file.exists( xls1 ) )

    expect_is( d, "data.frame" )
    expect_equal( ncol(d), 3 )
    expect_named( d, c("Correction","Shift","Scale"), ignore.order = TRUE )
    expect_equivalent( d$Correction, rep(0,54) )
    expect_equivalent( d$Shift, coef(bcf.1512)["sft",] )
    expect_equivalent( d$Scale, coef(bcf.1512)["shr",] )

    expect_true( file.exists(xls1) )
    expect_equal( excel_sheets(xls1), "BCF" )
    d2 <- read.xls(xls1)

    expect_equivalent( d2, d )

})

test_that( "48 probe corrections are turned into 54 row matrices in xls", {

    dir.create( dir1 <- tempfile() )
    bcf.ps1801l <- load.get( "data/bcf_ps1801l.RData", verbose=FALSE )

    d <- batch_xls(bcf.ps1801l, where=dir1, verbose=FALSE, force=TRUE)
    xls1 <- file.path( dir1, "PS1801L.xls" )
    expect_true( file.exists( xls1 ) )

    expect_equal( nrow(d), 54 )
    d2 <- read.xls( xls1 )
    expect_equal( nrow(d2), 54 )

})
