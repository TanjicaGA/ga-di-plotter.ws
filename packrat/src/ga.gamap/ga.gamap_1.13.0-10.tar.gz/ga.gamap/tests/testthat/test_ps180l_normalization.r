library(ga.gamap)
library(ga.data)
library(ga.batchcorrection)

lx200.file <- file.path( "data", "Lx200-TestfileD-Q2-012.csv" )

context( "PS1801L Normalization" )

test_that( "PS1801L normalization works", {

    x.q <- gamap( lx200.file, stop.at = "qcc" )
    x.n <- ps1801l.normalize( lx200.file, batch="PS1801L" )

    expect_is( x.q, "matrix" )
    expect_is( x.n, "matrix" )

    expect_equal( dim(x.q), c(90,54) )
    expect_identical( dimnames( x.n ), dimnames( x.q ) )

    ## at this point there shouldn't be any NA's at all
    expect_true( !anyNA( x.n ) )
    ## the qcc30 normalized data should have some NAs
    expect_true( all( is.na( x.q[, lx200.missing.probes(include.technical=FALSE) ] )))
    expect_true( !anyNA( x.q[, lx200.probes(include.technical=FALSE) ] ))

    ## the data should be essentially the same
    expect_equivalent( x.q[,lx200.probes(incl=F)], x.n[,lx200.probes(incl=F)] )

    x.b <- gamap( lx200.file, batch="PS1901L", stop.at="batch" )
    x.u <- inverse.correct( batch.correction("PS1801L"), x.b )
    x.n2 <- ps1801l.normalize( lx200.file, batch="PS1901L" )

    expect_equivalent(
        x.u,
        x.n2
    )

    din.u <- gamap( x.u, start.from="qcc", batch="PS1801L" )
    din   <- gamap( lx200.file, batch="PS1901L" )

    ## DI scores assuming this is qcc data at PS1801L should match
    ## those calculated from scratch
    expect_equivalent( din.u, din )

    ## can work with already batch hcorrected data
    x.u2 <- ps1801l.normalize( x.b, start.from="batch" )
    expect_equivalent( x.u2, x.n2 )

})

test_that( "PS1801L normalization on biocode works", {

    biocode.file <- file.path( "data", "Q2-005-K1515_II-BC1511.csv" )
    x.n <- ps1801l.normalize( biocode.file, batch = "PS1512" )
    x.b <- gamap( biocode.file, batch = "PS1512", stop.at="batch" )

    stopifnot( all( x.b > 0 ) )

    x.u <- inverse.correct( batch.correction("PS1801L"), x.b )

    expect_equivalent( x.n, x.u )

})
