library(ga.utils)

context( "Look up" )

test_that( "2 column lookups work", {

    db <- data.frame( A=1:5, B=letters[1:5], stringsAsFactors = FALSE )

    expect_equal(
      look.up( 1:5, db ),
      letters[1:5]
      )

    expect_equal(
      look.up( 3, db ),
      "c"
      )

    expect_equal(
      look.up( letters[1:5], db ),
      1:5
      )

    expect_equal(
      look.up( letters[5:6], db ),
      c("5","f")
      )

    expect_equal(
      look.up( c(1:4,6), db ),
      c(letters[1:4],"6")
      )

})
