##' batch correction
##'
##' Performs batch correction as implemented in pamr::pamr.batchadjust
##' @title anova batch correction
##' @param data data to batchadjust, a 2D array
##' @param batchlabels vector labels defining the batches to adjust
##'     according to. length of this should equal number of rows of x
##' @return input data adjusted according to batchlabels
##' @author Torbjorn Lindahl
##' @importFrom pamr pamr.batchadjust
##' @export
batchadjust <- function (data, batchlabels) {
    temp <- list(x = t(data), batchlabels = batchlabels)
    temp2 <- pamr::pamr.batchadjust(temp)
    t(temp2$x)
}
