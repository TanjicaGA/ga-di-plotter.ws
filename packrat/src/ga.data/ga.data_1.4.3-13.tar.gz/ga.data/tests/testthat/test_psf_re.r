library(ga.data)

context( "psf re" )

test_that( "the psf regexp works", {

    expect_true( grepl( psf_re(anchored=FALSE), "foo PS1903L bar" ) )
    expect_false( grepl( psf_re(anchored=TRUE), "foo PS1903L bar" ) )

    expect_true( grepl( psf_re(), "PS1903L" ) )
    expect_true( grepl( psf_re(), "PS1801" ) )

})
