##' PCA model of GAmap
##'
##' The PCA model that is the core of GAmap
##' @title GAmap PCA model
##' @return prcomp object with 15 pcs
##' @author Torbjørn Lindahl
##' @export
##' @param full return the full PCA model, not capped at 15 components
##' @importFrom stats prcomp
model.pca <- function( full=FALSE ) {

    if( full ) {
        x <- model.qcc30.data()
        x[ x < 15 ] <- 0
        return( prcomp(x) )
    }

    return( gamap.pca )

}
