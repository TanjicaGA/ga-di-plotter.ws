library(ga.biocode)

options(stringsAsFactors = FALSE)

context( "read.biocode" )

biocode.file <- file.path( "data", "TestFile1.csv" )
biocode.file2 <- file.path( "data", "TestFile3.csv" )

test_that( "biocode files can be read", {

    d <- read.biocode( biocode.file )

    expect_is( d, "list" )
    expect_named( d, c("Median","Count","header"), ignore.order = TRUE )
    expect_is( d[["Median"]], "data.frame" )
    expect_is( d[["Count"]],  "data.frame" )
    expect_is( d[["header"]],  "list" )

    m <- d[["Median"]]
    c <- d[["Count"]]

    expect_equal( dim(m), c(76,61) )
    expect_equal( dim(c), c(76,61) )

    expect_named(
        d$header,
        c( "Program", "Build", "Date", "SN", "Session", "Operator",
          "TemplateName", "Samples", "Min Events")
    )

    expect_equal( as.character(d$header$Date), "2014-10-09 11:24:00" )

    expect_equal(

        d$header,

        structure(list(Program = "Biocode Analyzer 1000A", Build =
                                                               2.3, Date = "2014-10-09 11:24:00 CEST", SN = "None",
                       Session = "COP-1404 plate1", Operator =
                                                        "Krzysztofa Grzelak", TemplateName = "IBS3.0",
                       Samples = 76L, `Min Events` = 0L), .Names =
                                                              c("Program", "Build", "Date", "SN", "Session",
                                                                "Operator", "TemplateName", "Samples",
                                                                "Min Events"))

    )

    fromfile <- source( file.path( "data", "testfile1_data.r" ) )$value
    expect_equal( d, fromfile )

})

context( "read.biocode.files" )

test_that( "several biocode files can be read", {

    d <- read.biocode.plates( c( biocode.file, biocode.file2 ) )

    expect_equal( dim(d), c(135,67) )

    fromfile <- source( file.path( "data", "testdata13_data.r" ) )$value
    expect_equal( fromfile, d )

})
