##' Add nicely formatted PCA scores axis
##'
##' Sets up pca axis labels reporting explained variance
##' @title adds explained variance to PCA scores axes
##' @param obj pca object
##' @param comps components to report on
##' @param sprintf.pattern pattern to use with sprintf
##' @return a ggplot2::labs object
##' @author Torbjørn Lindahl
##' @importFrom pls explvar
##' @export
pca.axis.labels <- function( obj, comps=c(1,2), sprintf.pattern="PC%d (%.1f%%)" ) {
    xp <- explvar(obj)
    ggplot2::labs(
        x=sprintf( sprintf.pattern, comps[1], xp[comps[1]] ),
        y=sprintf( sprintf.pattern, comps[2], xp[comps[2]] )
    )
}
