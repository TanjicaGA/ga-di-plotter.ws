##' Calculate DI
##'
##' Calcuate DI. Details to come
##' @title Calculate DI
##' @param x input, often a csv file
##' @param start.with step to start with
##' @param stop.at step to stop after
##' @param start.from step to start after
##' @param batch batch to use for correction
##' @param qc.check.qcc30 check QCC30 for QC values before calculating
##'     the median profile
##' @param ignore.total.signal.criterion don't check QCC30 samples for
##'     total signal criterion
##' @param platform Platform, one of 'biocode' and 'lx200'. Used to
##'     handle discrapency in probe sets
##' @return depends, see details
##' @author Torbjørn Lindahl
##' @export
gamap <- function( x,
                  start.with="file", stop.at, start.from,
                  batch, qc.check.qcc30=TRUE,
                  ignore.total.signal.criterion=FALSE,
                  platform=NULL
                  ) {

    steps <- c( "file", "raw", "hyb", "qcc", "batchadjusted", "bg",
               "center", "scores", "t2res", "dysbiosis", "numerical",
               "final" )

    if( !missing(start.from) ) {
        start.from <- match.arg( start.from, steps )
        if( start.from == "final" ) {
            warning( "Cannot start from final since that is the last step, proceding with start.with as final" )
            start.with <- "final"
        }
        else {
            m <- match( start.from, steps )
            start.with <- steps[m+1]
        }
    }

    if( missing( stop.at ) )
      stop.at <- steps[ length(steps) ]

    start.with <- match.arg( start.with, steps )
    stop.at <- match.arg( stop.at, steps )

    start.step <- match( start.with, steps )
    stop.step <- match( stop.at, steps )

    ## initialize output before the chain starts
    output <- x

    platform.is.missing <- missing(platform)

    ## arguments to each step
    step.args <- list(
        "batchadjusted" = function() {
        if(!platform.is.missing) {
            list( "platform" = platform, "batch" = batch )
        } else {
            list("batch" = batch)
        }},
        "numerical" = function() {list(
        )},
        "qcc" = function() {list(
        "qc.check.qcc30"=qc.check.qcc30,
        "ignore.total.signal.criterion"=ignore.total.signal.criterion
        )},
        "center" = function() {
        if(!platform.is.missing) {
            list( "platform" = platform )
        } else {
            list()
        }}
    )

    if( stop.step >= start.step ) {
        for( step in steps[start.step:stop.step] ){

            step.func <- get(paste0("gamap.step.",step))

            if( step %in% names(step.args) ) {
                extra.args <- step.args[[step]]()
            }
            else {
                extra.args <- list()
            }

            args <- append( list(output), extra.args )

            output <- do.call( step.func, args )

        }
    }
    else if( start.step == stop.step + 1 ) {
        output <- x
    }
    else {
        stop( "cannot stop at something that is before the starting point" )
    }

    return( output )

}

##' Parse biocode data from file data
##'
##' Extracts probe measurements from data frame with complete info
##' from file.
##' @title fetch biocode data
##' @param input data.frame as read from a biocode csv file using read.biocode
##' @return matrix with biocode data
##' @author Torbjørn Lindahl
##' @importFrom ga.biocode biocode.data
##' @importFrom ga.data probe.re
gamap.step.raw <- function( input ){

    output <- biocode.data( input, name.fix=FALSE, hyc=FALSE, qcc=FALSE,
                           hyc.name="HYC01", remove.control.probes=FALSE )

    attr( output, "plate" ) <- input$Plate
    attr( output, "HYC01" ) <- input[,"HYC01"]
    attr( output, "UNI05" ) <- input[,"UNI05"]
    attr( output, "platform" ) <- input$Platform
    cn <- colnames(input)
    vn <- grep( probe.re(TRUE), cn, value=TRUE )
    attr( output, "TotalSignal" ) <- rowSums( input[, vn ], na.rm=TRUE )

    ## set batch correction for later use in the process
    ## if( is.null( do.batch.correct ) ) {
    ##     do.batch.correct <<- rep( FALSE, nrow(output ) )
    ##     ## do.batch.correct[ basename(as.character(input$File)) %in% batch.correct.files() ] <<- TRUE
    ## }

    ## if( is.null(filenames) ) {
    ##     filenames <<- basename(as.character(input$File))
    ##     ## attr( output, "filenames" ) <- unique(filenames)
    ## }

    return( output )
}

##' Hyb adjustment step
##'
##' Divides profile by HYC01 or supplied vector
##' @title Hyb adjustment step
##' @param input raw median data from biocode file
##' @return matrix
##' @author Torbjørn Lindahl
gamap.step.hyb <- function( input ){
    hyc.vector <- attr( input, "HYC01" )
    uni.vector <- attr( input, "UNI05" )
    output <- hyc.correct( input, hyc.vector )
    output <- output * 1e3
    attr( output, "UNI05" ) <- attr( input, "UNI05" )
    attr( output, "plate" ) <- attr( input, "plate" )
    attr( output, "platform" ) <- attr( input, "platform" )
    attr( output, "TotalSignal" ) <- attr( input, "TotalSignal" )
    return( output )
}

gamap.step.center <- function( input, platform ){

    pca <- ga.data::model.pca()
    output <- scale(input, pca$center, pca$scale)

    ## handle the missing for lx200, they should be 0 here
    pl <- attr( input, "platform" )[1]

    if( missing(platform) ) {
        if( is.null(pl) ) {
            warning( "gamap.step.center: platform not supplied as argument or a named attribute of the input data to gamap.step.batchadjusted, using 'biocode'" )
            pl <- rep("biocode", nrow(input) )
        }
    } else {
        if( length(platform) == 1 ) {
            pl <- rep( "biocode", nrow(input) )
        }
        else if( length(platform) != nrow(input) ) {
            stop( sprintf(
                "gamap.step.center: The supplied platform argument (%d values) does not match the data size (%d rows)" ,
                length(platform), nrow(input)
            ))
        }
        else {
            pl <- platform
        }
    }

    jj <- pl %in% "lx200"

    if( any(jj) ) {
        p <- lx200.missing.probes( colnames(output) )
        output[ jj, p ] <- 0
    }
    ##

    return( output )

}

gamap.step.scores <- function( input ){
    ## input is centered data
    pca <- ga.data::model.pca()
    l <- pca$rotation[,1:15]
    scores <- input %*% l
    rownames(scores) <- rownames(input)
    colnames(scores) <- colnames(pca$rotation)
    attr( scores, "x.centered" ) <- input
    output <- scores
    return( output )
}

gamap.step.t2res <- function( input ){
    ## input is scores
    pca <- ga.data::model.pca()
    l <- pca$rotation[,1:15]
    x.pred <- input %*% t(l)
    x.new.centered <- attr( input, "x.centered" )
    x.res <- x.pred - x.new.centered
    q.res.new <- rowSums( x.res**2 )

    sc <- pca$x[,1:15]
    f0 <- colSums( sc**2 ) / nrow(sc)
    f <- sqrt( 1/f0 )
    t2.new <- rowSums( (input %*% diag(f))**2 )
    names(t2.new) <- rownames(input)

    output <- data.frame( T2=t2.new, Qres=q.res.new, Sample=names(t2.new) )

    return( output )
}

##' T2/Qres eval step of the algorithm
##'
##' Evaluates T2 and Qres and reports result
##' @title classificaion step of algorithm
##' @param input list named T2 and Qres, containing these numbers
##' @return character with classification outcome
##' @author Torbjørn Lindahl
##' @importFrom ga.data t2.limit
##' @importFrom ga.data qres.limit
gamap.step.dysbiosis <- function( input ){

    t2 <- input$T2
    q.res <- input$Qres

    q.eval <- q.res > ga.data::qres.limit()
    t2.eval <- t2 > ga.data::t2.limit()

    severity <- 1 + apply( cbind(q.eval,t2.eval), 1, max )

    grades <- c( "negative", "dysbiosis", "dysbiosis" )

    output <- grades[severity]

    attr( output, "T2" ) <- t2
    attr( output, "Qres" ) <- q.res
    names(output) <- input$Sample

    return( output )

}

gamap.step.final <- identity
