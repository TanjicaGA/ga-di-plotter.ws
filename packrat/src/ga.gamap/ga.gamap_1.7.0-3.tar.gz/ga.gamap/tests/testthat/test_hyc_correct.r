library(ga.gamap)

context( "hyc correct" )

test_that( "data is corrected", {

    x <- matrix( 1, ncol=58, dimnames = list( "Foo", ga.data::probe.set("ibs3") ) )

    local({

        x[1,"HYC01"] <- 2

        expect_equivalent(
          hyc.correct( x ),
          matrix( .5, ncol=57 )
          )
    })

    expect_equivalent(
      hyc.correct( x, .5 ),
      matrix( 2, ncol=58 )
      )

})
