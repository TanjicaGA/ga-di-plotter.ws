##' Plots batchcorrection object
##'
##' Plots one of several plots. Available plots are:
##'
##' 1. Per probe line plots, showing old and new and corrected
##'
##' 2. PCA scores of old, new and corrected
##'
##' 3. T2/Qres plot with normal rference, old and corrected and
##' optinally uncorrected
##'
##' 4. Scatter plot, similar to per probe line plot only with signal
##' values on both axes instad of just one
##'
##' @title Various plots of batchcorrection
##' @param x batchcorrection object
##' @param what what type of plot to produce, one of "PCA", "Probes",
##'     "T2Qres", "Scatter"
##' @param newdata optionally new data to correct
##' @param ... other parameters passed to plot functions
##' @return None
##' @author Torbjørn Lindahl
##' @export
plot.batchcorrection <- function( x, what=c("PCA","Probes","T2Qres","Scatter"), newdata=NULL, ... ) {

    if (!inherits(x, "batchcorrection"))
        stop("object not of class \"batchcorrection\"")

    what <- match.arg( what )

    old <- x$model$old
    new <- x$model$new
    x.corr <- correct( x, new )

    if( what == "PCA" ) {
        plot.batchcorrection.pca( x, newdata, ... )
    }
    else if( what == "T2Qres" ) {
        di.new <- ga.gamap::gamap( x.corr, start.from = "batch", stop.at = "dysbiosis" )
        ga.gamap::di.plot( di.new )
    }
    else if( what == "Probes" ) {
        plot.batchcorrection.probes( x, ... )
    }
    else if( what == "Scatter" ) {
        plot.batchcorrection.probes.scatter( x, ... )
    }

}

##' @importFrom pls scores explvar
##' @importFrom graphics plot text legend
##' @importFrom stats prcomp predict
##' @importFrom ga.utils knn.impute
##' @rdname plot.batchcorrection
plot.batchcorrection.pca <- function( obj, newdata, ... ) {

    old <- obj$model$old
    new <- obj$model$new
    x.corr <- correct( obj, new )

    x <- rbind( old, new )
    xk <- knn.impute(x)
    pca <- prcomp( xk )
    sets <- c(
        rep( "old", nrow(old) ),
        rep( "new", nrow(new) )
        )
    n <- nrow(x.corr)
    corr.scores <- predict( pca, newdata=x.corr )
    set.colors <- c(
        old="green", new="red", corr="blue"
        )
    sc <- scores(pca)
    xpl <- explvar(pca)
    xr <- range( sc[,1] )
    yr <- range( sc[,2] )

    plot( 0,
         xlab=sprintf("PC1 (%.1f%%)", round(xpl[1]*1,1) ),
         ylab=sprintf("PC2 (%.1f%%)", round(xpl[2]*1,1) ),
         xlim=xr, ylim=yr,
         main="PCA scores",
         type="n", ...
         )
    text( sc[,1], sc[,2], labels=1:n, col=set.colors[sets], ... )
    text( corr.scores[,1:2], labels=1:n, col=set.colors["corr"], ... )
    legend(
        "topright", col=set.colors,
        legend=names(set.colors),
        pch=19
        )

    invisible(pca)

}

##' @importFrom ga.utils pdf.a4.landscape
##' @importFrom shape Arrows
##' @importFrom grDevices dev.off dev.interactive
##' @importFrom stats cor
##' @importFrom graphics plot axis text title segments
##' @param obj PSF object
##' @param pdf.file optional pdf file to write to
##' @param probes subset of probes to plot
##' @param add.coef optionally add coefficients to the title
##' @param ... other arguments to and from methods
##' @rdname plot.batchcorrection
##' @importFrom graphics par
plot.batchcorrection.probes <- function( obj, pdf.file, probes, add.coef=FALSE, ... ) {

    old <- obj$model$old
    new <- obj$model$new
    x.corr <- correct( obj, new )

    if( missing(probes) ) {
        probes <- 1:ncol(old)
    }

    outliers <- obj$outliers

    args <- list(...)

    if(!missing(pdf.file))
        pdf.a4.landscape(pdf.file)

    nn <- nrow(old)
    for( i in probes ) {
        ol <- outliers[[as.character(i)]]
        yr <- range(
            c( old[,i], x.corr[,i], new[,i] ),
            na.rm=TRUE
            )
        if( !"log" %in% names(args) || !args$log %in% "y" )
            yr[1] <- 0
        ## r2 <- cor( old[,i], x.corr[,i], method="spearman", use="pairwise.complete.obs" )
        r2 <- cor( old[,i], x.corr[,i], method="pearson", use="pairwise.complete.obs" )
        r2s <- cor( old[,i], x.corr[,i], method="spearman", use="pairwise.complete.obs" )
        x1 <- rep(1,nn)
        x2 <- rep(2,nn)
        x3 <- rep(2.5,nn)
        ll <- 1:nn

        j <- rep( TRUE, length(x1) )
        if(!is.null(ol)) {
            j[ol] <- FALSE
        }

        plot( 1, type="n", xlim=c(0.5,3),
             xaxt="n", ylim=yr,
             xlab = "",
             ylab="Probe signal", ... )
        axis( side=1, at=c(1,2,2.5), labels=c("Old", "Corrected", "Uncorrected") )
        text( x=x1, y=old[,i],    labels=ll, col="green"     )
        text( x=x2, y=x.corr[,i], labels=ll, col="darkgreen" )
        text( x=x3, y=new[,i],    labels=ll, col="gray"      )

        Dx <- .5
        dx <- .1
        my1 <- exp(mean(log(new[,i])))
        my2 <- exp(mean(log(x.corr[,i])))
        Dy <- my2-my1
        dy <- dx/Dx*Dy
        Arrows( 2.5-dx, my1+dy , 2+dx, my2-dy, col="gray" )

        if( add.coef ) {
            cf <- coef( obj )[,i]
            title( sprintf("Probe %d: %.4f , %.4f",i, cf[1], cf[2]) )
        }
        else {
            title( paste("Probe",i) )
        }
        segments( x1[j], old[j,i], x2[j], x.corr[j,i], col="gray" )
        if( any( !j ) )
            segments( x1[!j], old[!j,i], x2[!j], x.corr[!j,i], col="red" )
        up <- par("usr")
        t.dy <- diff( up[3:4] )
        t.y <- mean( old[,i] ) + t.dy/15
        if( t.y > up[4] )
            t.y <- up[4] - t.dy/15
        text(
            1.85, t.y,
            sprintf( "Pears: %.2f\nSpear: %.2f", round(r2,2), round(r2s,2) ),
            cex=1.5, family="mono", adj=c(1,1),
        )
        if( dev.interactive() )
            readline(i)
        i <- i+1
    }

    if( !dev.interactive() )
        dev.off()

}

##' @importFrom reshape2 melt
##' @importFrom ggplot2 ggplot geom_point guides geom_blank
##' @importFrom ga.utils pdf.a4.landscape
##' @importFrom ga.data probe.set
##' @param obj PSF object
##' @param pdf.file optional pdf file to write to
##' @param probes subset of probes to plot
##' @param add.coef optionally add coefficients to the title
##' @rdname plot.batchcorrection
##' @importFrom ga.data bacteria.names
##' @importFrom ga.data probe.numbers
##' @importFrom ggplot2 geom_abline
##' @importFrom ggplot2 ggtitle
##' @importFrom ggplot2 aes
##' @importFrom ggplot2 ggplot
##' @importFrom ggplot2 guides
plot.batchcorrection.probes.scatter <- function( obj, pdf.file, probes, add.coef=FALSE ) {

    xo <- obj$model$old
    class(xo) <- setdiff( class(xo), "AsIs" )
    xn <- obj$model$new
    class(xn) <- setdiff( class(xn), "AsIs" )

    xc <- correct( obj, xn )

    xm <- cbind.data.frame(
        melt( xo ),
        melt( xn ),
        melt( xc )
    )[,-c(4:5,7:8)]
    colnames(xm) <- c("Sample","Probe","Old","New","Corr")

    if(!missing(pdf.file))
        pdf.a4.landscape(pdf.file)

    if( missing(probes) )
        probes <- colnames(xo)

    pr <- probe.set("ibs3")

    g <- NULL

    for( probe in probes ) {

        if( add.coef ) {
            cf <- coef( obj )[,probe]
            title <- sprintf(
                "%d - %s [%s] - probe %d: %.4f , %.4f",
                probe.numbers(probe),
                probe,
                bacteria.names(probe),
                match(probe,pr),
                cf[1], cf[2]
            )
        }
        else {
            title <- sprintf(
                "%d - %s [%s] - probe %d",
                probe.numbers(probe),
                probe,
                bacteria.names(probe),
                match(probe,pr)
            )
        }

        ## To prevent warnings with devtools::check
        Old <- New <- Corr <- Sample <- NULL

        g <- ggplot( xm[ xm$Probe == probe, ] ) +
            geom_abline( intercept = 0, slope = 1, col="grey" ) +
            geom_point( aes(x=Old,y=New,col=Sample), pch=1 ) +
            geom_point( aes(x=Old,y=Corr,col=Sample) ) +
            guides( col=FALSE ) +
            ggtitle( title ) +
            geom_blank()
        print(g)

        if( dev.interactive() )
            readline(probe)

    }

    if( !dev.interactive() )
        dev.off()

    ## return the last plot
    invisible(g)

}
