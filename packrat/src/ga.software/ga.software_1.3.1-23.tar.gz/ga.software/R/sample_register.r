##' Read some samples from the sample register
##'
##' Finds samples from the sample register, with the given filename and name combinations
##' @title read sample register
##' @param sreg.file sample register file
##' @param fpart filename to match, eg AID123456
##' @param snames sample names to look up
##' @param variant EN or GE, which variant to use
##' @return subset of data frame from sample register
##' @author Torbjørn Lindahl
##' @importFrom readxl read_excel
##' @importFrom gdata read.xls
##' @importFrom ga.utils count.na
read.sample.register <- function(sreg.file, fpart, snames, variant=c("2.0","EN","GE")) {
    variant <- match.arg(variant)
    ## d <- readxl::read_excel( sreg.file, skip=3 )
    d <- gdata::read.xls( sreg.file, skip=2, stringsAsFactors=FALSE )
    colnames(d) <- make.names( colnames(d) )
    if( variant == "GE" || variant == "2.0" )
        i <- grepl( fpart, d$Sample.file ) & d$Sample.ID %in% snames
    else if( variant == "EN" )
        i <- grepl( fpart, d$Sample.file ) & d$X.Sample.ID. %in% snames
    if(!any(i)){
        say("Found no matches in sample register")
        invisible()
    }
    else {
        ## cat("Found",sum(i %in% TRUE),"matches in SR","\n")
        dd <- d[i,]
        dd <- dd[, count.na(dd) < nrow(dd)]
        dd
    }
}
