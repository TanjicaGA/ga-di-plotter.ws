##' Bacteria names as shown on report
##'
##' Returns bacteria names as shown intended to be shown on the
##' customer reports. Source for the mapping is the file
##' \code{54_Probenr_Bacterianr_Bacteria name - edditert mot gammel
##' rekkefølge.xlsx}
##' @title report bacteria names
##' @return character with bacteria names
##' @author Torbjørn Lindahl
##' @export
##' @param x names to look up (could be AG codes or probe numbers)
##' @param ... extra arguments to ga.utils::look.up
##' @importFrom ga.utils look.up
customer.bacteria.names <- function( x, ... ) {

    if( missing(x) )
        x <- probe.set("ibs3")[1:54]

    return( look.up( x=x, db=bacteria.report.name.mapping, to="NameOnReport", ... ) )

}
