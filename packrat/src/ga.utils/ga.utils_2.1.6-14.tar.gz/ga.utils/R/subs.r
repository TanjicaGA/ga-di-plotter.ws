##' Internal function
##'
##' Contains common code used by both \code{subs} and \code{gsubs}
##' @title internal.subs
##' @param func The function to call, typcically sub og gsub
##' @param patterns a vector of patterns
##' @param replacements a vector of replacements
##' @param x the object to be substituted
##' @param ... arguments for sub or gsub
##' @return same as \code{\link{sub}} og \code{\link{gsub}}
##' @author Torbjørn Lindahl
internal.subs <- function( func, patterns, replacements, x, ... ) {

    if( length(patterns) > 1 && length(replacements) > 1 && length(patterns) != length(replacements) )
      stop( "If many patterns and replacements are provided, they need to have the same length" )

    pairs <- cbind( patterns, replacements )

    for( i in 1:nrow(pairs) ) {
        x <- do.call( func, list( pairs[i,1], pairs[i,2], x, ... ) )
    }

    return( x )

}

##' sub with many patterns and replacements
##'
##' Process many patterns and many replacements in one go. Note the order
##' of patterns will matter as they are processed sequentially. subs
##' invokes \code{\link{sub}} and gsubs invokes \code{\link{gsub}}
##' @title sub many patterns and replacements
##' @param ... arguments for sub or gsub
##' @return one value for each character in x
##' @author Torbjørn Lindahl
##' @export
subs <- function( ... ) internal.subs( sub, ... )

##' @rdname subs
##' @export
gsubs <- function( ... ) internal.subs( gsub, ... )
