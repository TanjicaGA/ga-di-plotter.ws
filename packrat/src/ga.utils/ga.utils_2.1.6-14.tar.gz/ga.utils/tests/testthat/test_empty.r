context("empty")

test_that( "simple cases work", {

    expect_true( empty( "" ) )
    expect_true( empty( c() ) )
    expect_true( empty( list() ) )
    expect_true( empty( NULL ) )
    expect_true( empty( array(dim=c(0,2)) ) )

})
